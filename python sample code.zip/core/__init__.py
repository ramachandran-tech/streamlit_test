"""O2C medallion ingestion framework."""
__version__ = "0.1.0"
