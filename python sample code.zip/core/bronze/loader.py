"""Bronze layer loader."""
from __future__ import annotations

import fnmatch
from dataclasses import dataclass
from datetime import datetime

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from ..common import audit as ops
from ..common.hashing import align_to_spec, create_table_if_absent, row_hash
from ..common.landing import archive_file
from ..config.loader import ConfigContext
from ..config.models import LoadMode, RetiredFeed, SourceSpec, TableSpec
from . import parsers
from .schema_drift import SchemaResolution

# substrings meaning "the folder isn't there" (not a real infra failure)
_MISSING_PATH_HINTS = (
    "path does not exist",
    "no such file or directory",
    "file or directory not found",
    "cannot find the path",
)


def _is_missing_path(exc: Exception) -> bool:
    message = str(exc).lower()
    return any(hint in message for hint in _MISSING_PATH_HINTS)


class SchemaDriftError(RuntimeError):
    """A delivery's headers broke the source's schema-drift policy (on_drift=fail)."""


class SchemaQuarantine(Exception):
    """A delivery is set aside unprocessed (on_drift=quarantine) without failing the run."""


class FeedOwnershipError(RuntimeError):
    """A file's content is already registered to a different feed."""


@dataclass(frozen=True)
class LandedFile:
    path: str
    name: str
    version_id: str
    received_ts: datetime
    is_partial: bool


class BronzeLoader:
    def __init__(self, spark: SparkSession, ctx: ConfigContext,
                 ops_store: ops.OpsStore) -> None:
        self.spark = spark
        self.ctx = ctx
        self.cfg = ctx.platform
        self.ops = ops_store

    # -- discovery -----------------------------------------------------------
    def landing_path(self, source: SourceSpec) -> str:
        """Resolved folder for a feed."""
        return source.landing_path(self.cfg)

    def _rival_claims(self, source: SourceSpec, file_name: str) -> list[str]:
        """Other feeds reading the same folder whose glob also takes this file."""
        home = self.landing_path(source)
        return [s.entity for s in self.ctx.sources()
                if s.entity != source.entity
                and self.landing_path(s) == home
                and fnmatch.fnmatchcase(file_name, s.file_glob)]

    def discover(self, source: SourceSpec) -> list[LandedFile]:
        root = self.landing_path(source)
        try:
            listing = (self.spark.read.format("binaryFile")
                       .option("pathGlobFilter", source.file_glob)
                       .load(root)
                       .select("path", "modificationTime",
                               F.sha2(F.col("content"), 256).alias("content_hash"))
                       .collect())
        except Exception as exc:
            if _is_missing_path(exc):
                print(f"[bronze] {source.entity}: no landing folder at {root}")
                return []
            raise RuntimeError(
                f"[bronze] {source.entity}: could not list '{root}' "
                f"(glob={source.file_glob}). Check the path exists and is "
                f"readable from the cluster. Underlying error: {exc}") from exc

        out: list[LandedFile] = []
        for r in listing:
            name = r["path"].rsplit("/", 1)[-1]
            rivals = self._rival_claims(source, name)
            if rivals:
                raise ValueError(
                    f"[bronze] '{name}' in {root} matches {source.entity} and "
                    f"{rivals}. Narrow file_glob so each feed claims only its "
                    f"own files, or give them separate landing_subdir folders.")
            out.append(LandedFile(
                path=r["path"], name=name,
                version_id=r["content_hash"][:32],
                received_ts=r["modificationTime"],
                is_partial=self.cfg.partial_file_marker in name))
        print(f"[bronze] {source.entity}: {len(out)} file(s) matched "
              f"{source.file_glob} in {root}")
        return sorted(out, key=lambda f: f.received_ts)

    # -- schema drift --------------------------------------------------------
    def _apply_drift_policy(self, source: SourceSpec, f: LandedFile,
                            spec: TableSpec, res: SchemaResolution,
                            schema_version: str) -> str:
        """Record what the header resolution found and decide the action."""
        policy = source.drift_policy(self.cfg)
        fatal = set(policy.fatal_if_missing) | {
            c.name for c in spec.columns if c.bk or c.pk}
        blocking = bool(set(res.missing) & fatal)
        action = policy.drift_action(blocking) if res.literal_drift else "OK"

        # per-column detail + DQ roll-up, then the per-file summary row
        self.ops.drift_events(source.entity, spec.logical_name, f.version_id,
                              f.name, res.fingerprint, res.events)
        if res.literal_drift:
            self.ops.drift_summary(
                source.entity, spec.logical_name, f.version_id, f.name,
                res.fingerprint, schema_version, res.drift_type,
                res.missing_headers, res.additional_headers,
                res.file_header_count, action)
        self.ops.set_schema_drift(f.version_id, res.status, res.fingerprint)
        if res.drifted:
            print(f"[bronze] {source.entity}: {f.name} -> {res.summary()} "
                  f"[{action}]")
            self.ops.run_event("bronze", source.entity, f"DRIFT_{res.status}",
                               detail=f"{f.name}: {res.summary()} -> {action}")
        return action

    def _drift_message(self, source: SourceSpec, f: LandedFile,
                       res: SchemaResolution) -> str:
        detail = "; ".join(e.detail for e in res.events
                           if e.severity == "ERROR") or res.summary()
        return (f"{source.entity}/{f.name}: {detail}. Declare the new header "
                f"under parse.aliases, or adjust this feed's on_drift / "
                f"fatal_if_missing in sources.yaml.")

    # -- archive -------------------------------------------------------------
    def _archive(self, source: SourceSpec, f: LandedFile) -> None:
        """Move a just-APPLIED file from incoming/ to archive/ (source_tree only)."""
        archive_dir = self.cfg.archive_path(source)
        if not archive_dir:  # subdir/flat layout: no archive
            return
        try:
            dst = archive_file(self.spark, f.path, archive_dir, f.name)
            self.ops.run_event("bronze", source.entity, "ARCHIVED",
                               detail=f"{f.name} -> {dst}")
            print(f"[bronze] {source.entity}: archived {f.name} -> {dst}")
        except Exception as exc:
            self.ops.run_event("bronze", source.entity, "ARCHIVE_FAILED",
                               detail=f"{f.name}: {exc}")
            print(f"[bronze] {source.entity}: archive skipped for {f.name} "
                  f"(left in incoming): {exc}")

    # -- retired feeds --------------------------------------------------------
    def _sweep_retired(self, feeds: list[RetiredFeed]) -> int:
        """Archive and log any file that lands in a retired feed's folder."""
        handled = 0
        for feed in feeds:
            root = self.cfg.landing_path(feed)
            try:
                paths = [r["path"] for r in (
                    self.spark.read.format("binaryFile")
                    .option("pathGlobFilter", feed.file_glob).load(root)
                    .select("path").collect())]
            except Exception as exc:
                if _is_missing_path(exc):
                    continue
                raise RuntimeError(
                    f"[bronze] {feed.entity} (retired): could not list '{root}' "
                    f"(glob={feed.file_glob}): {exc}") from exc
            archive_dir = self.cfg.archive_path(feed)
            for path in paths:
                name = path.rsplit("/", 1)[-1]
                live = [s.entity for s in self.ctx.sources()
                        if self.landing_path(s) == root
                        and fnmatch.fnmatchcase(name, s.file_glob)]
                if live:
                    msg = (f"{name} matches retired feed {feed.entity} and live "
                           f"feed(s) {live}; left in place. Narrow the globs.")
                    self.ops.run_event("bronze", feed.entity, "BLOCKED",
                                       detail=msg)
                    print(f"[bronze] {feed.entity}: BLOCKED - {msg}")
                    continue
                detail = f"{name}: {feed.reason or 'retired feed'}"
                if archive_dir:
                    try:
                        dst = archive_file(self.spark, path, archive_dir, name)
                        detail += f"; archived to {dst}"
                    except Exception as exc:
                        detail += f"; archive failed, left in incoming: {exc}"
                self.ops.run_event("bronze", feed.entity,
                                   "IGNORED_RETIRED_FEED", detail=detail)
                print(f"[bronze] {feed.entity}: not loaded (retired) - {detail}")
                handled += 1
        return handled

    # -- per-file load -------------------------------------------------------
    def _load_file(self, source: SourceSpec,
                   f: LandedFile) -> tuple[int, SchemaResolution]:
        spec = self.ctx.table(source.bronze_table)
        physical = create_table_if_absent(self.spark, self.cfg, spec)

        parser = parsers.get_parser(source.parser)
        pctx = parsers.ParseContext.for_source(self.cfg, source, spec)
        result = parser(self.spark, f.path, source, pctx)
        parsed, res = result.df, result.resolution
        # a multi-layout feed learns each file's layout from its headers
        schema_version = res.layout or source.schema_version
        if res.layout:
            self.ops.record_layout(f.version_id, schema_version,
                                   source.priority_of(res.layout))
        action = self._apply_drift_policy(source, f, spec, res, schema_version)
        if action == "FAIL":
            raise SchemaDriftError(self._drift_message(source, f, res))
        if action == "QUARANTINE":
            raise SchemaQuarantine(self._drift_message(source, f, res))

        business_cols = [c.name for c in spec.columns
                         if c.column_class == "business" and c.name in parsed.columns]
        stamped = (parsed
                   .withColumn("schema_drift_status", F.lit(res.status))
                   .withColumn("source_header_fingerprint",
                               F.lit(res.fingerprint))
                   .withColumn("source_file_version_id", F.lit(f.version_id))
                   .withColumn("ingestion_id", F.lit(self.ops.run_id))
                   .withColumn("source_system", F.lit(source.source_system))
                   .withColumn("source_entity", F.lit(source.entity))
                   .withColumn("source_file_name", F.lit(f.name))
                   .withColumn("source_file_path", F.lit(f.path))
                   .withColumn("file_received_ts",
                               F.lit(f.received_ts).cast("timestamp"))
                   .withColumn("schema_version", F.lit(schema_version))
                   .withColumn("raw_record_hash", row_hash(business_cols))
                   .withColumn("parse_status", F.lit("PARSED"))
                   .withColumn("parse_error_message", F.lit(None).cast("string"))
                   .withColumn("load_ts", F.current_timestamp())
                   .withColumn("load_date", F.current_date()))
        aligned = align_to_spec(stamped, spec)

        # supersede this file version's rows, then append (idempotent on retry)
        self.spark.sql(f"DELETE FROM {physical} "
                       f"WHERE source_file_version_id = '{f.version_id}'")
        aligned.write.format("delta").mode("append").saveAsTable(physical)
        return aligned.count(), res

    # -- public --------------------------------------------------------------
    def run(self, entities: list[str] | None = None,
            mode: LoadMode = LoadMode.INCREMENTAL) -> None:
        sources = [s for s in self.ctx.sources()
                   if entities is None or s.entity in entities]
        retired = [f for f in self.ctx.retired_feeds()
                   if entities is None or f.entity in entities]
        if not sources and not retired:
            raise ValueError(
                f"No configured source matches entities={entities}. "
                f"Known entities: {sorted(s.entity for s in self.ctx.sources())}")
        self._sweep_retired(retired)

        registered = (self.ops.registry()
                      .select("source_file_version_id", "entity", "bronze_status")
                      .collect())
        already = {r["source_file_version_id"] for r in registered
                   if r["bronze_status"] == "APPLIED"}
        owner_of = {r["source_file_version_id"]: r["entity"] for r in registered}
        blocked: list[str] = []
        conflicts: list[str] = []
        for source in sources:
            root = self.landing_path(source)
            # create the target table up front
            create_table_if_absent(self.spark, self.cfg,
                                   self.ctx.table(source.bronze_table))
            if not source.active:
                # deployed ahead of go-live: nothing in its folder is touched
                self.ops.run_event("bronze", source.entity, "INACTIVE",
                                   detail=f"active: false in sources.yaml; "
                                          f"files in {root} left in place")
                print(f"[bronze] {source.entity}: inactive - not loaded")
                continue
            discovered = self.discover(source)
            foreign = {f.version_id for f in discovered
                       if owner_of.get(f.version_id, source.entity) != source.entity}
            for f in (f for f in discovered if f.version_id in foreign):
                msg = (f"{source.entity}/{f.name}: this exact content is already "
                       f"registered to feed '{owner_of[f.version_id]}'. If that "
                       f"feed was renamed or merged into this one, re-point its "
                       f"ops.file_registry rows to '{source.entity}' first; "
                       f"otherwise take the file out of this feed's folder.")
                self.ops.run_event("bronze", source.entity, "BLOCKED", detail=msg)
                print(f"[bronze] {source.entity}: BLOCKED - {msg}")
                conflicts.append(msg)
            discovered = [f for f in discovered if f.version_id not in foreign]
            files = ([f for f in discovered if f.version_id not in already]
                     if mode is LoadMode.INCREMENTAL else list(discovered))
            if not files:
                detail = (f"{root} | glob={source.file_glob} | "
                          f"{len(discovered)} matched, 0 new "
                          f"({'already applied' if discovered else 'nothing found'})")
                self.ops.run_event("bronze", source.entity, "SKIPPED",
                                   detail=detail)
                continue
            for f in files:
                try:
                    self.ops.upsert_registration(
                        version_id=f.version_id, entity=source.entity,
                        name=f.name, path=f.path, received_ts=f.received_ts,
                        schema_version=source.schema_version,
                        is_partial=f.is_partial)
                    n, res = self._load_file(source, f)
                    self.ops.set_layer_status(f.version_id, "bronze",
                                              "APPLIED", n)
                    self.ops.run_event("bronze", source.entity, "SUCCESS", n,
                                       detail=f"{f.name} ({res.summary()})")
                    self._archive(source, f)  # incoming -> archive (best-effort)
                except SchemaQuarantine as exc:
                    # set aside without failing the run: not APPLIED
                    self.ops.set_layer_status(f.version_id, "bronze",
                                              "QUARANTINED")
                    self.ops.run_event("bronze", source.entity, "QUARANTINED",
                                       detail=str(exc))
                    print(f"[bronze] {source.entity}: QUARANTINED - {exc}")
                    continue
                except (SchemaDriftError, parsers.SheetNotFoundError) as exc:
                    # a feed whose layout broke must not land
                    self.ops.set_layer_status(f.version_id, "bronze", "FAILED")
                    self.ops.run_event("bronze", source.entity, "FAILED",
                                       detail=str(exc))
                    print(f"[bronze] {source.entity}: BLOCKED - {exc}")
                    blocked.append(str(exc))
                    break  # later files share the layout
                except Exception as exc:
                    self.ops.set_layer_status(f.version_id, "bronze", "FAILED")
                    self.ops.run_event("bronze", source.entity, "FAILED",
                                       detail=f"{f.name}: {exc}")
                    raise
        problems: list[str] = []
        if blocked:
            problems.append(f"{len(blocked)} source(s) blocked by schema drift "
                            f"or a missing tab:"
                            "\n  - " + "\n  - ".join(blocked))
        if conflicts:
            problems.append(f"{len(conflicts)} file(s) already registered to "
                            "another feed:\n  - " + "\n  - ".join(conflicts))
        if problems:
            error = SchemaDriftError if blocked else FeedOwnershipError
            raise error("\n".join(problems))
