"""Bronze parser plugins."""
from __future__ import annotations

import datetime as _dt
from dataclasses import dataclass, field
from io import BytesIO
from typing import Any, Callable, Dict, Optional, Sequence

from pyspark.sql import Column, DataFrame, SparkSession, Window
from pyspark.sql import functions as F
from pyspark.sql import types as T

from ..config.models import (PlatformConfig, SchemaDriftPolicy, SourceSpec,
                             TableSpec)
from . import schema_drift as drift

# column carrying a reader-supplied physical row number, dropped on projection
_ROW_COL = "__source_row_number"


class SheetNotFoundError(ValueError):
    """The workbook has none of the tabs the feed accepts."""


@dataclass(frozen=True)
class ParseContext:
    """Everything a parser needs to judge a header row beyond the file itself."""

    policy: SchemaDriftPolicy = field(default_factory=SchemaDriftPolicy)
    key_columns: frozenset = frozenset()  # bronze grain components (bk/pk)
    known_targets: frozenset = frozenset()  # columns the bronze table has

    @staticmethod
    def for_source(cfg: PlatformConfig, source: SourceSpec,
                   spec: Optional[TableSpec] = None) -> "ParseContext":
        keys = frozenset(c.name for c in spec.columns
                         if c.bk or c.pk) if spec else frozenset()
        known = frozenset(spec.column_names) if spec else frozenset()
        return ParseContext(policy=source.drift_policy(cfg),
                            key_columns=keys, known_targets=known)

    @staticmethod
    def default(source: SourceSpec) -> "ParseContext":
        return ParseContext(policy=SchemaDriftPolicy().merged(source.schema_drift))


@dataclass(frozen=True)
class ParseResult:
    df: DataFrame
    resolution: drift.SchemaResolution


ParserFn = Callable[..., ParseResult]
_REGISTRY: Dict[str, ParserFn] = {}


def register_parser(parser_id: str) -> Callable[[ParserFn], ParserFn]:
    def deco(fn: ParserFn) -> ParserFn:
        _REGISTRY[parser_id] = fn
        return fn
    return deco


def get_parser(parser_id: str) -> ParserFn:
    try:
        return _REGISTRY[parser_id]
    except KeyError as exc:
        raise KeyError(
            f"No parser registered for '{parser_id}'. "
            f"Available: {sorted(_REGISTRY)}") from exc


# -- Readers ----------------------------------------------------------------

def _read_csv(spark: SparkSession, path: str, source: SourceSpec) -> DataFrame:
    return (spark.read
            .option("header", str(source.parse.get("header", True)).lower())
            .option("delimiter", source.parse.get("delimiter", ","))
            .option("mode", "PERMISSIVE")
            .csv(path))


def _cell_to_str(value: Any) -> str | None:
    """Excel cell -> string, protecting identifiers and dates."""
    if value is None:
        return None
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, _dt.datetime):
        if (value.hour, value.minute, value.second) == (0, 0, 0):
            return value.strftime("%Y-%m-%d")
        return value.strftime("%Y-%m-%d %H:%M:%S")
    if isinstance(value, _dt.date):
        return value.isoformat()
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return repr(value)
    text = str(value).strip()
    return text or None


def _forward_fill(row: Sequence[Any]) -> list[str | None]:
    """Carry a merged header cell across the columns it visually spans."""
    out: list[str | None] = []
    last: str | None = None
    for cell in row:
        text = _cell_to_str(cell)
        if text:
            last = text
        out.append(last)
    return out


def _unique(names: Sequence[str | None]) -> list[str]:
    """Guarantee non-empty, unique, backtick-safe column names."""
    seen: Dict[str, int] = {}
    out: list[str] = []
    for i, raw in enumerate(names):
        name = (raw or f"__col_{i + 1}").replace("`", "").strip()
        name = name or f"__col_{i + 1}"
        if name in seen:
            seen[name] += 1
            name = f"{name} ({seen[name]})"
        else:
            seen[name] = 1
        out.append(name)
    return out


def _pick_sheet(sheet: Any, sheetnames: Sequence[str], path: str) -> str:
    """Resolve the configured ``sheet`` against a workbook's actual tabs."""
    if sheet is None:
        return sheetnames[0]
    candidates = sheet if isinstance(sheet, (list, tuple)) else [sheet]
    for candidate in candidates:
        if isinstance(candidate, bool):
            continue
        if isinstance(candidate, int):
            if -len(sheetnames) <= candidate < len(sheetnames):
                return sheetnames[candidate]
        elif candidate in sheetnames:
            return str(candidate)
    raise SheetNotFoundError(
        f"Sheet {sheet!r} not found in {path}. Available: {sheetnames}. "
        f"Set parse.sheet for this feed (a name, a 0-based index, or a list "
        f"of accepted names) in sources.yaml.")


def _read_xlsx(spark: SparkSession, path: str, source: SourceSpec) -> DataFrame:
    """Read one worksheet into a string dataframe keyed by its own headers."""
    from openpyxl import load_workbook

    content = (spark.read.format("binaryFile").load(path)
               .select("content").collect()[0]["content"])
    wb = load_workbook(BytesIO(content), read_only=True, data_only=True)
    try:
        ws = wb[_pick_sheet(source.parse.get("sheet"), wb.sheetnames, path)]

        header_rows: list[int] = [int(r) for r in (
            source.parse.get("header_rows")
            or [source.parse.get("header_row", 1)])]
        first_data_row = max(header_rows) + 1 + int(
            source.parse.get("skip_rows", 0))

        header_parts: list[list[str | None]] = []
        data: list[tuple] = []
        for idx, row in enumerate(ws.iter_rows(values_only=True), start=1):
            if idx in header_rows:
                header_parts.append(_forward_fill(row))
            elif idx >= first_data_row:
                data.append((idx, row))
    finally:
        wb.close()

    if not header_parts:
        raise ValueError(
            f"No header row found in {path}; expected row(s) {header_rows}.")

    width = max(len(p) for p in header_parts)
    combined: list[str | None] = []
    for c in range(width):
        parts = [p[c] for p in header_parts
                 if c < len(p) and p[c] not in (None, "")]
        # de-duplicate repeats caused by forward-filling identical rows
        deduped: list[str] = []
        for part in parts:
            if not deduped or deduped[-1] != part:
                deduped.append(part)
        combined.append(" ".join(deduped) if deduped else None)
    headers = _unique(combined)

    schema = T.StructType(
        [T.StructField(_ROW_COL, T.LongType(), True)]
        + [T.StructField(h, T.StringType(), True) for h in headers])
    rows = []
    for excel_row, values in data:
        cells = [_cell_to_str(v) for v in values[:width]]
        cells += [None] * (width - len(cells))
        if all(c is None for c in cells):  # drop fully blank rows
            continue
        rows.append(tuple([excel_row] + cells))
    return spark.createDataFrame(rows, schema)


# -- Complex-layout readers --------------------------------------------------

def _load_rows(spark: SparkSession, path: str,
               source: SourceSpec) -> list[list[Any]]:
    """Every worksheet row as a plain list, for the multi-row preamble readers."""
    from openpyxl import load_workbook

    content = (spark.read.format("binaryFile").load(path)
               .select("content").collect()[0]["content"])
    wb = load_workbook(BytesIO(content), read_only=True, data_only=True)
    try:
        ws = wb[_pick_sheet(source.parse.get("sheet"), wb.sheetnames, path)]
        return [list(r) for r in ws.iter_rows(values_only=True)]
    finally:
        wb.close()


def _period_pair(row: Sequence[Any]) -> tuple[str | None, str | None]:
    """Read the period start and end dates from the period row."""
    cells = [_cell_to_str(c) for c in row]
    start = end = None
    for i, c in enumerate(cells):
        key = (c or "").strip().lower()
        nxt = cells[i + 1] if i + 1 < len(cells) else None
        if key.startswith("period start"):
            start = nxt
        elif key.startswith("period end"):
            end = nxt
    return start, end


def _rows_to_df(spark: SparkSession, headers: Sequence[str | None],
                records: Sequence[tuple[int, Sequence[Any]]]) -> DataFrame:
    """Assemble the reader's string dataframe."""
    names = _unique(headers)
    width = len(names)
    schema = T.StructType(
        [T.StructField(_ROW_COL, T.LongType(), True)]
        + [T.StructField(h, T.StringType(), True) for h in names])
    out: list[tuple] = []
    for excel_row, cells in records:
        vals = [_cell_to_str(v) for v in list(cells)[:width]]
        vals += [None] * (width - len(vals))
        if all(v is None for v in vals):
            continue
        out.append(tuple([excel_row] + vals))
    return spark.createDataFrame(out, schema)


def _at(row: Sequence[Any], i: int) -> str | None:
    return _cell_to_str(row[i]) if i < len(row) else None


def _read_xlsx_relex_stock(spark: SparkSession, path: str,
                           source: SourceSpec) -> DataFrame:
    """RELEX 'Bayer Stock File' layout."""
    rows = _load_rows(spark, path, source)
    r3 = rows[2] if len(rows) > 2 else []
    r4 = rows[3] if len(rows) > 3 else []
    p_start, p_end = _period_pair(rows[1] if len(rows) > 1 else [])
    width = max(len(r3), len(r4))
    headers = [_at(r4, i) or _at(r3, i) for i in range(width)]
    records = [(i + 1, rows[i]) for i in range(5, len(rows))]  # skip rows 1-5
    df = _rows_to_df(spark, headers, records)
    return (df.withColumn("Period start date", F.lit(p_start))
              .withColumn("Period end date", F.lit(p_end)))


def _read_xlsx_bayer_weekly(spark: SparkSession, path: str,
                            source: SourceSpec) -> DataFrame:
    """Bayer weekly report layout."""
    rows = _load_rows(spark, path, source)
    r3 = _forward_fill(rows[2]) if len(rows) > 2 else []  # groups span 3 cols
    r4 = rows[3] if len(rows) > 3 else []
    r5 = rows[4] if len(rows) > 4 else []
    p_start, p_end = _period_pair(rows[1] if len(rows) > 1 else [])
    n_fixed = int(source.parse.get("fixed_column_count", 5))
    width = max(len(r3), len(r4), len(r5))
    headers: list[str | None] = []
    for i in range(width):
        if i < n_fixed:
            headers.append(_at(r4, i))  # dimension: name only
        else:
            metric = " ".join(p for p in (_at(r4, i), _at(r5, i)) if p)
            headers.append(" ".join(p for p in (r3[i] if i < len(r3) else None,
                                                metric) if p) or None)
    records = [(i + 1, rows[i]) for i in range(5, len(rows))]  # data from row 6
    df = _rows_to_df(spark, headers, records)
    return (df.withColumn("Period start date", F.lit(p_start))
              .withColumn("Period end date", F.lit(p_end)))


# -- Projections ------------------------------------------------------------

def _with_row_number(df: DataFrame) -> DataFrame:
    """Use the reader's physical row number when it supplied one."""
    if _ROW_COL in df.columns:
        return (df.withColumn("source_row_number",
                              F.col(_ROW_COL).cast("bigint"))
                  .drop(_ROW_COL))
    w = Window.orderBy(F.monotonically_increasing_id())
    return (df.coalesce(1)
              .withColumn("source_row_number", F.row_number().over(w).cast("bigint")))


def _file_headers(df: DataFrame) -> list[str]:
    """The file's own headers - the reader's row-number column is not one."""
    return [c for c in df.columns if c != _ROW_COL]


def _json_of(headers: Sequence[str]) -> Column:
    """Headers serialised as a JSON object keyed by the original header."""
    if not headers:
        return F.lit(None).cast("string")
    return F.to_json(F.struct(*[F.col(f"`{h}`").cast("string").alias(h)
                                for h in headers]))


def _project_mapped(df: DataFrame, source: SourceSpec,
                    ctx: ParseContext) -> ParseResult:
    """Ordinary feed: resolve the file's headers onto the bronze *_raw columns."""
    if source.layouts:
        resolution = drift.resolve_layout(
            _file_headers(df), list(source.layouts.values()),
            policy=ctx.policy, aliases=source.column_aliases,
            patterns=source.column_patterns, key_columns=ctx.key_columns,
            known_targets=ctx.known_targets)
    else:
        resolution = drift.resolve_headers(
            _file_headers(df), dict(source.parse.get("column_map", {})),
            policy=ctx.policy, aliases=source.column_aliases,
            patterns=source.column_patterns, key_columns=ctx.key_columns,
            known_targets=ctx.known_targets)

    matched = resolution.by_target
    selects: list[Column] = []
    for target in resolution.targets:
        m = matched.get(target)
        selects.append(F.col(f"`{m.source_header}`").cast("string").alias(target)
                       if m else F.lit(None).cast("string").alias(target))
    if ctx.policy.capture_unmapped:
        selects.append(_json_of(resolution.unmapped_headers)
                       .alias("unmapped_columns_raw"))
    keep = [F.col(_ROW_COL)] if _ROW_COL in df.columns else []
    return ParseResult(_with_row_number(df.select(*selects, *keep)), resolution)


def _project_weekly(df: DataFrame, source: SourceSpec,
                    ctx: ParseContext) -> ParseResult:
    """Rolling weekly report: fixed columns are renamed to *_raw."""
    resolution = drift.resolve_headers(
        _file_headers(df), dict(source.parse.get("fixed_column_map", {})),
        policy=ctx.policy, aliases=source.column_aliases,
        patterns=source.column_patterns, key_columns=ctx.key_columns,
        known_targets=ctx.known_targets, unmapped_expected=True)

    matched = resolution.by_target
    fixed_cols = [F.col(f"`{m.source_header}`").cast("string").alias(m.target)
                  for m in (matched.get(t) for t in resolution.targets) if m]
    dynamic = resolution.unmapped_headers
    resolution = resolution.with_events(drift.unrecognised_header_events(
        dynamic,
        [source.parse.get("week_header_pattern", ""),
         source.parse.get("total_header_pattern", "")],
        ctx.policy, what="weekly measure header"))

    keep = [F.col(_ROW_COL)] if _ROW_COL in df.columns else []
    out = df.select(*fixed_cols,
                    _json_of(dynamic).alias("weekly_measure_columns_raw"),
                    *keep)
    return ParseResult(_with_row_number(out), resolution)


# -- Parsers = reader + projection ------------------------------------------

@register_parser("delimited")
def parse_delimited(spark: SparkSession, path: str, source: SourceSpec,
                    ctx: Optional[ParseContext] = None) -> ParseResult:
    """Generic delimited file: resolve source headers to *_raw via column_map."""
    ctx = ctx or ParseContext.default(source)
    return _project_mapped(_read_csv(spark, path, source), source, ctx)


@register_parser("xlsx")
def parse_xlsx(spark: SparkSession, path: str, source: SourceSpec,
               ctx: Optional[ParseContext] = None) -> ParseResult:
    """Generic Excel workbook: same column_map contract as ``delimited``."""
    ctx = ctx or ParseContext.default(source)
    return _project_mapped(_read_xlsx(spark, path, source), source, ctx)


@register_parser("weekly_report")
def parse_weekly_report(spark: SparkSession, path: str, source: SourceSpec,
                        ctx: Optional[ParseContext] = None) -> ParseResult:
    """Rolling weekly report delivered as a delimited file."""
    ctx = ctx or ParseContext.default(source)
    return _project_weekly(_read_csv(spark, path, source), source, ctx)


@register_parser("xlsx_weekly_report")
def parse_xlsx_weekly_report(spark: SparkSession, path: str, source: SourceSpec,
                             ctx: Optional[ParseContext] = None) -> ParseResult:
    """Rolling weekly report delivered as an Excel workbook."""
    ctx = ctx or ParseContext.default(source)
    return _project_weekly(_read_xlsx(spark, path, source), source, ctx)


@register_parser("xlsx_stock_relex")
def parse_xlsx_stock_relex(spark: SparkSession, path: str, source: SourceSpec,
                           ctx: Optional[ParseContext] = None) -> ParseResult:
    """RELEX stock file: banner + period row + grouped headers + aggregate row."""
    ctx = ctx or ParseContext.default(source)
    return _project_mapped(_read_xlsx_relex_stock(spark, path, source), source, ctx)


@register_parser("xlsx_bayer_weekly")
def parse_xlsx_bayer_weekly(spark: SparkSession, path: str, source: SourceSpec,
                            ctx: Optional[ParseContext] = None) -> ParseResult:
    """Bayer weekly report: banner + period row + week-group/metric merged header."""
    ctx = ctx or ParseContext.default(source)
    return _project_weekly(_read_xlsx_bayer_weekly(spark, path, source), source, ctx)
