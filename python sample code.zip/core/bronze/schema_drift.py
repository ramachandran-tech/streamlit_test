"""Schema-drift tolerant header resolution for bronze."""
from __future__ import annotations

import difflib
import hashlib
import re
from dataclasses import dataclass, field, replace
from typing import Iterable, Mapping, Optional, Sequence

from ..config.models import LayoutSpec, SchemaDriftPolicy

# -- severities --------------------------------------------------------------
INFO, WARNING, ERROR = "INFO", "WARNING", "ERROR"
_SEVERITY_RANK = {INFO: 0, WARNING: 1, ERROR: 2}

# -- event vocabulary --------------------------------------------------------
RENAMED_COLUMN = "RENAMED_COLUMN"  # matched, but not by its configured header
MISSING_COLUMN = "MISSING_COLUMN"  # configured column absent from the file
NEW_COLUMN = "NEW_COLUMN"  # file header nothing claims
AMBIGUOUS_MATCH = "AMBIGUOUS_MATCH"  # refused: more than one plausible pairing
DUPLICATE_HEADER = "DUPLICATE_HEADER"  # same header twice in one file
UNKNOWN_TARGET = "UNKNOWN_TARGET"  # config maps to a column the table lacks
UNRECOGNISED_HEADER = "UNRECOGNISED_HEADER"  # dynamic header no pattern classifies

# -- match strategies (ladder order) -----------------------------------------
EXACT, NORMALIZED, QUALIFIER, PATTERN, FUZZY = (
    "EXACT", "NORMALIZED", "QUALIFIER", "PATTERN", "FUZZY")
LADDER = (EXACT, NORMALIZED, QUALIFIER, PATTERN, FUZZY)
_CONFIDENCE = {EXACT: 1.0, NORMALIZED: 0.98, QUALIFIER: 0.95, PATTERN: 0.90}

# candidate origins
_MAP, _ALIAS, _DERIVED = "map", "alias", "derived"


# -- normalisation ----------------------------------------------------------

def normalize_header(text: str) -> str:
    """Casefold + flatten punctuation so cosmetic header edits stop mattering."""
    s = (text or "").replace("﻿", "").replace(" ", " ")
    s = s.replace("'", "").replace("’", "").replace("´", "")
    s = re.sub(r"[^0-9a-z]+", " ", s.casefold())
    return " ".join(s.split())


def split_qualifiers(text: str,
                     patterns: Sequence[str]) -> tuple[str, list[str]]:
    """``"Sales Value (GBP)"`` -> ``("Sales Value ", ["GBP"])``."""
    base, quals = text or "", []
    for p in patterns:
        for m in re.finditer(p, base):
            g = (m.group(1) if m.groups() else m.group(0)).strip()
            if g:
                quals.append(g)
        base = re.sub(p, " ", base)
    return base, quals


def target_display_name(target: str) -> str:
    """``sales_value_raw`` -> ``sales value`` (the naming-convention candidate)."""
    stem = target[:-4] if target.endswith("_raw") else target
    return stem.replace("_", " ")


def header_fingerprint(headers: Sequence[str]) -> str:
    """Stable id for a file's layout - equal fingerprint = nothing to re-review."""
    joined = "|".join(normalize_header(h) for h in headers)
    return hashlib.sha256(joined.encode("utf-8")).hexdigest()[:32]


def _dedup(items: Iterable[str]) -> list[str]:
    """De-duplicate preserving first-seen order."""
    out, seen = [], set()
    for x in items:
        if x not in seen:
            seen.add(x)
            out.append(x)
    return out


# -- result model -----------------------------------------------------------

@dataclass(frozen=True)
class ColumnMatch:
    target: str
    source_header: str
    strategy: str
    origin: str  # map | alias | derived
    confidence: float
    qualifier: Optional[str] = None

    @property
    def is_drift(self) -> bool:
        """True when the file did not use the header config said it would."""
        return self.strategy != EXACT or self.origin != _MAP


@dataclass(frozen=True)
class DriftEvent:
    event_type: str
    severity: str
    detail: str
    target_column: Optional[str] = None
    source_header: Optional[str] = None
    matched_via: Optional[str] = None
    confidence: Optional[float] = None
    qualifier: Optional[str] = None


@dataclass(frozen=True)
class SchemaResolution:
    """What the ladder made of one file's header row."""

    matches: tuple[ColumnMatch, ...] = ()
    missing: tuple[str, ...] = ()
    unmapped_headers: tuple[str, ...] = ()
    events: tuple[DriftEvent, ...] = ()
    fingerprint: str = ""
    targets: tuple[str, ...] = ()
    # header-level view for the drift audit: configured headers no longer present
    missing_headers: tuple[str, ...] = ()
    additional_headers: tuple[str, ...] = ()
    drift_type: str = ""  # RENAMED | MISSING_COLUMNS | ADDITIONAL_COLUMNS
    # the declared layout this header row was resolved against (multi-layout feeds only)
    layout: Optional[str] = None

    # -- views ---------------------------------------------------------------
    @property
    def by_target(self) -> dict[str, ColumnMatch]:
        return {m.target: m for m in self.matches}

    @property
    def drifted_matches(self) -> tuple[ColumnMatch, ...]:
        return tuple(m for m in self.matches if m.is_drift)

    @property
    def status(self) -> str:
        """OK | WARNING | ERROR - the worst severity the file produced."""
        worst = max((_SEVERITY_RANK[e.severity] for e in self.events), default=-1)
        return {2: ERROR, 1: WARNING}.get(worst, "OK")

    @property
    def has_errors(self) -> bool:
        return any(e.severity == ERROR for e in self.events)

    @property
    def drifted(self) -> bool:
        return bool(self.events)

    @property
    def literal_drift(self) -> bool:
        """The file's header set differs from what config declared."""
        return bool(self.missing_headers or self.additional_headers)

    @property
    def file_header_count(self) -> int:
        """Distinct headers actually present in the file."""
        return len(self.matches) + len(self.unmapped_headers)

    def events_of(self, *types: str) -> tuple[DriftEvent, ...]:
        return tuple(e for e in self.events if e.event_type in types)

    def with_events(self, extra: Iterable[DriftEvent]) -> "SchemaResolution":
        return replace(self, events=self.events + tuple(extra))

    def summary(self) -> str:
        layout = f", layout {self.layout}" if self.layout else ""
        if not self.events:
            return f"schema OK ({len(self.matches)} columns{layout})"
        counts: dict[str, int] = {}
        for e in self.events:
            counts[e.event_type] = counts.get(e.event_type, 0) + 1
        body = ", ".join(f"{k.lower()}={v}" for k, v in sorted(counts.items()))
        return f"schema {self.status}: {body}{layout}"


# -- candidates -------------------------------------------------------------

@dataclass(frozen=True)
class _Candidate:
    target: str
    origin: str
    text: str
    norm: str = field(default="", compare=False)
    base_norm: str = field(default="", compare=False)


def _build_candidates(column_map: Mapping[str, str],
                      aliases: Mapping[str, Sequence[str]],
                      targets: Sequence[str],
                      qualifier_patterns: Sequence[str]) -> list[_Candidate]:
    raw: list[tuple[str, str, str]] = []
    for header, target in column_map.items():
        raw.append((target, _MAP, header))
    for target, names in (aliases or {}).items():
        for name in names or ():
            raw.append((target, _ALIAS, str(name)))
    for target in targets:
        raw.append((target, _DERIVED, target_display_name(target)))

    out: list[_Candidate] = []
    for target, origin, text in raw:
        if target not in targets:
            continue
        base, _ = split_qualifiers(text, qualifier_patterns)
        out.append(_Candidate(target, origin, text,
                              normalize_header(text), normalize_header(base)))
    return out


# -- the ladder -------------------------------------------------------------

def _claim(strategy: str, header: str, cand: _Candidate,
           norm: str, base: str, quals: Sequence[str],
           patterns: Mapping[str, str],
           policy: SchemaDriftPolicy) -> Optional[float]:
    """Confidence with which ``cand`` claims ``header`` under ``strategy``."""
    if strategy == EXACT:
        return _CONFIDENCE[EXACT] if header == cand.text else None
    if strategy == NORMALIZED:
        return _CONFIDENCE[NORMALIZED] if norm and norm == cand.norm else None
    if strategy == QUALIFIER:
        # only meaningful when a qualifier was actually dropped on either side
        if not base or base != cand.base_norm or norm == cand.norm:
            return None
        return _CONFIDENCE[QUALIFIER]
    if strategy == PATTERN:
        rx = (patterns or {}).get(cand.target)
        if not rx:
            return None
        try:
            hit = re.search(rx, header, re.IGNORECASE)
        except re.error:
            return None
        return _CONFIDENCE[PATTERN] if hit else None
    if strategy == FUZZY:
        if not base or not cand.base_norm:
            return None
        ratio = difflib.SequenceMatcher(None, base, cand.base_norm).ratio()
        return ratio if ratio >= policy.fuzzy_threshold else None
    return None


def _best_fuzzy(claims: Sequence[tuple[_Candidate, float]],
                margin: float) -> Optional[tuple[_Candidate, float]]:
    """Winner only if it is clearly ahead of the runner-up, else ambiguous."""
    best: dict[str, tuple[_Candidate, float]] = {}
    for cand, conf in claims:
        if conf > best.get(cand.target, (None, -1.0))[1]:
            best[cand.target] = (cand, conf)
    ranked = sorted(best.values(), key=lambda c: c[1], reverse=True)
    if len(ranked) == 1 or ranked[0][1] - ranked[1][1] >= margin:
        return ranked[0]
    return None


def resolve_headers(headers: Sequence[str],
                    column_map: Mapping[str, str],
                    *,
                    policy: SchemaDriftPolicy,
                    aliases: Optional[Mapping[str, Sequence[str]]] = None,
                    patterns: Optional[Mapping[str, str]] = None,
                    key_columns: Iterable[str] = (),
                    known_targets: Iterable[str] = (),
                    unmapped_expected: bool = False,
                    optional_targets: Iterable[str] = (),
                    parked_headers: Iterable[str] = ()) -> SchemaResolution:
    """Pair a file's header row with the configured bronze columns."""
    events: list[DriftEvent] = []
    keys = set(key_columns)
    known = set(known_targets)
    optional = set(optional_targets)
    qual_patterns = tuple(policy.qualifier_patterns)

    # -- de-duplicate the header row ----------------------------------------
    ordered: list[str] = []
    seen: set[str] = set()
    for h in headers:
        if h in seen:
            events.append(DriftEvent(
                DUPLICATE_HEADER, policy.severity_for(DUPLICATE_HEADER),
                f"header '{h}' appears more than once; only the first is used",
                source_header=h))
            continue
        seen.add(h)
        ordered.append(h)

    # parked headers sit out the ladder, so no column can claim them by a near match
    parked_norms = {normalize_header(p) for p in parked_headers}
    parked = {h for h in ordered if normalize_header(h) in parked_norms}

    # -- what we are looking for --------------------------------------------
    targets: list[str] = []
    for t in (list(column_map.values()) + list((aliases or {}).keys())
              + list((patterns or {}).keys())):
        if t not in targets:
            targets.append(t)
    orphaned: set[str] = set()  # headers left behind by a bad mapping
    if known:
        for t in list(targets):
            if t not in known:
                targets.remove(t)
                orphaned.update(h for h, tgt in column_map.items() if tgt == t)
                orphaned.update((aliases or {}).get(t, ()))
                events.append(DriftEvent(
                    UNKNOWN_TARGET, policy.severity_for(UNKNOWN_TARGET),
                    f"config maps to '{t}' which the bronze table does not "
                    f"have; its source header is captured as unmapped instead",
                    target_column=t))

    if not policy.enabled:
        # exact-only behaviour, still reported - the pre-drift contract
        strategies = (EXACT,)
    else:
        strategies = tuple(s for s in LADDER
                           if s.lower() in {x.lower() for x in policy.strategies})

    cands = _build_candidates(column_map, aliases or {}, targets, qual_patterns)
    norms = {h: normalize_header(h) for h in ordered}
    bases: dict[str, tuple[str, list[str]]] = {}
    for h in ordered:
        b, q = split_qualifiers(h, qual_patterns)
        bases[h] = (normalize_header(b), q)

    filled: dict[str, ColumnMatch] = {}
    consumed: set[str] = set()

    for strategy in strategies:
        # header -> [(candidate, confidence)]
        proposals: dict[str, list[tuple[_Candidate, float]]] = {}
        for h in ordered:
            if h in consumed or h in parked:
                continue
            base, quals = bases[h]
            hits = []
            for c in cands:
                if c.target in filled:
                    continue
                conf = _claim(strategy, h, c, norms[h], base, quals,
                              patterns or {}, policy)
                if conf is not None:
                    hits.append((c, conf))
            if hits:
                proposals[h] = hits

        # one header must resolve to exactly one column
        accepted: dict[str, tuple[_Candidate, float]] = {}
        for h, hits in proposals.items():
            distinct = {c.target for c, _ in hits}
            if len(distinct) == 1:
                accepted[h] = max(hits, key=lambda x: x[1])
            elif strategy == FUZZY:
                winner = _best_fuzzy(hits, policy.fuzzy_margin)
                if winner:
                    accepted[h] = winner
                else:
                    consumed.add(h)
                    events.append(DriftEvent(
                        AMBIGUOUS_MATCH, policy.severity_for(AMBIGUOUS_MATCH),
                        f"header '{h}' is a near match for "
                        f"{sorted(distinct)} - refusing to guess",
                        source_header=h, matched_via=strategy))
            else:
                consumed.add(h)
                events.append(DriftEvent(
                    AMBIGUOUS_MATCH, policy.severity_for(AMBIGUOUS_MATCH),
                    f"header '{h}' matches {sorted(distinct)} via {strategy} "
                    f"- refusing to guess",
                    source_header=h, matched_via=strategy))

        # ...and one column must be claimed by exactly one header
        per_target: dict[str, list[str]] = {}
        for h, (c, _) in accepted.items():
            per_target.setdefault(c.target, []).append(h)
        for target, hs in per_target.items():
            if len(hs) > 1:
                for h in hs:
                    consumed.add(h)
                events.append(DriftEvent(
                    AMBIGUOUS_MATCH, policy.severity_for(AMBIGUOUS_MATCH),
                    f"headers {sorted(hs)} all match '{target}' via {strategy} "
                    f"- refusing to guess",
                    target_column=target, matched_via=strategy))
                continue
            h = hs[0]
            cand, conf = accepted[h]
            matched_by = strategy
            if strategy == EXACT and cand.origin == _DERIVED:
                # a header may differ from the column's own name by case only
                declared = next((c for c in cands if c.target == target
                                 and c.origin != _DERIVED
                                 and c.norm == norms[h]), None)
                if declared is not None:
                    cand, conf, matched_by = (declared, _CONFIDENCE[NORMALIZED],
                                              NORMALIZED)
            _, quals = bases[h]
            filled[target] = ColumnMatch(
                target=target, source_header=h, strategy=matched_by,
                origin=cand.origin, confidence=round(float(conf), 4),
                qualifier="; ".join(quals) or None)
            consumed.add(h)

    # -- events for everything the ladder had to bend for --------------------
    for m in sorted(filled.values(), key=lambda x: x.target):
        if not m.is_drift:
            continue
        severity = policy.severity_for(
            RENAMED_COLUMN, key_column=m.target in keys,
            strategy=m.strategy, origin=m.origin)
        qual = f" qualifier='{m.qualifier}'" if m.qualifier else ""
        events.append(DriftEvent(
            RENAMED_COLUMN, severity,
            f"'{m.target}' matched header '{m.source_header}' via "
            f"{m.strategy}/{m.origin} (confidence {m.confidence}){qual}",
            target_column=m.target, source_header=m.source_header,
            matched_via=f"{m.strategy}/{m.origin}", confidence=m.confidence,
            qualifier=m.qualifier))

    missing = tuple(t for t in targets
                    if t not in filled and t not in optional)
    for t in missing:
        is_key = t in keys
        events.append(DriftEvent(
            MISSING_COLUMN, policy.severity_for(MISSING_COLUMN, key_column=is_key),
            f"no header in the file resolves to '{t}'"
            + (" (grain component)" if is_key else ""),
            target_column=t))

    unmapped = tuple(h for h in ordered if h not in consumed)
    if not unmapped_expected:
        # a header orphaned by an UNKNOWN_TARGET is already reported by it
        for h in (x for x in unmapped if x not in orphaned and x not in parked):
            events.append(DriftEvent(
                NEW_COLUMN, policy.severity_for(NEW_COLUMN),
                f"header '{h}' is not mapped by config"
                + (" - captured in unmapped_columns_raw"
                   if policy.capture_unmapped else " - dropped"),
                source_header=h))

    # an undeclared rename shows as one missing and one additional header
    col_key = {}
    for header, target in column_map.items():
        col_key.setdefault(target, header)
    renamed = [m for m in filled.values()
               if m.is_drift and m.origin != _ALIAS]
    missing_headers = _dedup(
        [col_key.get(m.target, m.target) for m in renamed]
        + [col_key.get(t, t) for t in missing])
    additional_src = [] if unmapped_expected \
        else [h for h in unmapped if h not in orphaned and h not in parked]
    additional_headers = _dedup([m.source_header for m in renamed] + additional_src)
    has_m, has_a = bool(missing_headers), bool(additional_headers)
    drift_type = ("RENAMED" if has_m and has_a
                  else "MISSING_COLUMNS" if has_m
                  else "ADDITIONAL_COLUMNS" if has_a else "")

    return SchemaResolution(
        matches=tuple(filled[t] for t in targets if t in filled),
        missing=missing, unmapped_headers=unmapped, events=tuple(events),
        fingerprint=header_fingerprint(ordered), targets=tuple(targets),
        missing_headers=tuple(missing_headers),
        additional_headers=tuple(additional_headers), drift_type=drift_type)


def resolve_layout(headers: Sequence[str],
                   layouts: Sequence[LayoutSpec],
                   *,
                   policy: SchemaDriftPolicy,
                   aliases: Optional[Mapping[str, Sequence[str]]] = None,
                   patterns: Optional[Mapping[str, str]] = None,
                   key_columns: Iterable[str] = (),
                   known_targets: Iterable[str] = ()) -> SchemaResolution:
    """Resolve a header row against every declared layout of its feed and keep the one that explains it best."""
    keys = set(key_columns)
    known = tuple(known_targets)
    best: Optional[tuple[tuple[int, int], SchemaResolution]] = None
    for layout in layouts:
        targets = set(layout.column_map.values())
        lay_aliases: dict[str, list[str]] = {
            t: list(names) for t, names in (aliases or {}).items()
            if t in targets}
        for t, names in layout.aliases.items():
            lay_aliases.setdefault(t, []).extend(names)
        lay_patterns = {t: rx for t, rx in (patterns or {}).items()
                        if t in targets}
        res = resolve_headers(
            headers, layout.column_map, policy=policy, aliases=lay_aliases,
            patterns=lay_patterns, key_columns=keys,
            known_targets=known, optional_targets=layout.optional_targets,
            parked_headers=layout.parked_headers)
        fit = (len(res.missing_headers) + len(res.additional_headers),
               -len(res.matches))
        if best is None or fit < best[0]:
            best = (fit, replace(res, layout=layout.layout_id))
    if best is None:
        raise ValueError("resolve_layout needs at least one layout")
    return best[1]


def unrecognised_header_events(headers: Iterable[str],
                               recognisers: Sequence[str],
                               policy: SchemaDriftPolicy,
                               what: str = "dynamic header") -> list[DriftEvent]:
    """Flag dynamic headers that no configured pattern classifies."""
    out: list[DriftEvent] = []
    for h in headers:
        if any(re.search(rx, h) for rx in recognisers if rx):
            continue
        out.append(DriftEvent(
            UNRECOGNISED_HEADER, policy.severity_for(UNRECOGNISED_HEADER),
            f"{what} '{h}' matches none of the configured patterns - its "
            f"values will not reach Silver",
            source_header=h))
    return out
