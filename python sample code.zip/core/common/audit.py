"""Ops control plane: file registry + run / DQ / reconciliation audit."""
from __future__ import annotations

import uuid
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Optional, Sequence

from pyspark.sql import DataFrame, Row, SparkSession
from pyspark.sql import functions as F
from pyspark.sql import types as T

from ..common.hashing import evolve_table
from ..config.models import PlatformConfig

FILE_REGISTRY = "ops.file_registry"
RUN_AUDIT = "ops.run_audit"
DQ_AUDIT = "ops.dq_audit"
RECON_AUDIT = "ops.reconciliation_audit"
DRIFT_AUDIT = "ops.schema_drift_audit"

_REGISTRY_SCHEMA = T.StructType([
    T.StructField("source_file_version_id", T.StringType(), False),
    T.StructField("entity", T.StringType(), False),
    T.StructField("source_file_name", T.StringType(), False),
    T.StructField("source_file_path", T.StringType(), False),
    T.StructField("file_received_ts", T.TimestampType(), False),
    T.StructField("schema_version", T.StringType(), False),
    T.StructField("is_partial", T.BooleanType(), False),
    T.StructField("bronze_status", T.StringType(), True),
    T.StructField("silver_status", T.StringType(), True),
    T.StructField("gold_status", T.StringType(), True),
    T.StructField("bronze_row_count", T.LongType(), True),
    T.StructField("silver_row_count", T.LongType(), True),
    T.StructField("last_ingestion_id", T.StringType(), True),
    T.StructField("schema_drift_status", T.StringType(), True),
    T.StructField("source_header_fingerprint", T.StringType(), True),
    # supersede rank: the higher priority wins, then the newer file
    T.StructField("supersede_priority", T.IntegerType(), True),
    # the date range a file replaces, for date-range feeds
    T.StructField("coverage_start_date", T.DateType(), True),
    T.StructField("coverage_end_date", T.DateType(), True),
    T.StructField("updated_at", T.TimestampType(), False),
])

# one summary row per drifted file, plus one row per finding
_DRIFT_SCHEMA = T.StructType([
    T.StructField("drift_event_id", T.StringType(), False),
    T.StructField("run_id", T.StringType(), False),
    T.StructField("entity", T.StringType(), False),
    T.StructField("source_file_version_id", T.StringType(), False),
    T.StructField("source_file_name", T.StringType(), True),
    T.StructField("table_name", T.StringType(), False),
    T.StructField("event_type", T.StringType(), False),
    T.StructField("severity", T.StringType(), False),
    # per-file summary fields
    T.StructField("expected_schema_version", T.StringType(), True),
    T.StructField("drift_type", T.StringType(), True),
    T.StructField("missing_columns", T.ArrayType(T.StringType()), True),
    T.StructField("additional_columns", T.ArrayType(T.StringType()), True),
    T.StructField("column_count", T.LongType(), True),
    T.StructField("action_taken", T.StringType(), True),
    # per-finding detail fields
    T.StructField("target_column", T.StringType(), True),
    T.StructField("source_header", T.StringType(), True),
    T.StructField("matched_via", T.StringType(), True),
    T.StructField("match_confidence", T.DoubleType(), True),
    T.StructField("column_qualifier", T.StringType(), True),
    T.StructField("header_fingerprint", T.StringType(), True),
    T.StructField("detail", T.StringType(), True),
    T.StructField("event_ts", T.TimestampType(), False),
])

_RUN_SCHEMA = T.StructType([
    T.StructField("run_id", T.StringType(), False),
    T.StructField("layer", T.StringType(), False),
    T.StructField("entity", T.StringType(), False),
    T.StructField("status", T.StringType(), False),
    T.StructField("row_count", T.LongType(), True),
    T.StructField("detail", T.StringType(), True),
    # which configuration produced this run (ConfigContext.config_fingerprint)
    T.StructField("config_fingerprint", T.StringType(), True),
    T.StructField("event_ts", T.TimestampType(), False),
])

_DQ_SCHEMA = T.StructType([
    T.StructField("dq_event_id", T.StringType(), False),
    T.StructField("run_id", T.StringType(), False),
    T.StructField("entity", T.StringType(), False),
    T.StructField("table_name", T.StringType(), False),
    T.StructField("rule_id", T.StringType(), False),
    T.StructField("severity", T.StringType(), False),
    T.StructField("failed_record_count", T.LongType(), True),
    T.StructField("detail", T.StringType(), True),
    T.StructField("event_ts", T.TimestampType(), False),
])

_RECON_SCHEMA = T.StructType([
    T.StructField("reconciliation_id", T.StringType(), False),
    T.StructField("run_id", T.StringType(), False),
    T.StructField("entity", T.StringType(), False),
    T.StructField("metric_name", T.StringType(), False),
    T.StructField("source_value", T.DoubleType(), True),
    T.StructField("target_value", T.DoubleType(), True),
    T.StructField("status", T.StringType(), False),
    T.StructField("detail", T.StringType(), True),
    T.StructField("event_ts", T.TimestampType(), False),
])


def _now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


@dataclass
class OpsStore:
    """Writer/reader over the ops schema."""

    spark: SparkSession
    cfg: PlatformConfig
    run_id: str
    config_fingerprint: str = ""  # ctx.config_fingerprint, stamped on runs

    # -- bootstrap ----------------------------------------------------------
    def ensure_tables(self) -> None:
        for logical, schema in ((FILE_REGISTRY, _REGISTRY_SCHEMA),
                                (RUN_AUDIT, _RUN_SCHEMA),
                                (DQ_AUDIT, _DQ_SCHEMA),
                                (RECON_AUDIT, _RECON_SCHEMA),
                                (DRIFT_AUDIT, _DRIFT_SCHEMA)):
            physical = self.cfg.resolve_table(logical)
            empty = self.spark.createDataFrame([], schema)
            writer = empty.write.format("delta").mode("ignore")
            location = self.cfg.table_location(logical)
            if location:  # external table under storage_root
                writer = writer.option("path", location)
            writer.saveAsTable(physical)
            # add any new columns to a pre-existing ops table
            evolve_table(self.spark, physical,
                         [(f.name, f.dataType.simpleString())
                          for f in schema.fields])

    # -- file registry -------------------------------------------------------
    def registry(self) -> DataFrame:
        return self.spark.table(self.cfg.resolve_table(FILE_REGISTRY))

    def upsert_registration(self, *, version_id: str, entity: str, name: str,
                            path: str, received_ts: datetime,
                            schema_version: str, is_partial: bool,
                            supersede_priority: int = 1) -> None:
        # createDataFrame pairs Row fields with the schema by position
        row = Row(source_file_version_id=version_id, entity=entity,
                  source_file_name=name, source_file_path=path,
                  file_received_ts=received_ts, schema_version=schema_version,
                  is_partial=is_partial, bronze_status=None, silver_status=None,
                  gold_status=None, bronze_row_count=None, silver_row_count=None,
                  last_ingestion_id=self.run_id, schema_drift_status=None,
                  source_header_fingerprint=None,
                  supersede_priority=int(supersede_priority),
                  coverage_start_date=None, coverage_end_date=None,
                  updated_at=_now())
        src = self.spark.createDataFrame([row], _REGISTRY_SCHEMA)
        src.createOrReplaceTempView("_reg_src")
        target = self.cfg.resolve_table(FILE_REGISTRY)
        self.spark.sql(f"""
            MERGE INTO {target} t
            USING _reg_src s
            ON t.source_file_version_id = s.source_file_version_id
            WHEN MATCHED THEN UPDATE SET
                t.source_file_path = s.source_file_path,
                t.last_ingestion_id = s.last_ingestion_id,
                t.updated_at = s.updated_at
            WHEN NOT MATCHED THEN INSERT *
        """)

    def set_layer_status(self, version_id: str, layer: str, status: str,
                         row_count: Optional[int] = None) -> None:
        target = self.cfg.resolve_table(FILE_REGISTRY)
        sets = [f"{layer}_status = '{status}'",
                f"last_ingestion_id = '{self.run_id}'",
                "updated_at = current_timestamp()"]
        if row_count is not None and layer in ("bronze", "silver"):
            sets.append(f"{layer}_row_count = {int(row_count)}")
        self.spark.sql(
            f"UPDATE {target} SET {', '.join(sets)} "
            f"WHERE source_file_version_id = '{version_id}'")

    def set_schema_drift(self, version_id: str, status: str,
                         fingerprint: str) -> None:
        """Stamp the delivery's header verdict onto its registry row."""
        target = self.cfg.resolve_table(FILE_REGISTRY)
        self.spark.sql(
            f"UPDATE {target} SET schema_drift_status = '{status}', "
            f"source_header_fingerprint = '{fingerprint}', "
            f"updated_at = current_timestamp() "
            f"WHERE source_file_version_id = '{version_id}'")

    def record_layout(self, version_id: str, schema_version: str,
                      supersede_priority: int) -> None:
        """Stamp the layout a multi-layout delivery was read as."""
        target = self.cfg.resolve_table(FILE_REGISTRY)
        self.spark.sql(
            f"UPDATE {target} SET schema_version = '{schema_version}', "
            f"supersede_priority = {int(supersede_priority)}, "
            f"updated_at = current_timestamp() "
            f"WHERE source_file_version_id = '{version_id}'")

    def record_coverage(self, version_id: str, start: date, end: date) -> None:
        """Stamp the date range a DATE_RANGE delivery replaces (inclusive)."""
        target = self.cfg.resolve_table(FILE_REGISTRY)
        self.spark.sql(
            f"UPDATE {target} SET coverage_start_date = DATE'{start.isoformat()}', "
            f"coverage_end_date = DATE'{end.isoformat()}', "
            f"updated_at = current_timestamp() "
            f"WHERE source_file_version_id = '{version_id}'")

    def pending_versions(self, entity: str, layer: str) -> list[Row]:
        """Versions the given layer still has to apply (the incremental frontier)."""
        prior = {"silver": "bronze_status", "gold": "silver_status"}[layer]
        own = f"{layer}_status"
        return (self.registry()
                .where((F.col("entity") == entity)
                       & (F.col(prior) == "APPLIED")
                       & (F.col(own).isNull() | (F.col(own) != "APPLIED")))
                .collect())

    # -- audit ---------------------------------------------------------------
    def run_event(self, layer: str, entity: str, status: str,
                  row_count: Optional[int] = None, detail: str = "") -> None:
        row = Row(run_id=self.run_id, layer=layer, entity=entity, status=status,
                  row_count=row_count, detail=detail[:4000],
                  config_fingerprint=self.config_fingerprint or None,
                  event_ts=_now())
        self.spark.createDataFrame([row], _RUN_SCHEMA).write.format("delta") \
            .mode("append").saveAsTable(self.cfg.resolve_table(RUN_AUDIT))

    def dq_event(self, entity: str, table_name: str, rule_id: str,
                 severity: str, failed: int, detail: str = "") -> None:
        row = Row(dq_event_id=str(uuid.uuid4()), run_id=self.run_id,
                  entity=entity, table_name=table_name, rule_id=rule_id,
                  severity=severity, failed_record_count=failed,
                  detail=detail[:4000], event_ts=_now())
        self.spark.createDataFrame([row], _DQ_SCHEMA).write.format("delta") \
            .mode("append").saveAsTable(self.cfg.resolve_table(DQ_AUDIT))

    def _drift_row(self, **over) -> Row:
        """A drift-audit Row with every column defaulted, in schema order."""
        base = dict(
            drift_event_id=str(uuid.uuid4()), run_id=self.run_id, entity="",
            source_file_version_id="", source_file_name=None, table_name="",
            event_type="", severity="INFO", expected_schema_version=None,
            drift_type=None, missing_columns=None, additional_columns=None,
            column_count=None, action_taken=None, target_column=None,
            source_header=None, matched_via=None, match_confidence=None,
            column_qualifier=None, header_fingerprint=None, detail=None,
            event_ts=_now())
        base.update(over)
        return Row(**{f.name: base[f.name] for f in _DRIFT_SCHEMA.fields})

    def drift_summary(self, entity: str, table_name: str, version_id: str,
                      file_name: str, fingerprint: str, schema_version: str,
                      drift_type: str, missing_columns: Sequence[str],
                      additional_columns: Sequence[str], column_count: int,
                      action_taken: str) -> None:
        """One per-file summary row: what drifted and what we did."""
        row = self._drift_row(
            entity=entity, table_name=table_name,
            source_file_version_id=version_id, source_file_name=file_name,
            event_type="FILE_SUMMARY", severity=action_taken,
            expected_schema_version=schema_version, drift_type=drift_type,
            missing_columns=list(missing_columns) or None,
            additional_columns=list(additional_columns) or None,
            column_count=int(column_count), action_taken=action_taken,
            header_fingerprint=fingerprint,
            detail=f"missing={list(missing_columns)} "
                   f"additional={list(additional_columns)}")
        self.spark.createDataFrame([row], _DRIFT_SCHEMA).write.format("delta") \
            .mode("append").saveAsTable(self.cfg.resolve_table(DRIFT_AUDIT))

    def drift_events(self, entity: str, table_name: str, version_id: str,
                     file_name: str, fingerprint: str,
                     events: Sequence[object]) -> None:
        """Persist one delivery's drift findings: per-finding rows to ops.schema_drift_audit."""
        if not events:
            return
        rows = [self._drift_row(
                    entity=entity, source_file_version_id=version_id,
                    source_file_name=file_name, table_name=table_name,
                    event_type=e.event_type, severity=e.severity,
                    target_column=e.target_column, source_header=e.source_header,
                    matched_via=e.matched_via,
                    match_confidence=(float(e.confidence)
                                      if e.confidence is not None else None),
                    column_qualifier=e.qualifier, header_fingerprint=fingerprint,
                    detail=str(e.detail)[:4000])
                for e in events]
        self.spark.createDataFrame(rows, _DRIFT_SCHEMA).write.format("delta") \
            .mode("append").saveAsTable(self.cfg.resolve_table(DRIFT_AUDIT))

        rollup: dict[tuple[str, str], int] = {}
        for e in events:
            if e.severity == "INFO":
                continue
            rollup[(e.event_type, e.severity)] = \
                rollup.get((e.event_type, e.severity), 0) + 1
        for (event_type, severity), n in sorted(rollup.items()):
            self.dq_event(entity, table_name, f"SCHEMA_DRIFT_{event_type}",
                          severity, n, f"file {file_name} "
                                       f"(header fingerprint {fingerprint})")

    def reconciliation(self, entity: str, metric: str, source_value: float,
                       target_value: float, tolerance: float = 1e-6,
                       detail: str = "") -> str:
        status = "PASS" if abs((source_value or 0) - (target_value or 0)) <= tolerance else "FAIL"
        row = Row(reconciliation_id=str(uuid.uuid4()), run_id=self.run_id,
                  entity=entity, metric_name=metric,
                  source_value=float(source_value or 0),
                  target_value=float(target_value or 0),
                  status=status, detail=detail[:4000], event_ts=_now())
        self.spark.createDataFrame([row], _RECON_SCHEMA).write.format("delta") \
            .mode("append").saveAsTable(self.cfg.resolve_table(RECON_AUDIT))
        return status
