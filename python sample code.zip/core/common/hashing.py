"""Deterministic hashing and Spark schema/DDL helpers."""
from __future__ import annotations

import re
from typing import Iterable, Mapping, Sequence

from pyspark.sql import Column, DataFrame, SparkSession
from pyspark.sql import functions as F

from ..config.models import ColumnSpec, PlatformConfig, TableSpec


class SchemaEvolutionError(RuntimeError):
    """A deployed table differs from its spec in a way that is not additive."""

# -- Deterministic keys -----------------------------------------------------

def sentinel(colname: str, sentinel_value: str) -> Column:
    """NULL-safe key component: NULL renders as a fixed sentinel string."""
    return F.coalesce(F.col(colname).cast("string"), F.lit(sentinel_value))


def deterministic_key(components: Sequence[Column]) -> Column:
    """SHA-256 over pipe-joined components - the platform's key convention."""
    return F.sha2(F.concat_ws("|", *components), 256)


def bk_hash_components(spec: TableSpec, sentinel_value: str) -> list[Column]:
    """Key components for a fact grain: null-safe columns render NULL as the sentinel."""
    cols: list[Column] = []
    for c in spec.bk_columns:
        if c.null_safe:
            cols.append(sentinel(c.name, sentinel_value))
        else:
            cols.append(F.col(c.name).cast("string"))
    return cols


def sentinel_flag(spec: TableSpec, sentinel_value: str) -> Column:
    """True when any null-safe grain component is NULL (drives the DQ WARNING)."""
    flags = [F.col(c.name).isNull() for c in spec.bk_columns if c.null_safe]
    if not flags:
        return F.lit(False)
    out = flags[0]
    for f_ in flags[1:]:
        out = out | f_
    return out


def row_hash(df_cols: Iterable[str]) -> Column:
    return F.sha2(F.concat_ws("|", *[
        F.coalesce(F.col(c).cast("string"), F.lit("\u0000")) for c in df_cols]), 256)


# -- Schema / DDL from TableSpec --------------------------------------------

def ddl_column(c: ColumnSpec) -> str:
    null_sql = "" if c.nullable else " NOT NULL"
    return f"`{c.name}` {c.type.upper()}{null_sql}"


def evolve_table(spark: SparkSession, physical: str,
                 wanted: Sequence[tuple[str, str]]) -> list[str]:
    """Add spec columns the deployed table lacks (nullable; never drops/retypes)."""
    try:
        existing = {f.name.lower() for f in spark.table(physical).schema.fields}
    except Exception:  # table not there yet
        return []
    missing = [(n, t) for n, t in wanted if n.lower() not in existing]
    if missing:
        cols = ", ".join(f"`{n}` {t.upper()}" for n, t in missing)
        spark.sql(f"ALTER TABLE {physical} ADD COLUMNS ({cols})")
    return [n for n, _ in missing]


def _normalize_type(t: str) -> str:
    """Compare Delta's rendered type to the spec's without whitespace noise."""
    return re.sub(r"\s+", "", str(t).lower())


def plan_schema_evolution(deployed: Mapping[str, str], spec: TableSpec,
                          mode: str, table_has_rows: bool) -> list[tuple[str, str]]:
    """Columns to ADD to reconcile a deployed table with its spec (pure, no Spark)."""
    if mode == "off":
        return []
    dep = {k.lower(): _normalize_type(v) for k, v in deployed.items()}
    adds: list[tuple[str, str]] = []
    conflicts: list[str] = []
    for c in spec.columns:
        key = c.name.lower()
        if key in dep:
            if dep[key] != _normalize_type(c.type):
                conflicts.append(
                    f"column '{c.name}' is {dep[key]} in the table but "
                    f"{c.type} in the spec (type change)")
        elif not c.nullable and table_has_rows:
            conflicts.append(
                f"new NOT NULL column '{c.name}' cannot be added to a table "
                f"that already holds rows (backfill, then migrate)")
        else:
            adds.append((c.name, c.type))
    spec_names = {c.name.lower() for c in spec.columns}
    extra = sorted(n for n in dep if n not in spec_names)

    if mode == "strict":
        problems = conflicts[:]
        if adds:
            problems.append(f"spec adds columns {sorted(n for n, _ in adds)}")
        if extra:
            problems.append(f"table has columns the spec dropped {extra}")
        if problems:
            raise SchemaEvolutionError(
                f"{spec.logical_name}: schema_evolution=strict and the table "
                f"differs from the spec - " + "; ".join(problems))
        return []

    if conflicts:  # additive
        raise SchemaEvolutionError(
            f"{spec.logical_name}: cannot evolve automatically - "
            + "; ".join(conflicts)
            + ". schema_evolution=additive only adds nullable columns; a type "
              "change, drop or non-null backfill is a deliberate migration. "
              "Migrate the table manually, or set schema_evolution=off to skip "
              "this check.")
    return adds


def plan_nullability_relaxation(not_null: Iterable[str], spec: TableSpec,
                                mode: str) -> list[str]:
    """Deployed NOT NULL columns the spec now allows NULL in (pure, no Spark)."""
    if mode == "off":
        return []
    wanted = {c.name.lower(): c for c in spec.columns}
    relax = [n for n in not_null
             if n.lower() in wanted and wanted[n.lower()].nullable]
    if relax and mode == "strict":
        raise SchemaEvolutionError(
            f"{spec.logical_name}: schema_evolution=strict and the spec now "
            f"allows NULL in {sorted(relax)}, which the table declares NOT NULL")
    return relax


def column_position(spec: TableSpec, name: str) -> str:
    """Where an added column goes so the table keeps the spec's column order."""
    names = spec.column_names
    i = names.index(name)
    return f"AFTER `{names[i - 1]}`" if i else "FIRST"


def reconcile_table_schema(spark: SparkSession, cfg: PlatformConfig,
                           spec: TableSpec) -> list[str]:
    """Bring an existing table up to its spec per cfg.schema_evolution."""
    mode = (cfg.schema_evolution or "additive").lower()
    if mode == "off":
        return []
    physical = cfg.resolve_table(spec.logical_name)
    try:
        fields = spark.table(physical).schema.fields
    except Exception:  # not created yet - nothing to do
        return []
    deployed = {f.name: f.dataType.simpleString() for f in fields}

    lower = {n.lower() for n in deployed}
    needs_rowcheck = any((not c.nullable) and c.name.lower() not in lower
                         for c in spec.columns)
    has_rows = bool(spark.table(physical).limit(1).count()) if needs_rowcheck \
        else False

    adds = plan_schema_evolution(deployed, spec, mode, has_rows)
    relax = plan_nullability_relaxation(
        [f.name for f in fields if not f.nullable], spec, mode)
    for n, t in adds:
        spark.sql(f"ALTER TABLE {physical} ADD COLUMNS "
                  f"(`{n}` {t.upper()} {column_position(spec, n)})")
        # ADD COLUMNS lands nullable; enforce NOT NULL where the spec wants it
        if not spec.column(n).nullable:
            spark.sql(f"ALTER TABLE {physical} ALTER COLUMN `{n}` SET NOT NULL")
    for n in relax:
        spark.sql(f"ALTER TABLE {physical} ALTER COLUMN `{n}` DROP NOT NULL")
    return [n for n, _ in adds]


def create_table_if_absent(spark: SparkSession, cfg: PlatformConfig,
                           spec: TableSpec, evolve: bool = True) -> str:
    """Create the table from its spec if missing, and evolve it if asked."""
    physical = cfg.resolve_table(spec.logical_name)
    location = cfg.table_location(spec.logical_name)
    cols = ",\n  ".join(ddl_column(c) for c in spec.columns)
    loc_sql = f"\nLOCATION '{location}'" if location else ""
    props_sql = (f"\nTBLPROPERTIES ('pipeline.key_recipe_version' = "
                 f"'{spec.key_recipe.name}')" if spec.key_recipe else "")
    spark.sql(f"CREATE TABLE IF NOT EXISTS {physical} (\n  {cols}\n) "
              f"USING DELTA{loc_sql}{props_sql}")
    if evolve:
        reconcile_table_schema(spark, cfg, spec)
    return physical


def ensure_schemas(spark: SparkSession, cfg: PlatformConfig) -> None:
    """Create the configured schemas that do not exist yet."""
    # layers may share one schema - handle each distinct schema once
    for schema in dict.fromkeys(cfg.schemas.values()):
        qualified = f"{cfg.catalog}.{schema}" if cfg.catalog else schema
        try:
            if spark.catalog.databaseExists(qualified):
                continue
        except Exception:  # older/limited catalog API
            pass
        loc = (f" MANAGED LOCATION '{cfg.storage_root.rstrip('/')}/{schema}'"
               if cfg.storage_root and cfg.catalog else "")
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS {qualified}{loc}")


def align_to_spec(df: DataFrame, spec: TableSpec) -> DataFrame:
    """Project/cast a dataframe to exactly the spec's columns, in order."""
    cols = []
    for c in spec.columns:
        if c.name in df.columns:
            cols.append(F.col(c.name).cast(c.type))
        else:
            cols.append(F.lit(None).cast(c.type).alias(c.name))
    return df.select(*cols)
