"""Move a landed file from incoming/ to archive/ after a successful bronze load."""
from __future__ import annotations

import shutil
from pathlib import Path
from urllib.parse import urlparse
from typing import Any


def _get_dbutils(spark: Any):
    """The cluster's dbutils when running on Databricks, else None (local)."""
    try:
        from pyspark.dbutils import DBUtils  # Databricks runtime only
        return DBUtils(spark)
    except Exception:
        return None


def _to_local(path: str) -> str:
    """A dbutils-style URI -> a local filesystem path for the shutil fallback."""
    if path.startswith("file:"):
        p = urlparse(path).path
        # Windows: "/C:/dir/f" -> "C:/dir/f"
        return p[1:] if len(p) > 2 and p[0] == "/" and p[2] == ":" else p
    if path.startswith("dbfs:"):
        return "/dbfs/" + path[len("dbfs:"):].lstrip("/")
    return path


def archive_file(spark: Any, src_path: str, archive_dir: str,
                 file_name: str) -> str:
    """Move one landed file from incoming into ``archive_dir``."""
    dst = f"{archive_dir.rstrip('/')}/{file_name}"
    db = _get_dbutils(spark)
    if db is not None:
        db.fs.mkdirs(archive_dir)
        db.fs.mv(src_path, dst, recurse=False)
        return dst
    # local fallback (tests / laptop): plain filesystem move
    src_local, dst_local = _to_local(src_path), _to_local(dst)
    Path(dst_local).parent.mkdir(parents=True, exist_ok=True)
    shutil.move(src_local, dst_local)
    return dst
