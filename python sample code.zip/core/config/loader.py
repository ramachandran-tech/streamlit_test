"""Load YAML config into the typed models."""
from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from pathlib import Path
from typing import Any, Mapping, Optional, Protocol

import yaml

from .models import (GOLD_VIEWS, OPS_TABLES, ColumnSpec, KeyRecipe, LayoutSpec,
                     LoadMode, PlatformConfig, ResolutionRule, RetiredFeed,
                     RuleStatus, SchemaDriftPolicy, SourceSpec, TableSpec)

# Drift bookkeeping columns appended to every bronze table at load time.
_DRIFT_COLUMNS: tuple[tuple[str, str, str], ...] = (
    ("unmapped_columns_raw", "string",
     "Headers present in the file that config does not map, as a JSON object"),
    ("schema_drift_status", "string",
     "OK | WARNING | ERROR for the delivery this row came from"),
    ("source_header_fingerprint", "string",
     "Hash of the file's normalised header row - equal = same layout"),
)


def _fingerprint(docs: Mapping[str, Any]) -> str:
    """Stable 32-char hash of the raw config docs (key-order independent)."""
    blob = json.dumps(docs, sort_keys=True, default=str, ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:32]


def _drift_columns(policy: SchemaDriftPolicy) -> list[ColumnSpec]:
    if not policy.enabled:
        return []
    wanted = _DRIFT_COLUMNS if policy.capture_unmapped else _DRIFT_COLUMNS[1:]
    return [ColumnSpec(name=n, type=t, nullable=True, column_class="audit",
                       source_table="Ingestion process (schema drift)",
                       source_column=doc)
            for n, t, doc in wanted]


class ConfigStore(Protocol):
    """Port: supplies the platform, sources and per-layer table documents."""

    def platform(self) -> Mapping[str, Any]: ...
    def sources(self) -> Mapping[str, Any]: ...
    def tables(self, layer: str) -> Mapping[str, Any]: ...


class YamlConfigStore:
    """Reads config from local YAML files under a root directory."""

    def __init__(self, root: str | Path) -> None:
        self._root = Path(root)
        if not (self._root / "platform.yaml").exists():
            raise FileNotFoundError(f"platform.yaml not found under {self._root}")

    def _load(self, rel: str) -> Mapping[str, Any]:
        with (self._root / rel).open() as f:
            return yaml.safe_load(f) or {}

    def platform(self) -> Mapping[str, Any]:
        return self._load("platform.yaml")

    def sources(self) -> Mapping[str, Any]:
        return self._load("sources.yaml")

    def tables(self, layer: str) -> Mapping[str, Any]:
        """One file per table under tables/<layer>/, merged into {"tables": {...}}."""
        layer_dir = self._root / "tables" / layer
        if layer_dir.is_dir():
            merged: dict[str, Any] = {}
            for path in sorted(layer_dir.glob("*.yaml")):
                doc = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
                for name, tspec in doc.items():
                    if name in merged:
                        raise ValueError(
                            f"table '{name}' defined twice under {layer_dir}")
                    merged[name] = tspec
            return {"tables": merged}
        return self._load(f"tables/{layer}.yaml")


class CosmosConfigStore:
    """Placeholder for a Cosmos-backed store; not implemented."""

    def __init__(self, *_: Any, **__: Any) -> None:
        raise NotImplementedError(
            "Cosmos config backend is not implemented. Implement the ConfigStore "
            "port against Cosmos, then set config_backend: cosmos in platform.yaml.")


def _column(spec: Mapping[str, Any]) -> ColumnSpec:
    return ColumnSpec(
        name=spec["name"],
        type=spec["type"],
        nullable=bool(spec.get("nullable", True)),
        pk=bool(spec.get("pk", False)),
        bk=bool(spec.get("bk", False)),
        null_safe=bool(spec.get("null_safe", False)),
        fk=spec.get("fk"),
        durable_ref=bool(spec.get("durable_ref", False)),
        supersede_scope=bool(spec.get("supersede_scope", False)),
        column_class=spec.get("column_class", "business"),
        key_role=spec.get("key_role", ""),
        source_table=spec.get("source_table"),
        source_column=spec.get("source_column"),
        source_header=spec.get("source_header"),
        bk_order=spec.get("bk_order"),
        date_format=spec.get("date_format"),
        transform=spec.get("transform"),
        column_role=spec.get("column_role"),
    )


def _key_recipe(doc: Optional[Mapping[str, Any]]) -> Optional[KeyRecipe]:
    if not doc:
        return None
    return KeyRecipe(name=str(doc["name"]),
                     columns=tuple(str(c) for c in doc.get("columns") or ()))


def _layout(layout_id: str, doc: Optional[Mapping[str, Any]]) -> LayoutSpec:
    doc = doc or {}
    return LayoutSpec(
        layout_id=layout_id,
        priority=int(doc.get("priority", 1)),
        standard=bool(doc.get("standard", False)),
        header_map=dict(doc.get("header_map") or {}),
        aliases={target: list(names or ())
                 for target, names in (doc.get("aliases") or {}).items()},
        optional_headers=tuple(doc.get("optional_headers") or ()),
        parked_headers=tuple(doc.get("parked_headers") or ()),
        date_format=doc.get("date_format"),
    )


class ConfigContext:
    """Loaded config, served as typed views to the rest of the platform."""

    def __init__(self, store: ConfigStore) -> None:
        self._store = store
        platform_doc = store.platform()
        sources_doc = store.sources()
        table_docs = {layer: store.tables(layer)
                      for layer in ("bronze", "silver", "gold")}
        self.platform = self._build_platform(platform_doc)
        self._sources = self._build_sources(sources_doc,
                                            self.platform.xlsx_defaults)
        self.resolution_rules = self._build_rules(sources_doc)
        self._retired = self._build_retired(sources_doc)
        clash = sorted(set(self._retired) & set(self._sources))
        if clash:
            raise ValueError(f"feeds both live and retired in sources.yaml: {clash}")
        self._tables: dict[str, TableSpec] = {}
        drift_cols = _drift_columns(self.platform.schema_drift)
        for layer in ("bronze", "silver", "gold"):
            for name, tdoc in (table_docs[layer].get("tables") or {}).items():
                cols = [_column(c) for c in tdoc["columns"]]
                if layer == "bronze":
                    have = {c.name for c in cols}
                    cols += [c for c in drift_cols if c.name not in have]
                self._tables[name] = TableSpec(
                    logical_name=name, columns=tuple(cols),
                    key_recipe=_key_recipe(tdoc.get("key_recipe")))
        self._derive_column_maps()
        # hash the raw config so a run can be traced back to what produced it
        self.config_fingerprint = _fingerprint(
            {"platform": platform_doc, "sources": sources_doc, **table_docs})
        # fail fast: safe prefixes, one physical table per logical table
        self.platform.assert_table_prefixes_valid()
        self.platform.assert_names_unique(
            list(self._tables) + list(OPS_TABLES) + list(GOLD_VIEWS))
        self.platform.assert_storage_root_usable()

    def _derive_column_maps(self) -> None:
        """Fill each feed's column_map from its bronze source_header."""
        for entity, source in list(self._sources.items()):
            bronze = self._tables.get(source.bronze_table)
            if bronze is None:
                continue
            key = ("fixed_column_map"
                   if "weekly" in str(source.parser)  # any weekly-report parser
                   else "column_map")
            parse = dict(source.parse)
            if not parse.get(key):  # feed set its own map: keep it
                derived = dict(bronze.source_header_map)
                derived.update(source.column_map_overrides)
                if derived:
                    parse.pop("column_map_overrides", None)
                    parse[key] = derived
            standard_map = dict(parse.get(key) or {})
            layouts = {
                layout_id: replace(layout, column_map=(
                    standard_map if layout.standard else dict(layout.header_map)))
                for layout_id, layout in source.layouts.items()}
            self._sources[entity] = replace(source, parse=parse,
                                            layouts=layouts)

    # -- factories -----------------------------------------------------------
    @staticmethod
    def from_yaml(root: str | Path) -> "ConfigContext":
        return ConfigContext(YamlConfigStore(root))

    # -- builders ------------------------------------------------------------
    @staticmethod
    def _build_platform(doc: Mapping[str, Any]) -> PlatformConfig:
        cal = doc.get("calendar", {})
        load = doc.get("load", {})
        return PlatformConfig(
            environment=doc.get("environment", "poc"),
            catalog=doc.get("catalog"),
            schemas=dict(doc["schemas"]),
            storage_root=doc.get("storage_root"),
            landing_root=doc["landing_root"],
            source_system=doc.get("source_system", "AAH"),
            key_null_sentinel=doc.get("key_null_sentinel", "__NULL__"),
            backdate_first_version_ts=doc.get(
                "backdate_first_version_ts", "1900-01-01T00:00:00"),
            date_input_formats=list(doc.get("date_input_formats", ["yyyy-MM-dd"])),
            boolean_true_values=[str(v).lower() for v in doc.get(
                "boolean_true_values", ["yes", "true", "1"])],
            boolean_false_values=[str(v).lower() for v in doc.get(
                "boolean_false_values", ["no", "false", "0"])],
            calendar_start=cal.get("start_date", "2023-01-01"),
            calendar_end=cal.get("end_date", "2028-12-31"),
            default_mode=LoadMode(load.get("default_mode", "incremental")),
            partial_file_marker=load.get("partial_file_marker", ".partial"),
            metric_types=list(doc.get("metric_types", [])),
            config_backend=doc.get("config_backend", "yaml"),
            table_prefixes={k: str(v or "") for k, v in
                            (doc.get("table_prefixes") or {}).items()},
            landing_layout=str(load.get("landing_layout", "subdir")).lower(),
            schema_evolution=str(doc.get("schema_evolution", "additive")).lower(),
            xlsx_defaults=dict(doc.get("xlsx") or {}),
            schema_drift=SchemaDriftPolicy.from_mapping(doc.get("schema_drift")),
            raw=dict(doc),
        )

    @staticmethod
    def _build_sources(doc: Mapping[str, Any],
                       xlsx_defaults: Mapping[str, Any] | None = None
                       ) -> dict[str, SourceSpec]:
        out: dict[str, SourceSpec] = {}
        for name, s in (doc.get("sources") or {}).items():
            parse = dict(s.get("parse") or {})
            if str(s.get("parser", "")).startswith("xlsx"):
                # platform xlsx defaults fill in only what the feed left unsaid
                parse = {**dict(xlsx_defaults or {}), **parse}
            # allow on_drift / fatal_if_missing at the feed top level too
            drift_over = dict(s.get("schema_drift", {}) or {})
            for k in ("on_drift", "fatal_if_missing"):
                if k in s and k not in drift_over:
                    drift_over[k] = s[k]
            active = s.get("active", True)
            if not isinstance(active, bool):
                # a quoted "no" is a string, not false: refuse it
                raise ValueError(f"sources.yaml {name}: active must be true or "
                                 f"false, got {active!r}")
            out[name] = SourceSpec(
                entity=s["entity"],
                source_system=s.get("source_system", "AAH"),
                bronze_table=s["bronze_table"],
                silver_table=s["silver_table"],
                parser=s.get("parser", "delimited"),
                landing_subdir=str(s.get("landing_subdir", "") or ""),
                file_glob=s.get("file_glob", "*.csv"),
                schema_version=s.get("schema_version", "v16"),
                source_name=s.get("source_name"),
                parse=parse,
                silver=dict(s.get("silver", {})),
                schema_drift=drift_over,
                layouts={layout_id: _layout(layout_id, ldoc) for layout_id, ldoc
                         in (s.get("layouts") or {}).items()},
                active=active,
            )
        return out

    @staticmethod
    def _build_retired(doc: Mapping[str, Any]) -> dict[str, RetiredFeed]:
        return {name: RetiredFeed(
                    entity=name,
                    source_system=r.get("source_system", "AAH"),
                    landing_subdir=str(r.get("landing_subdir", "") or ""),
                    file_glob=r["file_glob"],
                    reason=str(r.get("reason", "") or ""),
                    source_name=r.get("source_name"))
                for name, r in (doc.get("retired_feeds") or {}).items()}

    @staticmethod
    def _build_rules(doc: Mapping[str, Any]) -> list[ResolutionRule]:
        rules: list[ResolutionRule] = []
        for entity_type, items in (doc.get("resolution") or {}).items():
            for r in items:
                rules.append(ResolutionRule(
                    entity_type=entity_type,
                    rule_id=r["rule_id"],
                    status=RuleStatus(r.get("status", "PENDING")),
                    identifier_type=r["identifier_type"],
                    confidence=r.get("confidence", "UNMATCHED"),
                    description=r.get("description", ""),
                ))
        return rules

    # -- accessors -----------------------------------------------------------
    def source(self, entity: str) -> SourceSpec:
        return self._sources[entity]

    def sources(self) -> list[SourceSpec]:
        return list(self._sources.values())

    def retired_feeds(self) -> list[RetiredFeed]:
        """Feeds whose files are archived on arrival, never loaded."""
        return list(self._retired.values())

    def table(self, logical_name: str) -> TableSpec:
        return self._tables[logical_name]

    def tables_in_layer(self, layer: str) -> list[TableSpec]:
        return [t for n, t in self._tables.items() if n.startswith(layer + ".")]

    def rules_for(self, entity_type: str) -> list[ResolutionRule]:
        return [r for r in self.resolution_rules if r.entity_type == entity_type]
