"""Frozen config models for the platform, sources, tables and columns."""
from __future__ import annotations

import re
from dataclasses import dataclass, field, replace
from enum import Enum
from typing import Any, Iterable, Mapping, Optional, Sequence

# ops.* control-plane tables, validated alongside the catalogue tables.
OPS_TABLES = ("ops.file_registry", "ops.run_audit", "ops.dq_audit",
              "ops.reconciliation_audit", "ops.schema_drift_audit")

# gold views (core/gold/views.py); they share the tables' physical namespace
GOLD_VIEWS = ("gold.vw_sell_out_all_vendors",)

# Azure storage URI schemes accepted for a Unity Catalog external location.
_CLOUD_SCHEMES = ("abfss://", "abfs://", "wasbs://")

# a table-name prefix: empty, or letters, digits and underscores only
_PREFIX_RE = re.compile(r"[A-Za-z0-9_]*")


class LoadMode(str, Enum):
    INCREMENTAL = "incremental"
    HISTORICAL = "historical"


class RuleStatus(str, Enum):
    ACTIVE = "ACTIVE"
    PENDING = "PENDING"


@dataclass(frozen=True)
class ColumnSpec:
    name: str
    type: str
    nullable: bool
    pk: bool = False
    bk: bool = False
    null_safe: bool = False
    fk: Optional[str] = None
    durable_ref: bool = False
    supersede_scope: bool = False
    column_class: str = "business"  # business | audit
    key_role: str = ""
    source_table: Optional[str] = None
    source_column: Optional[str] = None
    # Exact header in the source file; the parser's column_map derives from it.
    source_header: Optional[str] = None
    # Position in the business key (the key hash is order-sensitive).
    bk_order: Optional[int] = None
    # Exact parse format for a date/timestamp column.
    date_format: Optional[str] = None
    # Notes carried from the source catalogue (reference only).
    transform: Optional[str] = None
    column_role: Optional[str] = None


@dataclass(frozen=True)
class KeyRecipe:
    """The named recipe a table's row key is hashed from."""

    name: str
    columns: tuple[str, ...] = ()


@dataclass(frozen=True)
class TableSpec:
    logical_name: str  # e.g. silver.daily_sales
    columns: Sequence[ColumnSpec]
    # None: the PK is the hash of the business key
    key_recipe: Optional[KeyRecipe] = None

    @property
    def layer(self) -> str:
        return self.logical_name.split(".", 1)[0]

    @property
    def table(self) -> str:
        return self.logical_name.split(".", 1)[1]

    def column(self, name: str) -> ColumnSpec:
        for c in self.columns:
            if c.name == name:
                return c
        raise KeyError(f"{self.logical_name}: no column '{name}'")

    @property
    def bk_columns(self) -> list[ColumnSpec]:
        """Business-key columns in key order (bk_order, else declaration order)."""
        bks = [(i, c) for i, c in enumerate(self.columns) if c.bk]
        bks.sort(key=lambda ic: (ic[1].bk_order if ic[1].bk_order is not None
                                 else len(self.columns) + ic[0], ic[0]))
        return [c for _, c in bks]

    @property
    def source_header_map(self) -> dict[str, str]:
        """Source header -> bronze column name."""
        return {c.source_header: c.name for c in self.columns if c.source_header}

    @property
    def pk_column(self) -> Optional[ColumnSpec]:
        for c in self.columns:
            if c.pk:
                return c
        return None

    @property
    def column_names(self) -> list[str]:
        return [c.name for c in self.columns]


@dataclass(frozen=True)
class SchemaDriftPolicy:
    """How bronze parsing reacts when a file's headers stop matching config."""

    enabled: bool = True
    strategies: Sequence[str] = ("exact", "normalized", "qualifier",
                                 "pattern", "fuzzy")
    fuzzy_threshold: float = 0.88
    fuzzy_margin: float = 0.05
    capture_unmapped: bool = True
    qualifier_patterns: Sequence[str] = (r"\(([^)]*)\)", r"\[([^\]]*)\]",
                                         r"\{([^}]*)\}")
    # severity per event: INFO | WARNING | ERROR
    on_renamed_column: str = "WARNING"
    on_normalized_match: str = "INFO"
    on_alias_match: str = "INFO"
    on_fuzzy_key_match: str = "ERROR"
    on_missing_column: str = "WARNING"
    on_missing_key_column: str = "ERROR"
    on_new_column: str = "WARNING"
    on_ambiguous_match: str = "ERROR"
    on_unknown_target: str = "WARNING"
    on_unrecognised_header: str = "WARNING"
    # drifted delivery action: warn (land it) | quarantine (skip) | fail (raise)
    on_drift: str = "warn"
    # columns whose absence always blocks the file (keys/PK added automatically)
    fatal_if_missing: Sequence[str] = ()
    # legacy, superseded by on_drift
    fail_on_error: bool = True

    def drift_action(self, blocking: bool) -> str:
        """WARN | QUARANTINE | FAIL; blocking = a fatal column is missing."""
        mode = (self.on_drift or "warn").lower()
        if blocking:
            return "QUARANTINE" if mode == "quarantine" else "FAIL"
        return {"fail": "FAIL", "quarantine": "QUARANTINE"}.get(mode, "WARN")

    _SEVERITY_FIELDS = {
        "NEW_COLUMN": "on_new_column",
        "AMBIGUOUS_MATCH": "on_ambiguous_match",
        "DUPLICATE_HEADER": "on_ambiguous_match",
        "UNKNOWN_TARGET": "on_unknown_target",
        "UNRECOGNISED_HEADER": "on_unrecognised_header",
    }

    def severity_for(self, event_type: str, *, key_column: bool = False,
                     strategy: Optional[str] = None,
                     origin: Optional[str] = None) -> str:
        if event_type == "MISSING_COLUMN":
            return self.on_missing_key_column if key_column \
                else self.on_missing_column
        if event_type == "RENAMED_COLUMN":
            if origin == "alias":
                return self.on_alias_match
            if strategy == "FUZZY" and key_column:
                return self.on_fuzzy_key_match
            if strategy == "NORMALIZED":
                return self.on_normalized_match
            return self.on_renamed_column
        return getattr(self, self._SEVERITY_FIELDS.get(event_type, ""),
                       "WARNING")

    def merged(self, overrides: Optional[Mapping[str, Any]]) -> "SchemaDriftPolicy":
        """Platform defaults + a per-source override block -> one policy."""
        if not overrides:
            return self
        fields = {f for f in self.__dataclass_fields__}          # noqa: SLF001
        kw = {k: v for k, v in overrides.items() if k in fields}
        for seq in ("strategies", "qualifier_patterns", "fatal_if_missing"):
            if seq in kw:
                kw[seq] = tuple(kw[seq])
        return replace(self, **kw)

    @staticmethod
    def from_mapping(doc: Optional[Mapping[str, Any]]) -> "SchemaDriftPolicy":
        return SchemaDriftPolicy().merged(doc)


@dataclass(frozen=True)
class ResolutionRule:
    entity_type: str  # product | account | stock_location | supplier
    rule_id: str
    status: RuleStatus
    identifier_type: str
    confidence: str
    description: str = ""

    @property
    def active(self) -> bool:
        return self.status is RuleStatus.ACTIVE


@dataclass(frozen=True)
class LayoutSpec:
    """One accepted header layout of a feed that arrives in more than one."""

    layout_id: str
    priority: int = 1
    standard: bool = False
    header_map: Mapping[str, str] = field(default_factory=dict)
    aliases: Mapping[str, Sequence[str]] = field(default_factory=dict)
    # headers this layout may or may not carry - absent is not drift
    optional_headers: Sequence[str] = ()
    # headers it carries that are deliberately not modelled: kept in unmapped_columns_raw
    parked_headers: Sequence[str] = ()
    date_format: Optional[str] = None
    # header -> bronze column used to resolve this layout
    column_map: Mapping[str, str] = field(default_factory=dict)

    @property
    def optional_targets(self) -> frozenset[str]:
        return frozenset(self.column_map[h] for h in self.optional_headers
                         if h in self.column_map)


@dataclass(frozen=True)
class SourceSpec:
    entity: str
    source_system: str
    bronze_table: str
    silver_table: str
    parser: str
    landing_subdir: str
    file_glob: str
    schema_version: str
    # Vendor folder under landing_root; defaults to source_system.
    source_name: Optional[str] = None
    parse: Mapping[str, Any] = field(default_factory=dict)
    silver: Mapping[str, Any] = field(default_factory=dict)
    schema_drift: Mapping[str, Any] = field(default_factory=dict)
    # layout id -> layout, for a feed delivered in more than one layout
    layouts: Mapping[str, LayoutSpec] = field(default_factory=dict)
    # False: configured but switched off - its tables are created
    active: bool = True

    def priority_of(self, layout_id: Optional[str]) -> int:
        """Supersede priority of a file in ``layout_id`` (1 for a single layout)."""
        layout = self.layouts.get(layout_id or "")
        return layout.priority if layout else 1

    @property
    def landing_source_name(self) -> str:
        """Vendor folder = source_name (or source_system), exactly as in YAML."""
        return (self.source_name or self.source_system or "").strip().strip("/")

    @property
    def scope_columns(self) -> list[str]:
        return list(self.silver.get("scope", []))

    @property
    def is_scd2_master(self) -> bool:
        return bool(self.silver.get("scd2", False))

    @property
    def column_map_overrides(self) -> Mapping[str, str]:
        """Header -> column overrides the source_header derivation can't cover."""
        return dict(self.parse.get("column_map_overrides", {}) or {})

    @property
    def column_aliases(self) -> Mapping[str, Sequence[str]]:
        """Alternative header spellings per bronze column."""
        return dict(self.parse.get("aliases", {}) or {})

    @property
    def column_patterns(self) -> Mapping[str, str]:
        """Per-column regex for headers whose text varies by delivery."""
        return dict(self.parse.get("patterns", {}) or {})

    def drift_policy(self, platform: "PlatformConfig") -> SchemaDriftPolicy:
        return platform.schema_drift.merged(self.schema_drift)

    def landing_path(self, platform: "PlatformConfig") -> str:
        """This feed's read folder."""
        return platform.landing_path(self)


@dataclass(frozen=True)
class RetiredFeed:
    """A feed the business no longer needs."""

    entity: str
    source_system: str
    landing_subdir: str
    file_glob: str
    reason: str = ""
    source_name: Optional[str] = None

    @property
    def landing_source_name(self) -> str:
        """Vendor folder, as for a live feed (SourceSpec.landing_source_name)."""
        return (self.source_name or self.source_system or "").strip().strip("/")


@dataclass(frozen=True)
class PlatformConfig:
    environment: str
    catalog: Optional[str]
    schemas: Mapping[str, str]  # logical layer -> physical schema
    storage_root: Optional[str]
    landing_root: str
    source_system: str
    key_null_sentinel: str
    backdate_first_version_ts: str
    date_input_formats: Sequence[str]
    boolean_true_values: Sequence[str]
    boolean_false_values: Sequence[str]
    calendar_start: str
    calendar_end: str
    default_mode: LoadMode
    partial_file_marker: str
    metric_types: Sequence[str]
    config_backend: str
    # logical layer -> table-name prefix ("bronze_"); lets layers share a schema.
    table_prefixes: Mapping[str, str] = field(default_factory=dict)
    landing_layout: str = "subdir"  # source_tree | subdir | flat
    # additive: ALTER ADD new nullable cols | strict: raise on any diff | off: skip
    schema_evolution: str = "additive"
    # workbook read defaults (sheet, header rows) folded into each xlsx feed.
    xlsx_defaults: Mapping[str, Any] = field(default_factory=dict)
    schema_drift: SchemaDriftPolicy = field(default_factory=SchemaDriftPolicy)
    raw: Mapping[str, Any] = field(default_factory=dict, repr=False)

    def physical_schema(self, layer: str) -> str:
        try:
            return self.schemas[layer]
        except KeyError as exc:
            raise KeyError(f"No schema mapping for layer '{layer}'") from exc

    def physical_table(self, logical_name: str) -> str:
        """'bronze.daily_sales' -> 'bronze_daily_sales' (the layer's prefix + table)."""
        layer, table = logical_name.split(".", 1)
        return f"{self.table_prefixes.get(layer, '')}{table}"

    def resolve_table(self, logical_name: str) -> str:
        """Logical name -> '[catalog.]schema.table'."""
        layer, _ = logical_name.split(".", 1)
        schema = self.physical_schema(layer)
        table = self.physical_table(logical_name)
        return f"{self.catalog}.{schema}.{table}" if self.catalog else f"{schema}.{table}"

    def table_location(self, logical_name: str) -> Optional[str]:
        # External-table folder layout: <storage_root>/<layer>/<source>/<table>
        if not self.storage_root:
            return None
        layer, _ = logical_name.split(".", 1)
        source = (self.source_system or "").strip().strip("/").lower()
        return (f"{self.storage_root.rstrip('/')}/{layer}/{source}"
                f"/{self.physical_table(logical_name)}")

    def _feed_base(self, source: "SourceSpec | RetiredFeed") -> str:
        """Feed folder <landing_root>/<source>/<landing_subdir> (holds incoming/, archive/)."""
        root = self.landing_root.rstrip("/")
        parts = [root, source.landing_source_name,
                 (source.landing_subdir or "").strip().strip("/")]
        return "/".join(p for p in parts if p)

    def landing_path(self, source: "SourceSpec | RetiredFeed") -> str:
        """Folder a feed's files are read from, per landing_layout."""
        root = self.landing_root.rstrip("/")
        if self.landing_layout == "flat":
            return root
        if self.landing_layout == "source_tree":
            return f"{self._feed_base(source)}/incoming"
        sub = (source.landing_subdir or "").strip().strip("/")
        return f"{root}/{sub}" if sub else root

    def archive_path(self, source: "SourceSpec | RetiredFeed") -> Optional[str]:
        """Where a file moves after bronze APPLIED (source_tree only, else None)."""
        if self.landing_layout != "source_tree":
            return None
        return f"{self._feed_base(source)}/archive"

    def assert_storage_root_usable(self) -> None:
        """Reject a storage_root Unity Catalog would refuse, before any DDL runs."""
        root = (self.storage_root or "").strip()
        if not root or root.startswith(_CLOUD_SCHEMES):
            return  # managed tables, or a cloud URI
        if root.startswith("/Volumes/") or root.startswith("dbfs:/Volumes/"):
            raise ValueError(
                f"storage_root '{root}' is a Volume - Volumes store files, not "
                f"tables. Leave storage_root null for managed tables, or set an "
                f"external location like "
                f"abfss://<container>@<account>.dfs.core.windows.net/o2c.")
        if self.catalog:
            raise ValueError(
                f"storage_root '{root}' has no cloud filesystem scheme. Use an "
                f"external location ({', '.join(_CLOUD_SCHEMES)}) or null.")

    def assert_table_prefixes_valid(self) -> None:
        """Reject a prefix that would break a table name, before any SQL runs."""
        problems = [f"'{layer}' is not a layer (schemas has {sorted(self.schemas)})"
                    for layer in self.table_prefixes if layer not in self.schemas]
        problems += [f"{layer}: '{prefix}' may hold only letters, digits and "
                     f"underscores" for layer, prefix in self.table_prefixes.items()
                     if not _PREFIX_RE.fullmatch(prefix)]
        if problems:
            raise ValueError("table_prefixes in platform.yaml: "
                             + "; ".join(problems))

    def assert_names_unique(self, logical_names: Iterable[str]) -> None:
        """Fail if two logical tables resolve to the same physical table."""
        seen: dict[str, str] = {}
        clashes: list[str] = []
        for name in logical_names:
            physical = self.resolve_table(name)
            if physical in seen:
                clashes.append(f"{seen[physical]} and {name} -> {physical}")
            seen[physical] = name
        if clashes:
            raise ValueError(
                "Table naming collision: " + "; ".join(clashes)
                + ". Set distinct table_prefixes per layer in platform.yaml.")
