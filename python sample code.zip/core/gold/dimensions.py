"""Gold dimensions: published from the silver references (identity is decided in silver)."""
from __future__ import annotations

import hashlib

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from ..common.audit import OpsStore
from ..common.hashing import align_to_spec, create_table_if_absent
from ..config.loader import ConfigContext

DIM_SOURCES = {
    "product": ("silver.product_reference", "gold.dim_product",
                "product_reference_version_id", "product_key",
                "product_business_key"),
    "account": ("silver.account_reference", "gold.dim_account",
                "account_reference_version_id", "account_key",
                "account_business_key"),
    "stock_location": ("silver.stock_location_reference",
                       "gold.dim_stock_location",
                       "stock_location_reference_version_id",
                       "stock_location_key", "stock_location_business_key"),
    "supplier": ("silver.supplier_reference", "gold.dim_supplier",
                 "supplier_reference_version_id", "supplier_key",
                 "supplier_business_key"),
}


def unknown_key(backdate_ts: str) -> str:
    """sha256('UNKNOWN|<backdate>') - the seeded member every dim carries."""
    return hashlib.sha256(f"UNKNOWN|{backdate_ts}".encode()).hexdigest()


class DimensionBuilder:
    def __init__(self, spark: SparkSession, ctx: ConfigContext,
                 ops: OpsStore) -> None:
        self.spark = spark
        self.ctx = ctx
        self.cfg = ctx.platform
        self.ops = ops

    # -- dim_date ------------------------------------------------------------
    def build_dim_date(self) -> int:
        spec = self.ctx.table("gold.dim_date")
        physical = create_table_if_absent(self.spark, self.cfg, spec)
        cal = (self.spark.sql(
            f"SELECT explode(sequence(to_date('{self.cfg.calendar_start}'), "
            f"to_date('{self.cfg.calendar_end}'), interval 1 day)) AS calendar_date")
            .withColumn("date_key",
                        F.date_format("calendar_date", "yyyyMMdd").cast("int"))
            .withColumn("year", F.year("calendar_date"))
            .withColumn("quarter", F.quarter("calendar_date"))
            .withColumn("month", F.month("calendar_date"))
            .withColumn("month_name", F.date_format("calendar_date", "MMMM"))
            .withColumn("year_month", F.date_format("calendar_date", "yyyy-MM"))
            .withColumn("week_start_date",
                        F.date_trunc("week", F.col("calendar_date")).cast("date"))
            .withColumn("week_end_date", F.date_add("week_start_date", 6))
            .withColumn("week_number", F.weekofyear("calendar_date"))
            .withColumn("week_year", F.year("week_start_date"))
            .withColumn("day_of_week", F.dayofweek("calendar_date"))
            .withColumn("day_name", F.date_format("calendar_date", "EEEE"))
            .withColumn("is_weekend", F.dayofweek("calendar_date").isin(1, 7)))
        aligned = align_to_spec(cal, spec)
        aligned.write.format("delta").mode("overwrite").saveAsTable(physical)
        return aligned.count()

    # -- SCD2 dims ------------------------------------------------------------
    def publish_dimension(self, entity_type: str) -> int:
        ref_table, dim_table, version_col, key_col, bk_col = DIM_SOURCES[entity_type]
        spec = self.ctx.table(dim_table)
        physical = create_table_if_absent(self.spark, self.cfg, spec)
        # ensure the reference exists too
        create_table_if_absent(self.spark, self.cfg, self.ctx.table(ref_table),
                               evolve=False)
        ref = self.spark.table(self.cfg.resolve_table(ref_table))
        now = F.current_timestamp()
        dim = (ref
               .withColumn(key_col, F.col(version_col))
               .withColumn("valid_from_ts", F.col("effective_from_ts"))
               .withColumn("valid_to_ts", F.col("effective_to_ts"))
               .withColumn("created_at", now)
               .withColumn("updated_at", now))
        aligned = align_to_spec(dim, spec)
        aligned.createOrReplaceTempView("_dim_src")
        upd = ", ".join(f"t.`{c}` = s.`{c}`" for c in spec.column_names
                        if c not in (key_col, "created_at"))
        self.spark.sql(f"""
            MERGE INTO {physical} t USING _dim_src s
            ON t.`{key_col}` = s.`{key_col}`
            WHEN MATCHED THEN UPDATE SET {upd}
            WHEN NOT MATCHED THEN INSERT *""")
        self._seed_unknown(entity_type)
        return aligned.count()

    def _seed_unknown(self, entity_type: str) -> None:
        _, dim_table, _, key_col, bk_col = DIM_SOURCES[entity_type]
        spec = self.ctx.table(dim_table)
        physical = self.cfg.resolve_table(dim_table)
        ukey = unknown_key(self.cfg.backdate_first_version_ts)
        exists = (self.spark.table(physical)
                  .where(F.col(key_col) == ukey).limit(1).count())
        if exists:
            return
        row = (self.spark.range(1)
               .withColumn(key_col, F.lit(ukey))
               .withColumn(bk_col, F.lit("UNKNOWN"))
               # UNKNOWN is unmatched; align_to_spec drops this for dims without it
               .withColumn("match_confidence", F.lit("UNMATCHED"))
               .withColumn("valid_from_ts", F.to_timestamp(
                   F.lit(self.cfg.backdate_first_version_ts)))
               .withColumn("valid_to_ts", F.lit(None).cast("timestamp"))
               .withColumn("is_current", F.lit(True))
               .withColumn("hash_diff", F.lit("UNKNOWN"))
               .withColumn("created_at", F.current_timestamp())
               .withColumn("updated_at", F.current_timestamp())
               .drop("id"))
        align_to_spec(row, spec).write.format("delta").mode("append") \
            .saveAsTable(physical)

    def run(self) -> None:
        n = self.build_dim_date()
        self.ops.run_event("gold", "dim_date", "SUCCESS", n)
        for entity_type in DIM_SOURCES:
            n = self.publish_dimension(entity_type)
            self.ops.run_event("gold", f"dim_{entity_type}", "SUCCESS", n)
