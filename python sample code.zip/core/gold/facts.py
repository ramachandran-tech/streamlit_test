"""Gold facts."""
from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import date
from typing import Mapping, Optional, Sequence

from pyspark.sql import DataFrame, SparkSession, Window
from pyspark.sql import functions as F

from ..common.audit import OpsStore
from ..common.hashing import align_to_spec, create_table_if_absent
from ..config.loader import ConfigContext
from ..config.models import LoadMode, TableSpec
from .dimensions import DIM_SOURCES, unknown_key


@dataclass(frozen=True)
class RefJoin:
    entity_type: str  # key into DIM_SOURCES
    ref_id_col: str  # silver durable ref column
    key_col: str  # gold dimension key column


@dataclass(frozen=True)
class UnknownKeyAlert:
    """Alert when too many lines with an identifier point at UNKNOWN."""

    rule_id: str
    max_share: float
    # dimension key column -> fact columns holding its identifiers
    identifiers: Mapping[str, tuple[str, ...]]


@dataclass(frozen=True)
class FactDef:
    entities: tuple[str, ...]  # registry entities driving incrementality
    silver_table: str
    gold_table: str
    pk_source: str  # silver PK column -> gold fact key
    asof_date_col: str  # fact date used for version resolution
    ref_joins: Sequence[RefJoin]
    scope_cols: Sequence[str]
    # rebuild each pending file's date range from silver
    by_coverage: bool = False
    unknown_key_alert: Optional[UnknownKeyAlert] = None


FACTS: list[FactDef] = [
    # AAH sales and not-supplied lines are separate facts on the same product
    FactDef(("daily_sales",), "silver.daily_sales", "gold.fact_daily_sales",
            "daily_sales_id", "business_date",
            (RefJoin("product", "product_ref_id", "product_key"),
             RefJoin("account", "account_ref_id", "account_key")),
            ("business_date",)),
    FactDef(("daily_sales_not_supplied",), "silver.daily_sales_not_supplied",
            "gold.fact_daily_sales_not_supplied",
            "daily_sales_not_supplied_id", "business_date",
            (RefJoin("product", "product_ref_id", "product_key"),
             RefJoin("account", "account_ref_id", "account_key")),
            ("business_date",)),
    # silver keeps one file's lines per invoice date
    FactDef(("williams_sales",), "silver.williams_sales",
            "gold.fact_williams_sales",
            "williams_sales_id", "invoice_date",
            (RefJoin("product", "product_ref_id", "product_key"),
             RefJoin("account", "account_ref_id", "account_key")),
            ("invoice_date",)),
    # Phoenix: the location is the Phoenix depot
    FactDef(("phoenix_sales",), "silver.phoenix_sales",
            "gold.fact_phoenix_sales",
            "phoenix_sales_id", "business_date",
            (RefJoin("product", "product_ref_id", "product_key"),
             RefJoin("account", "account_ref_id", "account_key"),
             RefJoin("stock_location", "stock_location_ref_id",
                     "stock_location_key")),
            ("business_date",),
            by_coverage=True,
            unknown_key_alert=UnknownKeyAlert(
                "PX-17_UNKNOWN_KEY_SHARE", 0.02,
                {"product_key": ("pip_code", "article_code"),
                 "account_key": ("customer_number",),
                 "stock_location_key": ("location_number",)})),
    FactDef(("stock_availability",), "silver.stock_availability",
            "gold.fact_stock_availability_snapshot",
            "stock_availability_id", "period_end_date",
            (RefJoin("product", "product_ref_id", "product_key"),
             RefJoin("stock_location", "stock_location_ref_id",
                     "stock_location_key"),
             RefJoin("supplier", "supplier_ref_id", "supplier_key")),
            ("period_end_date",)),
    FactDef(("weekly_report",), "silver.weekly_report_measure",
            "gold.fact_weekly_forecast_measure",
            "weekly_measure_id", "report_period_end_date",
            (RefJoin("product", "product_ref_id", "product_key"),
             RefJoin("stock_location", "stock_location_ref_id",
                     "stock_location_key"),
             RefJoin("supplier", "supplier_ref_id", "supplier_key")),
            ("report_period_end_date",)),
    FactDef(("weekly_report",), "silver.weekly_report_period_total",
            "gold.fact_weekly_forecast_period_total",
            "weekly_period_total_id", "report_period_end_date",
            (RefJoin("product", "product_ref_id", "product_key"),
             RefJoin("stock_location", "stock_location_ref_id",
                     "stock_location_key"),
             RefJoin("supplier", "supplier_ref_id", "supplier_key")),
            ("report_period_end_date",)),
]

# columns build_fact sets by hand; the generic mapping loop skips them
_SKIP = {"created_at", "updated_at", "reference_resolved_at",
         "source_file_version_id"}

REF_ID_COLS = {
    "product": "product_ref_id",
    "account": "account_ref_id",
    "stock_location": "stock_location_ref_id",
    "supplier": "supplier_ref_id",
}


class FactBuilder:
    def __init__(self, spark: SparkSession, ctx: ConfigContext,
                 ops: OpsStore) -> None:
        self.spark = spark
        self.ctx = ctx
        self.cfg = ctx.platform
        self.ops = ops
        self._unknown = unknown_key(self.cfg.backdate_first_version_ts)

    # -- helpers -------------------------------------------------------------
    @staticmethod
    def _silver_origin(spec_col, silver_spec: TableSpec) -> Optional[str]:
        """Resolve a gold column's silver source column from the catalogue text."""
        text = (spec_col.source_column or "").strip()
        if text in silver_spec.column_names:
            return text
        if spec_col.name in silver_spec.column_names:
            return spec_col.name
        tokens = re.findall(r"[a-z0-9_]+", text.lower())
        for t in tokens[::-1]:
            if t in silver_spec.column_names:
                return t
        return None

    def _asof_key(self, df: DataFrame, fd: FactDef, rj: RefJoin) -> DataFrame:
        ref_table, _, version_col, _, _ = DIM_SOURCES[rj.entity_type]
        ref = (self.spark.table(self.cfg.resolve_table(ref_table))
               .select(F.col(REF_ID_COLS[rj.entity_type]).alias("_rid"),
                       F.col(version_col).alias("_ver"),
                       F.col("effective_from_ts").alias("_from"),
                       F.col("effective_to_ts").alias("_to")))
        fact_ts = F.coalesce(F.col(fd.asof_date_col).cast("timestamp"),
                             F.current_timestamp())
        # one reference version per fact row; if history overlaps
        rid = F.monotonically_increasing_id()
        joined = (df.withColumn("_asof_row", rid).join(
                    ref,
                    (F.col(rj.ref_id_col) == ref["_rid"])
                    & (ref["_from"] <= fact_ts)
                    & (ref["_to"].isNull() | (ref["_to"] > fact_ts)),
                    "left"))
        pick = Window.partitionBy("_asof_row").orderBy(
            F.col("_to").desc_nulls_first(), F.col("_from").desc())
        return (joined.withColumn("_rn", F.row_number().over(pick))
                .where(F.col("_rn") == 1)
                .withColumn(rj.key_col,
                            F.coalesce(F.col("_ver"), F.lit(self._unknown)))
                .drop("_rid", "_ver", "_from", "_to", "_asof_row", "_rn"))

    @staticmethod
    def _in_ranges(col: str, ranges: Sequence[tuple[date, date]]) -> str:
        """SQL predicate: ``col`` falls in any of the inclusive date ranges."""
        return " OR ".join(
            f"(`{col}` BETWEEN DATE'{start.isoformat()}' AND "
            f"DATE'{end.isoformat()}')" for start, end in ranges)

    # -- per-fact ------------------------------------------------------------
    def build_fact(self, fd: FactDef, version_ids: list[str],
                   coverage: Sequence[tuple[date, date]] = ()) -> int:
        """Publish the pending silver lines of ``version_ids``."""
        silver_spec = self.ctx.table(fd.silver_table)
        gold_spec = self.ctx.table(fd.gold_table)
        physical = create_table_if_absent(self.spark, self.cfg, gold_spec)

        df = self.spark.table(self.cfg.resolve_table(fd.silver_table))
        if fd.by_coverage:
            if len(fd.scope_cols) != 1:
                raise ValueError(f"{fd.gold_table}: by_coverage needs exactly "
                                 f"one scope column, got {fd.scope_cols}")
            if not coverage:
                return 0
            in_range = self._in_ranges(fd.scope_cols[0], coverage)
            df = df.where(F.expr(in_range))
        else:
            df = df.where(F.col("source_file_version_id").isin(version_ids))
            if df.limit(1).count() == 0:
                return 0

        for rj in fd.ref_joins:
            df = self._asof_key(df, fd, rj)

        gold_key = gold_spec.pk_column.name
        exprs = [F.col(fd.pk_source).alias(gold_key)]
        for c in gold_spec.columns:
            if c.name in (gold_key, *_SKIP) or c.name in (
                    rj.key_col for rj in fd.ref_joins):
                continue
            origin = self._silver_origin(c, silver_spec)
            if origin:
                exprs.append(F.col(origin).cast(c.type).alias(c.name))
        exprs += [F.col(rj.key_col) for rj in fd.ref_joins]
        now = F.current_timestamp()
        out = (df.select(*exprs, F.col("source_file_version_id"))
                 .withColumn("reference_resolved_at", now)
                 .withColumn("created_at", now)
                 .withColumn("updated_at", now))
        out = align_to_spec(out, gold_spec)

        if fd.by_coverage:
            self.spark.sql(f"DELETE FROM {physical} WHERE {in_range}")
        else:
            scopes = out.select(*fd.scope_cols).distinct().collect()
            preds = []
            for s in scopes:
                conj = " AND ".join(
                    f"`{c}` = '{s[c]}'" if s[c] is not None else f"`{c}` IS NULL"
                    for c in fd.scope_cols)
                preds.append(f"({conj})")
            if preds:
                self.spark.sql(f"DELETE FROM {physical} WHERE {' OR '.join(preds)}")
        out.write.format("delta").mode("append").saveAsTable(physical)
        return out.count()

    def _check_unknown_keys(self, fd: FactDef) -> None:
        """Raise the fact's unknown-key alert when the share is too high."""
        alert = fd.unknown_key_alert
        if alert is None:
            return
        fact = self.spark.table(self.cfg.resolve_table(fd.gold_table))
        aggs = []
        for key_col, ident_cols in alert.identifiers.items():
            has_ident = F.lit(False)
            for c in ident_cols:
                has_ident = has_ident | F.col(c).isNotNull()
            unknown = has_ident & (F.col(key_col) == F.lit(self._unknown))
            aggs += [F.sum(has_ident.cast("long")).alias(f"{key_col}__with"),
                     F.sum(unknown.cast("long")).alias(f"{key_col}__unknown")]
        totals = fact.agg(*aggs).collect()[0]
        for key_col in alert.identifiers:
            with_ident = totals[f"{key_col}__with"] or 0
            unknown = totals[f"{key_col}__unknown"] or 0
            if with_ident and unknown / with_ident > alert.max_share:
                self.ops.dq_event(
                    fd.entities[0], fd.gold_table, alert.rule_id, "WARNING",
                    unknown,
                    f"{key_col}: {unknown} of {with_ident} line(s) carrying an "
                    f"identifier point at UNKNOWN ({unknown / with_ident:.1%}, "
                    f"alert above {alert.max_share:.0%}) - mapping backlog")

    # -- driver --------------------------------------------------------------
    def run(self, entities: Optional[list[str]] = None,
            mode: LoadMode = LoadMode.INCREMENTAL) -> None:
        wanted = set(entities) if entities else None
        for fd in FACTS:
            if wanted is not None and not (set(fd.entities) & wanted):
                continue
            vids: list[str] = []
            coverage: list[tuple[date, date]] = []
            for entity in fd.entities:
                if mode is LoadMode.HISTORICAL:
                    pend = (self.ops.registry()
                            .where((F.col("entity") == entity)
                                   & (F.col("silver_status") == "APPLIED"))
                            .collect())
                else:
                    pend = self.ops.pending_versions(entity, "gold")
                vids.extend(r["source_file_version_id"] for r in pend)
                # a file with no dated lines covers nothing
                coverage.extend(
                    (r["coverage_start_date"], r["coverage_end_date"])
                    for r in pend if r["coverage_start_date"] is not None)
            if not vids:
                self.ops.run_event("gold", fd.gold_table, "SKIPPED",
                                   detail="no pending versions")
                continue
            n = self.build_fact(fd, vids, coverage)
            for vid in vids:
                self.ops.set_layer_status(vid, "gold", "APPLIED")
            self.ops.run_event("gold", fd.gold_table, "SUCCESS", n)
            self._check_unknown_keys(fd)


