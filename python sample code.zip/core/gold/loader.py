"""Gold layer loader: publish dimensions first, then build facts as-of."""
from __future__ import annotations

from typing import Optional

from pyspark.sql import SparkSession

from ..common.audit import OpsStore
from ..config.loader import ConfigContext
from ..config.models import LoadMode
from .dimensions import DimensionBuilder
from .facts import FactBuilder
from .views import publish_views


class GoldLoader:
    def __init__(self, spark: SparkSession, ctx: ConfigContext,
                 ops: OpsStore) -> None:
        self.spark = spark
        self.ctx = ctx
        self.ops = ops
        self.dims = DimensionBuilder(spark, ctx, ops)
        self.facts = FactBuilder(spark, ctx, ops)

    def run(self, entities: Optional[list[str]] = None,
            mode: LoadMode = LoadMode.INCREMENTAL) -> None:
        self.dims.run()
        self.facts.run(entities, mode)
        for view in publish_views(self.spark, self.ctx):
            self.ops.run_event("gold", view, "SUCCESS", detail="view recreated")
