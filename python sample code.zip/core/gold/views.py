"""Gold views: read-only combinations of the gold facts."""
from __future__ import annotations

from pyspark.sql import SparkSession

from ..common.hashing import create_table_if_absent
from ..config.loader import ConfigContext

SELL_OUT_VIEW = "gold.vw_sell_out_all_vendors"
_SELL_OUT_FACTS = ("gold.fact_daily_sales", "gold.fact_williams_sales",
                   "gold.fact_phoenix_sales")


def _sell_out_sql(ctx: ConfigContext) -> str:
    """AAH, Williams and Phoenix sell-out at line grain, on one column contract."""
    t = ctx.platform.resolve_table
    return f"""
        CREATE OR REPLACE VIEW {t(SELL_OUT_VIEW)} (
            vendor, source_fact, source_fact_key, sale_date, product_key,
            product_ref_id, account_key, account_ref_id, sales_qty, sales_value,
            dq_status)
        COMMENT 'Combined AAH, Williams and Phoenix sell-out at line grain (UNION ALL of the three sell-out facts).'
        AS
        SELECT 'AAH', 'fact_daily_sales', daily_sales_key, business_date,
               product_key, product_ref_id, account_key, account_ref_id,
               CAST(volume AS DECIMAL(18,3)), CAST(sales_value AS DECIMAL(18,4)),
               dq_status
        FROM {t("gold.fact_daily_sales")}
        UNION ALL
        SELECT 'WILLIAMS', 'fact_williams_sales', williams_sales_key, invoice_date,
               product_key, product_ref_id, account_key, account_ref_id,
               CAST(sales_qty AS DECIMAL(18,3)), CAST(NULL AS DECIMAL(18,4)),
               dq_status
        FROM {t("gold.fact_williams_sales")}
        UNION ALL
        SELECT 'PHOENIX', 'fact_phoenix_sales', phoenix_sales_key, business_date,
               product_key, product_ref_id, account_key, account_ref_id,
               CAST(sales_qty AS DECIMAL(18,3)), CAST(sales_value AS DECIMAL(18,4)),
               dq_status
        FROM {t("gold.fact_phoenix_sales")}"""


def publish_views(spark: SparkSession, ctx: ConfigContext) -> list[str]:
    """(Re)create every gold view; returns their logical names."""
    for fact in _SELL_OUT_FACTS:
        create_table_if_absent(spark, ctx.platform, ctx.table(fact), evolve=False)
    spark.sql(_sell_out_sql(ctx))
    return [SELL_OUT_VIEW]
