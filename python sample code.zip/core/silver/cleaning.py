"""Type-driven cleaning: bronze ``*_raw`` strings -> typed silver columns."""
from __future__ import annotations

import re
from typing import Mapping, Optional, Sequence, Union

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F

from ..config.models import PlatformConfig, SourceSpec, TableSpec

_NUMERIC_JUNK = r"[£$€,\s]"
# what is left of a number once the junk above is stripped
_NUMBER = r"^[+-]?(\d+\.?\d*|\.\d+)([eE][+-]?\d+)?$"

# format of a typed Excel date cell, accepted for every layout
ISO_DATE = "yyyy-MM-dd"

# a PIP code is 7 digits
PIP_LENGTH = 7

# outward code (LS6, SW1A, B1) then inward code (2AB), spaces already removed
_UK_POST_CODE = r"^([A-Z]{1,2}[0-9][A-Z0-9]?)([0-9][A-Z]{2})$"

# silver columns that are computed rather than mapped 1:1 from a *_raw column
COMPUTED = {
    "line_occurrence", "row_hash", "dq_status", "dq_error_codes",
    "reference_resolved_at", "processed_at", "ingestion_id",
    "source_file_version_id", "source_file_name", "source_row_number",
}


def clean_string(col: Column) -> Column:
    return F.nullif(F.trim(col), F.lit(""))


# try_to_date returns NULL for an unparseable string
_try_to_date = getattr(F, "try_to_date", None)


def _parse_date(col: Column, fmt: str) -> Column:
    if _try_to_date is not None:
        return _try_to_date(col, fmt)
    return F.to_date(col, fmt)


def clean_date(col: Column, cfg: PlatformConfig,
               date_format: Union[str, Sequence[str], None] = None) -> Column:
    # a declared format is used on its own; otherwise try each global format
    if isinstance(date_format, str):
        fmts = [date_format]
    else:
        fmts = list(date_format or cfg.date_input_formats)
    return F.coalesce(*[_parse_date(F.trim(col), fmt) for fmt in fmts])


def layout_date(raw: Column, source: SourceSpec, cfg: PlatformConfig) -> Column:
    """A date parsed with the format of the layout its row arrived in."""
    parsed = clean_date(raw, cfg)
    for layout in source.layouts.values():
        if layout.date_format:
            parsed = F.when(
                F.col("schema_version") == layout.layout_id,
                clean_date(raw, cfg, [layout.date_format, ISO_DATE]),
            ).otherwise(parsed)
    return parsed


def clean_numeric(col: Column, target_type: str) -> Column:
    # cast only what looks like a number, so ANSI mode never fails the run
    stripped = F.regexp_replace(F.trim(col), _NUMERIC_JUNK, "")
    return F.when(stripped.rlike(_NUMBER), stripped.cast(target_type))


def clean_boolean(col: Column, cfg: PlatformConfig) -> Column:
    low = F.lower(F.trim(col))
    return (F.when(low.isin(*cfg.boolean_true_values), F.lit(True))
             .when(low.isin(*cfg.boolean_false_values), F.lit(False))
             .otherwise(F.lit(None).cast("boolean")))


def canonical_code(col: Column) -> Column:
    """pip_code_canonical rule: upper, trimmed, alphanumerics only, '' -> NULL."""
    canon = F.regexp_replace(F.upper(F.trim(col)), "[^A-Z0-9]", "")
    return F.nullif(canon, F.lit(""))


def canonical_pip(col: Column) -> Column:
    """A PIP code as the 7-digit code it is: dashes and spaces dropped."""
    code = canonical_code(col)
    return F.when(code.rlike(f"^[0-9]{{1,{PIP_LENGTH}}}$"),
                  F.lpad(code, PIP_LENGTH, "0"))


def uk_post_code(col: Column) -> Column:
    """Standard UK post code form, e.g. 'ls62ab' -> 'LS6 2AB'."""
    packed = F.regexp_replace(F.upper(col), r"\s+", "")
    return F.when(packed.rlike(_UK_POST_CODE),
                  F.regexp_replace(packed, _UK_POST_CODE, "$1 $2")) \
        .otherwise(clean_string(col))


def normalised_name(col: Column) -> Column:
    """Product-name match form: upper case, runs of whitespace collapsed to one space."""
    folded = F.trim(F.regexp_replace(F.upper(col), r"\s+", " "))
    return F.nullif(folded, F.lit(""))


def clean_for(col: Column, target_type: str, cfg: PlatformConfig,
              date_format: Union[str, Sequence[str], None] = None) -> Column:
    t = target_type.lower()
    if t == "date":
        return clean_date(col, cfg, date_format)
    if t.startswith(("decimal", "int", "bigint", "double", "float")):
        return clean_numeric(col, target_type)
    if t == "boolean":
        return clean_boolean(col, cfg)
    if t == "timestamp":
        return F.to_timestamp(F.trim(col))
    return clean_string(col)


def _raw_candidate(source_column: Optional[str]) -> Optional[str]:
    """Derive the single *_raw source column from the catalogue mapping text."""
    if not source_column:
        return None
    tokens = set(re.findall(r"[a-z0-9_]+_raw", source_column))
    return tokens.pop() if len(tokens) == 1 else None


def map_clean_columns(bronze_df: DataFrame, spec: TableSpec,
                      cfg: PlatformConfig,
                      overrides: Mapping[str, Column] | None = None,
                      keep: Sequence[str] = ()) -> DataFrame:
    """Project bronze onto the silver spec's business columns."""
    overrides = dict(overrides or {})
    exprs: list[Column] = []
    for c in spec.columns:
        if c.name in COMPUTED or c.column_class == "audit":
            continue
        if c.name in overrides:
            exprs.append(overrides[c.name].cast(c.type).alias(c.name))
            continue
        raw = f"{c.name}_raw" if f"{c.name}_raw" in bronze_df.columns \
            else _raw_candidate(c.source_column)
        if raw and raw in bronze_df.columns:
            exprs.append(
                clean_for(F.col(raw), c.type, cfg, c.date_format).alias(c.name))
        else:
            exprs.append(F.lit(None).cast(c.type).alias(c.name))
    passthrough = [f for f in ("source_file_version_id", "source_file_name",
                               "source_row_number", "ingestion_id", *keep)
                   if f in bronze_df.columns]
    return bronze_df.select(*exprs, *passthrough)
