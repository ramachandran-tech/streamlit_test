"""Deterministic keys, line_occurrence, and the sentinel DQ rule."""
from __future__ import annotations

from pyspark.sql import DataFrame, Window
from pyspark.sql import functions as F

from ..common.hashing import bk_hash_components, sentinel, sentinel_flag
from ..config.models import PlatformConfig, TableSpec

SENTINEL_RULE_PREFIX = "DQ_SENTINEL_"


def add_line_occurrence(df: DataFrame, spec: TableSpec,
                        cfg: PlatformConfig) -> DataFrame:
    """ROW_NUMBER within a file version, partitioned by the business key."""
    partition_cols = [sentinel(c.name, cfg.key_null_sentinel)
                      for c in spec.bk_columns if c.name != "line_occurrence"]
    w = (Window.partitionBy(F.col("source_file_version_id"), *partition_cols)
               .orderBy(F.col("source_row_number").asc_nulls_last()))
    return df.withColumn("line_occurrence", F.row_number().over(w).cast("int"))


def add_primary_key(df: DataFrame, spec: TableSpec,
                    cfg: PlatformConfig) -> DataFrame:
    """PK = hash of the business key."""
    pk = spec.pk_column
    if pk is None:
        return df
    if spec.key_recipe and spec.key_recipe.columns:
        parts = [sentinel(c, cfg.key_null_sentinel)
                 for c in spec.key_recipe.columns]
    else:
        parts = bk_hash_components(spec, cfg.key_null_sentinel)
    return df.withColumn(pk.name, F.sha2(F.concat_ws("|", *parts), 256))


def add_sentinel_dq(df: DataFrame, spec: TableSpec, cfg: PlatformConfig,
                    alert_cols: list[str] | None = None) -> DataFrame:
    """WARNING + rule ids when a null-safe key component was sentinel-keyed."""
    watch = [c for c in spec.bk_columns if c.null_safe
             and (alert_cols is None or c.name in alert_cols)]
    if not watch:
        return (df.withColumn("dq_error_codes",
                              F.lit(None).cast("array<string>"))
                  .withColumn("dq_status", F.lit("PASS")))
    codes = F.array_compact(F.array(*[
        F.when(F.col(c.name).isNull(),
               F.lit(f"{SENTINEL_RULE_PREFIX}{c.name.upper()}"))
        for c in watch]))
    flag = watch[0].name and F.col(watch[0].name).isNull()
    for c in watch[1:]:
        flag = flag | F.col(c.name).isNull()
    return (df.withColumn("dq_error_codes",
                          F.when(flag, codes).otherwise(F.lit(None).cast("array<string>")))
              .withColumn("dq_status",
                          F.when(flag, F.lit("WARNING")).otherwise(F.lit("PASS"))))
