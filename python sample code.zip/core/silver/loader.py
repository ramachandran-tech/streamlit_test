"""Silver layer loader."""
from __future__ import annotations

from dataclasses import replace
from datetime import date, datetime
from typing import Any, Callable, Mapping, Optional, Sequence

from pyspark.sql import Column, DataFrame, Row, SparkSession, Window
from pyspark.sql import functions as F

from ..common.audit import OpsStore
from ..common.hashing import align_to_spec, create_table_if_absent, row_hash
from ..config.loader import ConfigContext
from ..config.models import LoadMode, SourceSpec, TableSpec
from . import cleaning, keys, phoenix, row_rules, weekly, williams
from .references import REFERENCE_DEFS, ReferenceBuilder
from .scd2 import Scd2Def, apply_scd2
from .supersede import FileRank, claim_scopes

# Plain fact entities, in load order (the others have their own loaders)
FACT_ORDER = ["daily_sales", "daily_sales_not_supplied", "stock_availability"]

# The two AAH daily feeds: same columns and matching rules
AAH_DAILY_FEEDS = ("daily_sales", "daily_sales_not_supplied")

# SCD2 master templates.
_MASTER_TEMPLATES: Mapping[str, Scd2Def] = {
    "wholesale_product_master": Scd2Def(
        entity="product",
        version_id_col="product_version_id",
        ref_id_col="product_ref_id",
        business_key_cols=(),  # <- filled from the spec
        attribute_cols=["pip_code", "sku", "product_name",
                        "iqvia_scm_weekly_product_name", "williams_product_name",
                        "bu", "aah_product_code"]),
}


def _sql_literal(value: Any) -> str:
    """A scope value written as a Spark SQL literal, for a DELETE predicate."""
    if isinstance(value, datetime):
        return f"TIMESTAMP'{value:%Y-%m-%d %H:%M:%S}'"
    if isinstance(value, date):
        return f"DATE'{value.isoformat()}'"
    text = str(value).replace("\\", "\\\\").replace("'", "\\'")
    return f"'{text}'"


class SilverLoader:
    def __init__(self, spark: SparkSession, ctx: ConfigContext,
                 ops: OpsStore) -> None:
        self.spark = spark
        self.ctx = ctx
        self.cfg = ctx.platform
        self.ops = ops
        self.refs = ReferenceBuilder(spark, ctx)

    # -- utils ----------------------------------------------------------------
    def _bronze_rows(self, source: SourceSpec,
                     version_ids: list[str]) -> DataFrame:
        df = self.spark.table(self.cfg.resolve_table(source.bronze_table))
        return df.where(F.col("source_file_version_id").isin(version_ids))

    def _pending(self, source: SourceSpec, mode: LoadMode) -> list:
        if mode is LoadMode.HISTORICAL:
            return (self.ops.registry()
                    .where((F.col("entity") == source.entity)
                           & (F.col("bronze_status") == "APPLIED")).collect())
        return self.ops.pending_versions(source.entity, "silver")

    def _attach_ref(self, df: DataFrame, resolver: DataFrame, ident_col: str,
                    ref_col: str) -> DataFrame:
        r = resolver.withColumnRenamed("_ident", f"_i_{ref_col}") \
                    .withColumnRenamed("_ref", f"_r_{ref_col}")
        out = df.join(r, df[ident_col] == r[f"_i_{ref_col}"], "left")
        existing = F.col(ref_col) if ref_col in df.columns else F.lit(None).cast("string")
        return (out.withColumn(ref_col, F.coalesce(existing, F.col(f"_r_{ref_col}")))
                   .drop(f"_i_{ref_col}", f"_r_{ref_col}"))

    def _finalize(self, df: DataFrame, spec: TableSpec,
                  alert_cols: Optional[list[str]] = None) -> DataFrame:
        df = keys.add_line_occurrence(df, spec, self.cfg) \
            if "line_occurrence" in spec.column_names else df
        df = keys.add_primary_key(df, spec, self.cfg)
        df = keys.add_sentinel_dq(df, spec, self.cfg, alert_cols) \
            if "dq_status" in spec.column_names else df
        business = [c.name for c in spec.columns
                    if c.column_class == "business" and c.name in df.columns]
        now = F.current_timestamp()
        df = (df.withColumn("row_hash", row_hash(business))
                .withColumn("reference_resolved_at", now)
                .withColumn("processed_at", now))
        return align_to_spec(df, spec)

    def _scoped_write(self, df: DataFrame, spec: TableSpec,
                      scope_cols: list[str], is_partial: bool,
                      entity: str) -> int:
        physical = create_table_if_absent(self.spark, self.cfg, spec)
        n = df.count()
        if n == 0:
            return 0
        if is_partial:
            # partial files may only upsert - never delete a scope
            pk = spec.pk_column.name
            df.createOrReplaceTempView("_partial_src")
            set_cols = ", ".join(f"t.`{c}` = s.`{c}`"
                                 for c in spec.column_names if c != pk)
            self.spark.sql(f"""
                MERGE INTO {physical} t USING _partial_src s
                ON t.`{pk}` = s.`{pk}`
                WHEN MATCHED THEN UPDATE SET {set_cols}
                WHEN NOT MATCHED THEN INSERT *""")
            self.ops.dq_event(entity, spec.logical_name, "PARTIAL_FILE_MERGE",
                              "WARNING", n, "partial delivery merged by key")
            return n
        scopes = df.select(*scope_cols).distinct().collect()
        preds = []
        for s in scopes:
            conj = " AND ".join(
                f"`{c}` = '{s[c]}'" if s[c] is not None else f"`{c}` IS NULL"
                for c in scope_cols)
            preds.append(f"({conj})")
        if preds:
            self.spark.sql(f"DELETE FROM {physical} WHERE {' OR '.join(preds)}")
        df.write.format("delta").mode("append").saveAsTable(physical)
        return n

    def _sentinel_dq_events(self, df: DataFrame, spec: TableSpec,
                            entity: str) -> None:
        """One ops.dq_audit row per WARNING rule, with how many rows hit it."""
        warned = (df.where(F.col("dq_status") == "WARNING")
                    .select(F.explode("dq_error_codes").alias("rule"))
                    .groupBy("rule").count().collect())
        for r in warned:
            detail = ("null-safe grain component sentinel-keyed"
                      if r["rule"].startswith(keys.SENTINEL_RULE_PREFIX)
                      else "row-level rule; rows kept with dq_status WARNING")
            self.ops.dq_event(entity, spec.logical_name, r["rule"], "WARNING",
                              r["count"], detail)

    def _ranked_scope_write(self, df: DataFrame, spec: TableSpec,
                            scope_col: str, incoming: FileRank,
                            scopes: Optional[Sequence[Any]] = None
                            ) -> tuple[int, list, list, dict[str, int]]:
        """Write ``df`` scope by scope, each scope kept by its best-ranked file."""
        physical = create_table_if_absent(self.spark, self.cfg, spec)
        if scopes is None:
            scopes = [r[0] for r in df.select(scope_col).distinct().collect()]
        scopes = list(scopes)
        if not scopes:
            return 0, [], [], {}
        if None in scopes:
            raise ValueError(f"{spec.logical_name}: a row with no {scope_col} "
                             f"belongs to no scope - reject it before writing")
        ranks = self.ops.registry().select(
            "source_file_version_id", "supersede_priority", "file_received_ts")
        held = (self.spark.table(physical)
                .where(F.col(scope_col).isin(scopes))
                .groupBy(scope_col, "source_file_version_id").count()
                .join(ranks, "source_file_version_id", "left")
                .collect())
        holders: dict[Any, list[FileRank]] = {}
        for h in held:
            holders.setdefault(h[scope_col], []).append(FileRank(
                h["supersede_priority"] or 1,
                h["file_received_ts"] or datetime.min,
                h["source_file_version_id"]))
        won, lost = claim_scopes(incoming, scopes, holders)

        replaced: dict[str, int] = {}
        for h in held:
            vid = h["source_file_version_id"]
            if h[scope_col] in won and vid != incoming.version_id:
                replaced[vid] = replaced.get(vid, 0) + h["count"]
        if not won:
            return 0, won, lost, replaced

        literals = ", ".join(_sql_literal(s) for s in won)
        self.spark.sql(
            f"DELETE FROM {physical} WHERE `{scope_col}` IN ({literals})")
        mine = df.where(F.col(scope_col).isin(won))
        n = mine.count()
        mine.write.format("delta").mode("append").saveAsTable(physical)
        return n, won, lost, replaced

    # -- facts ----------------------------------------------------------------
    def _clean_fact(self, source: SourceSpec, spec: TableSpec,
                    version_ids: list[str]) -> DataFrame:
        bronze = self._bronze_rows(source, version_ids)
        overrides: dict[str, Column] = {}
        entity = source.entity
        if entity in AAH_DAILY_FEEDS:
            overrides["business_date"] = cleaning.clean_date(F.col("date_raw"),
                                                             self.cfg)
            overrides["pip_code_canonical"] = cleaning.canonical_code(
                F.col("pip_code_raw"))
        elif entity == "stock_availability":
            overrides["pip_code_canonical"] = cleaning.canonical_code(
                F.col("pip_code_raw"))
        return cleaning.map_clean_columns(bronze, spec, self.cfg, overrides)

    def _resolve_fact_refs(self, entity: str, df: DataFrame) -> DataFrame:
        if entity in AAH_DAILY_FEEDS:
            # PIP first, the AAH product code (through the master) second
            df = self._attach_ref(df, self.refs.resolver("product", "PIP_CODE"),
                                  "pip_code_canonical", "product_ref_id")
            df = self._attach_ref(df, self.refs.resolver(
                "product", "AAH_PRODUCT_CODE"), "aah_product_code",
                "product_ref_id")
            df = self._attach_ref(df, self.refs.resolver("account",
                                                         "AAH_ACCOUNT_NUMBER"),
                                  "account_number", "account_ref_id")
        elif entity == "stock_availability":
            # PIP is the primary identifier; AAH product code is the fallback
            df = self._attach_ref(df, self.refs.resolver("product", "PIP_CODE"),
                                  "pip_code_canonical", "product_ref_id")
            df = self._attach_ref(df, self.refs.resolver(
                "product", "AAH_PRODUCT_CODE"), "product_code", "product_ref_id")
            df = self._attach_ref(df, self.refs.resolver(
                "stock_location", "LOCATION_CODE"),
                "location_code", "stock_location_ref_id")
            df = self._attach_ref(df, self.refs.resolver(
                "supplier", "SUPPLIER_CODE"),
                "supplier_code", "supplier_ref_id")
        return df

    def _register_observed(self, frames: Mapping[str, DataFrame]) -> None:
        """Self-register stock locations & suppliers seen in stock/weekly rows."""
        rules = {r.rule_id: r for r in self.ctx.resolution_rules}
        loc_parts, sup_parts = [], []
        for name, df in frames.items():
            if "location_code" in df.columns:
                loc_name = F.col("location_name") if "location_name" in df.columns \
                    else F.lit(None).cast("string")
                loc_parts.append(df.select(
                    F.col("location_code"), loc_name.alias("location_name"),
                    "ingestion_id", "source_file_version_id",
                    "source_file_name"))
            if "supplier_code" in df.columns:
                sup_name = F.col("supplier_name") if "supplier_name" in df.columns \
                    else F.lit(None).cast("string")
                sup_parts.append(df.select(
                    F.col("supplier_code"), sup_name.alias("supplier_name"),
                    "ingestion_id", "source_file_version_id",
                    "source_file_name"))
        if loc_parts:
            obs = loc_parts[0]
            for p in loc_parts[1:]:
                obs = obs.unionByName(p)
            obs = (obs.where(F.col("location_code").isNotNull())
                      .dropDuplicates(["location_code"]))
            self.refs.build_observed_reference("stock_location", obs,
                                               rules["LOCATION_CODE_DIRECT"])
            # AAH locations only: a Phoenix location has no location code
            ref = (self.spark.table(self.cfg.resolve_table(
                "silver.stock_location_reference"))
                .where(F.col("is_current") & F.col("location_code").isNotNull()))
            self.refs.record_evidence("stock_location",
                                      rules["LOCATION_CODE_DIRECT"],
                                      ref.select(
                F.col("stock_location_ref_id").alias("entity_ref_id"),
                F.col("stock_location_reference_version_id")
                    .alias("reference_version_id"),
                F.lit("silver.stock_location_reference").alias("source_table"),
                "source_file_version_id",
                F.lit(None).cast("bigint").alias("source_row_number"),
                F.col("location_code").alias("source_identifier_value")))
        if sup_parts:
            obs = sup_parts[0]
            for p in sup_parts[1:]:
                obs = obs.unionByName(p)
            obs = (obs.where(F.col("supplier_code").isNotNull())
                      .dropDuplicates(["supplier_code"]))
            self.refs.build_observed_reference("supplier", obs,
                                               rules["SUPPLIER_CODE_DIRECT"])
            ref = self.spark.table(self.cfg.resolve_table(
                "silver.supplier_reference")).where(F.col("is_current"))
            self.refs.record_evidence("supplier", rules["SUPPLIER_CODE_DIRECT"],
                                      ref.select(
                F.col("supplier_ref_id").alias("entity_ref_id"),
                F.col("supplier_reference_version_id")
                    .alias("reference_version_id"),
                F.lit("silver.supplier_reference").alias("source_table"),
                "source_file_version_id",
                F.lit(None).cast("bigint").alias("source_row_number"),
                F.col("supplier_code").alias("source_identifier_value")))

    @staticmethod
    def _last_line_per(lines: DataFrame, code: str) -> DataFrame:
        """One line per account code: the last in the file."""
        last = Window.partitionBy(code).orderBy(F.col("source_row_number").desc())
        return (lines.where(F.col(code).isNotNull())
                .withColumn("_line_rank", F.row_number().over(last))
                .where(F.col("_line_rank") == 1).drop("_line_rank"))

    def _register_aah_accounts(self, lines: DataFrame) -> None:
        """Register every AAH account number on these lines as an account."""
        none = F.lit(None).cast("string")
        self.refs.register_accounts(
            self._last_line_per(lines, "account_number").select(
                F.lit("AAH_ACCOUNT_NUMBER").alias("account_identifier_type"),
                "account_number", none.alias("williams_customer_code"),
                F.lit("AAH").alias("vendor"), "account_name",
                "customer_type", "customer_channel",
                F.col("address_line_1").alias("address_1"),
                F.col("address_line_2").alias("address_2"),
                F.col("address_line_3").alias("address_3"),
                F.col("address_line_4").alias("address_4"),
                none.alias("town"), "post_code",
                F.lit("AAH_DAILY_SALES").alias("address_source"),
                "ingestion_id", "source_file_version_id", "source_file_name"),
            "AAH_ACCOUNT_NUMBER")

    def _register_williams_accounts(self, lines: DataFrame) -> None:
        """Register every Williams customer code on these lines as an account."""
        none = F.lit(None).cast("string")
        self.refs.register_accounts(
            self._last_line_per(lines, "customer_code").select(
                F.lit("WILLIAMS_CUSTOMER_CODE").alias("account_identifier_type"),
                none.alias("account_number"),
                F.col("customer_code").alias("williams_customer_code"),
                F.lit("WILLIAMS").alias("vendor"),
                F.col("customer_name").alias("account_name"),
                none.alias("customer_type"), none.alias("customer_channel"),
                F.col("delivery_address").alias("address_1"),
                none.alias("address_2"), none.alias("address_3"),
                none.alias("address_4"),
                F.col("customer_city").alias("town"),
                F.col("sales_order_delivery_post_code").alias("post_code"),
                F.lit("WILLIAMS").alias("address_source"),
                "ingestion_id", "source_file_version_id", "source_file_name"),
            "WILLIAMS_CUSTOMER_CODE")

    def _load_fact_entity(self, entity: str, mode: LoadMode) -> None:
        source = self.ctx.source(entity)
        pend = self._pending(source, mode)
        if not pend:
            self.ops.run_event("silver", entity, "SKIPPED",
                               detail="no pending versions")
            return
        spec = self.ctx.table(source.silver_table)
        for row in sorted(pend, key=lambda r: r["file_received_ts"]):
            vid = row["source_file_version_id"]
            cleanf = self._clean_fact(source, spec, [vid])
            self._register_observed({entity: cleanf})
            if entity in AAH_DAILY_FEEDS:
                self._register_aah_accounts(cleanf)
            resolved = self._resolve_fact_refs(entity, cleanf)
            final = self._finalize(resolved, spec,
                                   source.silver.get("dq_sentinel_columns"))
            n = self._scoped_write(final, spec, source.scope_columns,
                                   bool(row["is_partial"]), entity)
            self._sentinel_dq_events(final, spec, entity)
            self.ops.set_layer_status(vid, "silver", "APPLIED", n)
            self.ops.run_event("silver", entity, "SUCCESS", n,
                               detail=row["source_file_name"])

    # -- williams -------------------------------------------------------------
    def _resolve_williams_refs(self, df: DataFrame) -> DataFrame:
        """Product: the material code first, else the normalised material description."""
        df = williams.product_match_keys(df)
        df = self._attach_ref(df, self.refs.resolver(
            "product", "WILLIAMS_MATERIAL_CODE"),
            "_material_code_key", "product_ref_id")
        df = self._attach_ref(df, self.refs.resolver(
            "product", "WILLIAMS_PRODUCT_NAME"),
            "_material_name_key", "product_ref_id")
        df = self._attach_ref(df, self.refs.resolver(
            "account", "WILLIAMS_CUSTOMER_CODE"), "customer_code", "account_ref_id")
        return df.drop("_material_code_key", "_material_name_key")

    def _report_rejects(self, entity: str, spec: TableSpec,
                        tagged: DataFrame, file_name: str) -> int:
        """Count the lines a FAIL rule keeps out of silver, per rule."""
        rejects = row_rules.rejected(tagged)
        per_rule = (rejects.select(F.explode(row_rules.REJECT_CODES).alias("rule"))
                    .groupBy("rule").count().collect())
        if not per_rule:
            return 0
        rows = [r[0] for r in rejects.select("source_row_number")
                .orderBy("source_row_number").limit(20).collect()]
        for r in per_rule:
            self.ops.dq_event(
                entity, spec.logical_name, r["rule"], "ERROR", r["count"],
                f"{file_name}: kept out of silver; bronze source_row_number "
                f"{rows}{' (first 20)' if len(rows) == 20 else ''}")
        return rejects.count()

    def _refuse_partial(self, entity: str, spec: TableSpec, row: Row,
                        unit: str) -> None:
        """A feed whose files replace whole dates cannot take a partial delivery."""
        name = row["source_file_name"]
        msg = (f"{name}: partial deliveries cannot be applied to {entity} - "
               f"each file replaces every {unit} it carries. Re-deliver it "
               f"complete, without '{self.cfg.partial_file_marker}' in the name.")
        self.ops.set_layer_status(row["source_file_version_id"], "silver",
                                  "REJECTED")
        self.ops.dq_event(entity, spec.logical_name,
                          "PARTIAL_DELIVERY_NOT_SUPPORTED", "ERROR", 0, msg)
        self.ops.run_event("silver", entity, "REJECTED", detail=msg)

    def _load_williams(self, mode: LoadMode) -> None:
        """Williams sales, both file layouts, into silver.williams_sales."""
        entity = "williams_sales"
        source = self.ctx.source(entity)
        pend = self._pending(source, mode)
        if not pend:
            self.ops.run_event("silver", entity, "SKIPPED",
                               detail="no pending versions")
            return
        spec = self.ctx.table(source.silver_table)
        if len(source.scope_columns) != 1:
            raise ValueError(
                f"{entity}: silver.scope must name exactly one column (the "
                f"invoice date a file replaces), got {source.scope_columns}")
        scope_col = source.scope_columns[0]
        classes = list(source.silver.get("accepted_customer_classes") or [])

        for row in sorted(pend, key=lambda r: (r["file_received_ts"],
                                               r["source_file_version_id"])):
            vid, name = row["source_file_version_id"], row["source_file_name"]
            if row["is_partial"]:
                self._refuse_partial(entity, spec, row, "invoice date")
                continue

            tagged = williams.tag_rejects(williams.clean(
                self._bronze_rows(source, [vid]), spec, source, self.cfg))
            n_in = tagged.count()
            n_rejected = self._report_rejects(entity, spec, tagged, name)
            accepted = williams.accepted(tagged)
            self._register_williams_accounts(accepted)
            resolved = self._resolve_williams_refs(accepted)
            final = williams.flag_warnings(
                self._finalize(resolved, spec,
                               source.silver.get("dq_sentinel_columns")),
                classes)

            rank = FileRank(
                row["supersede_priority"]
                or source.priority_of(row["schema_version"]),
                row["file_received_ts"], vid)
            n, won, lost, replaced = self._ranked_scope_write(
                final, spec, scope_col, rank)
            if won:
                self._sentinel_dq_events(
                    final.where(F.col(scope_col).isin(won)), spec, entity)
            n_withheld = (final.where(F.col(scope_col).isin(lost)).count()
                          if lost else 0)

            # every delivered line is written, withheld or rejected
            detail = (f"{name} [{row['schema_version']}, priority "
                      f"{rank.priority}]: {n} line(s) written for {len(won)} "
                      f"invoice date(s); {n_withheld} withheld for {len(lost)} "
                      f"date(s) a better-ranked file holds; {n_rejected} "
                      f"rejected")
            if replaced:
                detail += "; replaced " + ", ".join(
                    f"{lines} line(s) of {holder}"
                    for holder, lines in sorted(replaced.items()))
            self.ops.reconciliation(entity, "LINES_DELIVERED_VS_ACCOUNTED",
                                    n_in, n + n_withheld + n_rejected,
                                    tolerance=0, detail=detail)
            self.ops.set_layer_status(vid, "silver", "APPLIED", n)
            self.ops.run_event("silver", entity, "SUCCESS", n, detail=detail)

    # -- phoenix --------------------------------------------------------------
    def _register_phoenix_accounts(self, lines: DataFrame) -> None:
        """Register every Phoenix customer number on these lines as an account."""
        self.refs.register_accounts(
            self._last_line_per(lines, "customer_number").select(
                F.lit("PHOENIX_CUSTOMER_NUMBER").alias("account_identifier_type"),
                F.col("customer_number").alias("phoenix_customer_number"),
                F.lit("PHOENIX").alias("vendor"),
                F.col("customer_name").alias("account_name"),
                "customer_channel",
                F.col("customer_post_code").alias("post_code"),
                F.lit("PHOENIX_SALES").alias("address_source"),
                "ingestion_id", "source_file_version_id", "source_file_name"),
            "PHOENIX_CUSTOMER_NUMBER")

    def _register_phoenix_locations(self, lines: DataFrame) -> None:
        """Register every Phoenix location number on these lines as a location."""
        self.refs.register_locations(
            self._last_line_per(lines, "location_number").select(
                F.lit("PHOENIX_LOCATION_NUMBER").alias("location_identifier_type"),
                F.col("location_number").alias("phoenix_location_number"),
                "location_name",
                "ingestion_id", "source_file_version_id", "source_file_name"),
            "PHOENIX_LOCATION_NUMBER")

    def _resolve_phoenix_refs(self, df: DataFrame
                              ) -> tuple[DataFrame, list[str]]:
        """Match product, account and location; also return unmatched article codes."""
        df = self._attach_ref(df, self.refs.resolver("product", "PIP_CODE"),
                              "pip_code_canonical", "product_ref_id")
        _, unmatched = self.refs.record_article_codes(df)
        df = self._attach_ref(df, self.refs.resolver(
            "product", "PHOENIX_ARTICLE_CODE"), "article_code", "product_ref_id")
        df = self._attach_ref(df, self.refs.resolver(
            "account", "PHOENIX_CUSTOMER_NUMBER"), "customer_number",
            "account_ref_id")
        df = self._attach_ref(df, self.refs.resolver(
            "stock_location", "PHOENIX_LOCATION_NUMBER"), "location_number",
            "stock_location_ref_id")
        return df, unmatched

    def _load_phoenix(self, mode: LoadMode) -> None:
        """Phoenix sales into silver.phoenix_sales."""
        entity = phoenix.ENTITY
        source = self.ctx.source(entity)
        spec = self.ctx.table(source.silver_table)
        # created up front: gold and the reporting views read it
        create_table_if_absent(self.spark, self.cfg, spec)
        pend = self._pending(source, mode)
        if not pend:
            self.ops.run_event("silver", entity, "SKIPPED",
                               detail="no pending versions")
            return
        if len(source.scope_columns) != 1:
            raise ValueError(
                f"{entity}: silver.scope must name exactly one column (the "
                f"business date a file replaces), got {source.scope_columns}")
        scope_col = source.scope_columns[0]
        channels = list(source.silver.get("accepted_customer_channels") or [])

        for row in sorted(pend, key=lambda r: (r["file_received_ts"],
                                               r["source_file_version_id"])):
            vid, name = row["source_file_version_id"], row["source_file_name"]
            if row["is_partial"]:
                self._refuse_partial(entity, spec, row, "business date")
                continue

            tagged = phoenix.tag_rejects(phoenix.clean(
                self._bronze_rows(source, [vid]), spec, source, self.cfg))
            n_in = tagged.count()
            n_rejected = self._report_rejects(entity, spec, tagged, name)
            covered = phoenix.coverage(tagged)
            accepted = phoenix.accepted(tagged)
            self._register_phoenix_accounts(accepted)
            self._register_phoenix_locations(accepted)
            resolved, unmatched = self._resolve_phoenix_refs(accepted)
            if unmatched:
                shown = unmatched[:20]
                self.ops.dq_event(
                    entity, spec.logical_name, phoenix.ARTICLE_CODE_CONFLICT,
                    "WARNING", len(unmatched),
                    f"{name}: article code(s) seen with more than one product, "
                    f"left unmatched for a data steward: {shown}"
                    f"{' (first 20)' if len(unmatched) > 20 else ''}")
            final = phoenix.flag_warnings(
                self._finalize(resolved, spec,
                               source.silver.get("dq_sentinel_columns")),
                channels)

            rank = FileRank(
                row["supersede_priority"]
                or source.priority_of(row["schema_version"]),
                row["file_received_ts"], vid)
            n, won, lost, replaced = self._ranked_scope_write(
                final, spec, scope_col, rank, scopes=covered)
            if won:
                self._sentinel_dq_events(
                    final.where(F.col(scope_col).isin(won)), spec, entity)
            n_withheld = (final.where(F.col(scope_col).isin(lost)).count()
                          if lost else 0)
            if covered:
                self.ops.record_coverage(vid, covered[0], covered[-1])

            span = (f"{covered[0]} to {covered[-1]}" if covered
                    else "no dated lines")
            detail = (f"{name} [{row['schema_version']}, covers {span}]: {n} "
                      f"line(s) written for {len(won)} date(s); {n_withheld} "
                      f"withheld for {len(lost)} date(s) a newer file holds; "
                      f"{n_rejected} rejected")
            if replaced:
                detail += "; replaced " + ", ".join(
                    f"{lines} line(s) of {holder}"
                    for holder, lines in sorted(replaced.items()))
            status = self.ops.reconciliation(
                entity, phoenix.LINES_RECONCILIATION, n_in,
                n + n_withheld + n_rejected, tolerance=0, detail=detail)
            if status != "PASS":
                # PX-16: a file whose lines do not add up is not published
                self.ops.set_layer_status(vid, "silver", "FAILED", n)
                self.ops.dq_event(entity, spec.logical_name,
                                  phoenix.LINES_RECONCILIATION, "ERROR",
                                  abs(n_in - (n + n_withheld + n_rejected)),
                                  f"{detail}; kept out of gold")
                self.ops.run_event("silver", entity, "FAILED", n, detail=detail)
                continue
            self.ops.set_layer_status(vid, "silver", "APPLIED", n)
            self.ops.run_event("silver", entity, "SUCCESS", n, detail=detail)

        # the latest article code per product, onto the product reference
        self.refs.build_product_reference()

    # -- weekly ---------------------------------------------------------------
    def _load_weekly(self, mode: LoadMode) -> None:
        entity = "weekly_report"
        source = self.ctx.source(entity)
        pend = self._pending(source, mode)
        if not pend:
            self.ops.run_event("silver", entity, "SKIPPED",
                               detail="no pending versions")
            return
        m_spec = self.ctx.table("silver.weekly_report_measure")
        t_spec = self.ctx.table("silver.weekly_report_period_total")
        for row in sorted(pend, key=lambda r: r["file_received_ts"]):
            vid = row["source_file_version_id"]
            bronze = self._bronze_rows(source, [vid])
            measures, totals = weekly.explode_weekly(bronze, source, self.cfg)
            self._register_observed({"weekly": measures})
            prod_pip = self.refs.resolver("product", "PIP_CODE")
            prod_code = self.refs.resolver("product", "AAH_PRODUCT_CODE")
            loc = self.refs.resolver("stock_location", "LOCATION_CODE")
            sup = self.refs.resolver("supplier", "SUPPLIER_CODE")

            def resolve(df: DataFrame) -> DataFrame:
                df = self._attach_ref(df, prod_pip, "pip_code_canonical",
                                      "product_ref_id")
                df = self._attach_ref(df, prod_code, "product_code",
                                      "product_ref_id")
                df = self._attach_ref(df, loc, "location_code",
                                      "stock_location_ref_id")
                df = self._attach_ref(df, sup, "supplier_code",
                                      "supplier_ref_id")
                return df

            fm = self._finalize(resolve(measures), m_spec)
            ft = self._finalize(resolve(totals), t_spec)
            n_m = self._scoped_write(fm, m_spec, source.scope_columns,
                                     bool(row["is_partial"]), entity)
            n_t = self._scoped_write(ft, t_spec, source.scope_columns,
                                     bool(row["is_partial"]), entity)
            self._sentinel_dq_events(fm, m_spec, entity)

            # reconcile on the raw exploded frames (both use metric_value)
            recon = weekly.reconcile_weeks_vs_totals(measures, totals)
            bad = recon.where(F.abs(F.col("difference")) > 0.001)
            n_bad = bad.count()
            status = self.ops.reconciliation(
                entity, "SUM_WEEKS_VS_TOTAL",
                float((measures.agg(F.sum("metric_value")).collect()[0][0]) or 0),
                float((totals.agg(F.sum("metric_value")).collect()[0][0]) or 0),
                tolerance=0.001,
                detail=f"{n_bad} grain combinations off; version {vid}")
            if n_bad:
                self.ops.dq_event(entity, m_spec.logical_name,
                                  "WEEKS_VS_TOTAL_MISMATCH", "WARNING", n_bad)
            self.ops.set_layer_status(vid, "silver", "APPLIED", n_m + n_t)
            self.ops.run_event("silver", entity, "SUCCESS", n_m + n_t,
                               detail=f"{row['source_file_name']} "
                                      f"(recon {status})")

    # -- public ---------------------------------------------------------------
    @property
    def master_order(self) -> list[str]:
        """SCD2 masters, from the scd2 flag in sources.yaml (in file order)."""
        return [s.entity for s in self.ctx.sources()
                if s.is_scd2_master and s.entity in _MASTER_TEMPLATES]

    def _master_def(self, entity: str) -> Scd2Def:
        """SCD2 definition with the business key taken from the spec."""
        spec = self.ctx.table(self.ctx.source(entity).silver_table)
        return replace(_MASTER_TEMPLATES[entity],
                       business_key_cols=[c.name for c in spec.bk_columns])

    def run(self, entities: Optional[list[str]] = None,
            mode: LoadMode = LoadMode.INCREMENTAL) -> None:
        wanted = set(entities) if entities else None

        def _want(e: str) -> bool:
            return wanted is None or e in wanted

        masters = self.master_order
        for e in masters:
            if _want(e):
                self._load_masters_single(e, mode)
        if any(_want(e) for e in masters) or wanted is None:
            self.refs.build_product_reference()
            self.refs.refresh_master_evidence()
        for e in FACT_ORDER:
            if _want(e):
                self._load_fact_entity(e, mode)
        if _want("williams_sales"):
            self._load_williams(mode)
        if _want(phoenix.ENTITY):
            self._load_phoenix(mode)
        if _want("weekly_report"):
            self._load_weekly(mode)

    def _load_masters_single(self, entity: str, mode: LoadMode) -> None:
        source = self.ctx.source(entity)
        pend = self._pending(source, mode)
        if not pend:
            self.ops.run_event("silver", entity, "SKIPPED",
                               detail="no pending versions")
            return
        spec = self.ctx.table(source.silver_table)
        d = self._master_def(entity)
        for row in sorted(pend, key=lambda r: r["file_received_ts"]):
            vid = row["source_file_version_id"]
            bronze = self._bronze_rows(source, [vid])
            overrides: dict[str, Column] = {}
            if entity == "wholesale_product_master":
                overrides["pip_code_canonical"] = cleaning.canonical_code(
                    F.col("pip_code_raw"))
                overrides["pip_code_repeat"] = cleaning.clean_string(
                    F.col("pip_code_raw"))
            cleanf = cleaning.map_clean_columns(bronze, spec, self.cfg,
                                                overrides)
            cleanf = cleanf.where(F.concat_ws(
                "", *[F.coalesce(F.col(c).cast("string"), F.lit(""))
                      for c in d.business_key_cols]) != "")
            n = apply_scd2(self.spark, self.cfg, spec, d, cleanf)
            self.ops.set_layer_status(vid, "silver", "APPLIED", n)
            self.ops.run_event("silver", entity, "SUCCESS", n,
                               detail=f"{row['source_file_name']}: "
                                      f"{n} new SCD2 versions")
