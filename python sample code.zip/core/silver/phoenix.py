"""Phoenix sales: cleaning, row rules and coverage."""
from __future__ import annotations

from typing import Callable, Mapping, Sequence

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F

from ..config.models import PlatformConfig, SourceSpec, TableSpec
from . import cleaning, row_rules
from .row_rules import REJECT_CODES, rejected     # noqa: F401  (the loader reads them here)
from .supersede import date_span

ENTITY = "phoenix_sales"

# PX-05 needs to know a value was delivered at all, which typing throws away
_VALUE_SUPPLIED = "_sales_value_supplied"

# Built lazily: a Column can only be created once a Spark session exists.
FAIL_RULES: Mapping[str, Callable[[], Column]] = {
    "PX-02_DATE_INVALID": lambda: F.col("business_date").isNull(),
    "PX-04_SALES_QTY_INVALID": lambda: F.col("sales_qty").isNull(),
    "PX-05_SALES_VALUE_NOT_NUMERIC": lambda: (
        F.col(_VALUE_SUPPLIED) & F.col("sales_value").isNull()),
    "PX-07_NO_PRODUCT_IDENTIFIER": lambda: (
        F.col("pip_code").isNull() & F.col("article_code").isNull()),
}

ARTICLE_CODE_CONFLICT = "PX-14_ARTICLE_CODE_CONFLICT"
LINES_RECONCILIATION = "PX-16_LINES_DELIVERED_VS_ACCOUNTED"
CHANNEL_UNLISTED = "PX-15_CUSTOMER_CHANNEL_UNLISTED"


def clean(bronze: DataFrame, spec: TableSpec, source: SourceSpec,
          cfg: PlatformConfig) -> DataFrame:
    """Bronze rows -> typed silver columns (keys and audit columns come later)."""
    supplied = F.nullif(F.trim(F.col("sales_value_raw")), F.lit("")).isNotNull()
    return cleaning.map_clean_columns(
        bronze.withColumn(_VALUE_SUPPLIED, supplied), spec, cfg,
        overrides={
            "business_date": cleaning.layout_date(F.col("date_raw"), source, cfg),
            "pip_code_canonical": cleaning.canonical_pip(F.col("pip_code_raw")),
            "customer_post_code": cleaning.uk_post_code(
                F.col("customer_post_code_raw")),
        },
        keep=[_VALUE_SUPPLIED])


def tag_rejects(df: DataFrame) -> DataFrame:
    """Add the ids of the FAIL rules each row breaks (empty array = clean)."""
    return row_rules.tag_rejects(df, FAIL_RULES)


def accepted(tagged: DataFrame) -> DataFrame:
    return row_rules.accepted(tagged).drop(_VALUE_SUPPLIED)


def flag_warnings(df: DataFrame,
                  accepted_channels: Sequence[str] = ()) -> DataFrame:
    """Add the WARN rules once the line has its key (PX-13 reads line_occurrence)."""
    qty, value = F.col("sales_qty"), F.col("sales_value")
    rules: dict[str, Column] = {
        "PX-06_SALES_VALUE_MISSING": value.isNull(),
        "PX-08_PIP_NOT_CANONICAL": (F.col("pip_code").isNotNull()
                                    & F.col("pip_code_canonical").isNull()),
        "PX-09_CUSTOMER_NUMBER_MISSING": F.col("customer_number").isNull(),
        "PX-10_LOCATION_NUMBER_MISSING": F.col("location_number").isNull(),
        "PX-11_NEGATIVE_QTY": qty < 0,
        "PX-12_QTY_VALUE_SIGN_MISMATCH": (((qty < 0) & (value > 0))
                                          | ((qty > 0) & (value < 0))),
        "PX-13_REPEATED_LINE": F.col("line_occurrence") > 1,
    }
    if accepted_channels:
        channel = F.col("customer_channel")
        rules[CHANNEL_UNLISTED] = (channel.isNotNull()
                                   & ~channel.isin(*accepted_channels))
    return row_rules.flag(df, rules)


def coverage(tagged: DataFrame) -> list:
    """The business dates a file replaces."""
    first, last = tagged.agg(F.min("business_date"),
                             F.max("business_date")).collect()[0]
    return date_span(first, last) if first is not None else []
