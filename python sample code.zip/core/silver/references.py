"""Conformed references + the evidence bridge."""
from __future__ import annotations

from pyspark.sql import Column, DataFrame, SparkSession, Window
from pyspark.sql import functions as F

from ..common.hashing import align_to_spec, create_table_if_absent
from ..config.loader import ConfigContext
from ..config.models import ResolutionRule
from .cleaning import canonical_code, normalised_name
from .scd2 import Scd2Def, apply_scd2, durable_ref_id

EVIDENCE_TABLE = "silver.entity_reference_source"

# Phoenix article codes are learned from Phoenix lines (rule SAME_LINE_PIP)
ARTICLE_CODE_TYPE = "PHOENIX_ARTICLE_CODE"
ARTICLE_CODE_SOURCE = "silver.phoenix_sales"

REFERENCE_DEFS: dict[str, Scd2Def] = {
    # phoenix_article_code is the latest code seen against the product
    "product": Scd2Def(
        entity="product",
        version_id_col="product_reference_version_id",
        ref_id_col="product_ref_id",
        business_key_cols=["pip_code_canonical"],
        business_key_out="product_business_key",
        attribute_cols=["pip_code", "sku", "aah_product_code", "product_code",
                        "ean_code", "product_name",
                        "iqvia_scm_weekly_product_name", "williams_product_name",
                        "product_description", "bu", "pack_size"],
        latest_cols=["phoenix_article_code"]),
    # no account master - the wholesaler's own code is the account.
    "account": Scd2Def(
        entity="account",
        version_id_col="account_reference_version_id",
        ref_id_col="account_ref_id",
        business_key_cols=["account_identifier_type", "account_number",
                           "williams_customer_code", "phoenix_customer_number"],
        business_key_out="account_business_key",
        attribute_cols=["vendor", "account_name", "address_1", "address_2",
                        "address_3", "address_4", "town", "post_code",
                        "address_source"],
        latest_cols=["customer_type", "customer_channel"]),
    # AAH location codes keep their key, the bare code
    "stock_location": Scd2Def(
        entity="stock_location",
        version_id_col="stock_location_reference_version_id",
        ref_id_col="stock_location_ref_id",
        business_key_cols=["location_identifier_type", "location_code",
                           "phoenix_location_number"],
        business_key_out="stock_location_business_key",
        attribute_cols=["location_name"]),
    "supplier": Scd2Def(
        entity="supplier",
        version_id_col="supplier_reference_version_id",
        ref_id_col="supplier_ref_id",
        business_key_cols=["supplier_code"],
        business_key_out="supplier_business_key",
        attribute_cols=["supplier_name"]),
}

# account namespace -> the account_reference column holding that code
ACCOUNT_CODE_COLUMNS = {"AAH_ACCOUNT_NUMBER": "account_number",
                        "WILLIAMS_CUSTOMER_CODE": "williams_customer_code",
                        "PHOENIX_CUSTOMER_NUMBER": "phoenix_customer_number"}

# location namespace -> the stock_location_reference column holding that code
LOCATION_CODE_COLUMNS = {"PHOENIX_LOCATION_NUMBER": "phoenix_location_number"}

REFERENCE_TABLES = {
    "product": "silver.product_reference",
    "account": "silver.account_reference",
    "stock_location": "silver.stock_location_reference",
    "supplier": "silver.supplier_reference",
}


class ReferenceBuilder:
    def __init__(self, spark: SparkSession, ctx: ConfigContext) -> None:
        self.spark = spark
        self.ctx = ctx
        self.cfg = ctx.platform

    def _ensure(self, logical: str) -> str:
        """Create the table empty if it doesn't exist yet, and return its physical name."""
        return create_table_if_absent(self.spark, self.cfg,
                                      self.ctx.table(logical), evolve=False)

    # -- member building -----------------------------------------------------
    def build_product_reference(self) -> int:
        """Members come from the governed product master (current versions)."""
        master = (self.spark
                  .table(self._ensure("silver.wholesale_product_master"))
                  .where(F.col("is_current")))
        incoming = master.select(
            "pip_code_canonical", "pip_code", "sku", "aah_product_code",
            # product_code == master aah_product_code (rule AAH_CODE_VIA_MASTER)
            F.col("aah_product_code").alias("product_code"),
            F.lit(None).cast("string").alias("ean_code"),
            "product_name", "iqvia_scm_weekly_product_name",
            "williams_product_name",
            F.col("product_name").alias("product_description"),
            "bu", F.lit(None).cast("string").alias("pack_size"),
            F.lit("PIP_EXACT").alias("match_rule"),
            F.lit("HIGH").alias("match_confidence"),
            "ingestion_id", "source_file_version_id", "source_file_name",
        ).where(F.col("pip_code_canonical").isNotNull())
        codes = self._latest_article_codes()
        incoming = (incoming
                    .withColumn("_article_ref", durable_ref_id(
                        "product", F.col("pip_code_canonical").cast("string")))
                    .join(codes, "_article_ref", "left").drop("_article_ref"))
        return apply_scd2(self.spark, self.cfg,
                          self.ctx.table(REFERENCE_TABLES["product"]),
                          REFERENCE_DEFS["product"], incoming)

    def _latest_article_codes(self) -> DataFrame:
        """Latest active Phoenix article code per product."""
        latest = Window.partitionBy("entity_ref_id").orderBy(
            F.col("processed_at").desc(), F.col("source_identifier_value").desc())
        return (self.spark.table(self._ensure(EVIDENCE_TABLE))
                .where((F.col("entity_type") == "product")
                       & (F.col("source_identifier_type") == ARTICLE_CODE_TYPE)
                       & F.col("is_active"))
                .withColumn("_rank", F.row_number().over(latest))
                .where(F.col("_rank") == 1)
                .select(F.col("entity_ref_id").alias("_article_ref"),
                        F.col("source_identifier_value")
                        .alias("phoenix_article_code")))

    def build_observed_reference(self, entity_type: str, observed: DataFrame,
                                 rule: ResolutionRule) -> int:
        """Self-registering references (account / stock_location / supplier)."""
        d = REFERENCE_DEFS[entity_type]
        # a feed sends only the columns it has: the others are NULL
        for c in (*d.business_key_cols, *d.attribute_cols, *d.latest_cols):
            if c not in observed.columns:
                observed = observed.withColumn(c, F.lit(None).cast("string"))
        incoming = (observed
                    .withColumn("match_rule", F.lit(rule.rule_id))
                    .withColumn("match_confidence", F.lit(rule.confidence)))
        # create or evolve the table first
        physical = create_table_if_absent(
            self.spark, self.cfg, self.ctx.table(REFERENCE_TABLES[entity_type]))
        current = self.spark.table(physical).where(F.col("is_current"))
        has_current = current.limit(1).count() > 0
        kept = [*d.attribute_cols, *d.latest_cols]
        if has_current and kept:
            bk = list(d.business_key_cols)
            cur = current.select(*[F.col(k).alias(f"_key_{k}") for k in bk],
                                 *[F.col(a).alias(f"_cur_{a}") for a in kept])
            # null-safe: an account key has one NULL code column
            on = F.lit(True)
            for k in bk:
                on = on & F.col(k).eqNullSafe(F.col(f"_key_{k}"))
            incoming = incoming.join(cur, on, "left") \
                .drop(*[f"_key_{k}" for k in bk])
            for a in kept:
                incoming = incoming.withColumn(
                    a, F.coalesce(F.col(a), F.col(f"_cur_{a}"))).drop(f"_cur_{a}")
        return apply_scd2(self.spark, self.cfg,
                          self.ctx.table(REFERENCE_TABLES[entity_type]),
                          d, incoming)

    # -- evidence bridge -----------------------------------------------------
    def record_evidence(self, entity_type: str, rule: ResolutionRule,
                        rows: DataFrame, active: bool | None = None) -> None:
        """Upsert evidence rows."""
        is_active = rule.active if active is None else active
        spec = self.ctx.table(EVIDENCE_TABLE)
        physical = create_table_if_absent(self.spark, self.cfg, spec)
        now = F.current_timestamp()
        ev = (rows
              .withColumn("entity_type", F.lit(entity_type))
              .withColumn("source_identifier_type", F.lit(rule.identifier_type))
              .withColumn("match_rule", F.lit(rule.rule_id))
              .withColumn("match_confidence", F.lit(rule.confidence))
              .withColumn("valid_from_ts", now)
              .withColumn("valid_to_ts", F.lit(None).cast("timestamp"))
              .withColumn("is_active", F.lit(is_active))
              .withColumn("processed_at", now)
              .withColumn("evidence_id", F.sha2(F.concat_ws(
                  "|", F.lit(entity_type), F.lit(rule.identifier_type),
                  F.coalesce(F.col("source_identifier_value"), F.lit("\u0000")),
                  F.col("source_table")), 256))
              .dropDuplicates(["evidence_id"]))
        aligned = align_to_spec(ev, spec)
        aligned.createOrReplaceTempView("_ev_src")
        self.spark.sql(f"""
            MERGE INTO {physical} t USING _ev_src s
            ON t.evidence_id = s.evidence_id
            WHEN MATCHED THEN UPDATE SET
                t.entity_ref_id = s.entity_ref_id,
                t.reference_version_id = s.reference_version_id,
                t.match_confidence = s.match_confidence,
                t.is_active = s.is_active,
                t.processed_at = s.processed_at
            WHEN NOT MATCHED THEN INSERT *
        """)

    def resolver(self, entity_type: str, identifier_type: str) -> DataFrame:
        """ACTIVE-evidence map: source_identifier_value -> durable ref id."""
        ev = self.spark.table(self._ensure(EVIDENCE_TABLE))
        return (ev.where((F.col("entity_type") == entity_type)
                         & (F.col("source_identifier_type") == identifier_type)
                         & F.col("is_active"))
                  .select(F.col("source_identifier_value").alias("_ident"),
                          F.col("entity_ref_id").alias("_ref"))
                  .dropDuplicates(["_ident"]))

    # -- canonical evidence sets --------------------------------------------
    def refresh_master_evidence(self) -> None:
        rules = {r.rule_id: r for r in self.ctx.resolution_rules}
        prod_ref = self.spark.table(
            self.cfg.resolve_table(REFERENCE_TABLES["product"])) \
            .where(F.col("is_current"))
        # keep the identifier columns in base; record_evidence drops the extras
        base = prod_ref.select(
            F.col("product_ref_id").alias("entity_ref_id"),
            F.col("product_reference_version_id").alias("reference_version_id"),
            F.lit("silver.product_reference").alias("source_table"),
            "source_file_version_id",
            F.lit(None).cast("bigint").alias("source_row_number"),
            "pip_code_canonical", "aah_product_code", "williams_product_name",
            "sku")
        self.record_evidence("product", rules["PIP_EXACT"], base.withColumn(
            "source_identifier_value", F.col("pip_code_canonical")))
        self.record_evidence("product", rules["AAH_CODE_VIA_MASTER"],
                             base.withColumn("source_identifier_value",
                                             F.col("aah_product_code"))
                             .where(F.col("source_identifier_value").isNotNull()))
        # Williams lines are looked up in these same forms (silver/williams.py)
        self.record_evidence("product", rules["WILLIAMS_NAME_EXACT"],
                             base.withColumn("source_identifier_value",
                                             normalised_name(
                                                 F.col("williams_product_name")))
                             .where(F.col("source_identifier_value").isNotNull()))
        # inactive candidate evidence until the material code rule is activated
        self.record_evidence("product", rules["WILLIAMS_MATERIAL_CODE_VIA_SKU"],
                             base.withColumn("source_identifier_value",
                                             canonical_code(F.col("sku")))
                             .where(F.col("source_identifier_value").isNotNull()))

    def register_accounts(self, observed: DataFrame, identifier_type: str) -> None:
        """Register the accounts seen on these lines and record their codes."""
        rules = {r.rule_id: r for r in self.ctx.resolution_rules}
        rule = {"AAH_ACCOUNT_NUMBER": rules["AAH_ACCOUNT_NUMBER"],
                "WILLIAMS_CUSTOMER_CODE": rules["WILLIAMS_CUSTOMER_CODE"],
                "PHOENIX_CUSTOMER_NUMBER": rules["PHOENIX_CUSTOMER_NUMBER"]
                }[identifier_type]
        self._register_namespaced("account", observed, rule,
                                  "account_identifier_type",
                                  ACCOUNT_CODE_COLUMNS[identifier_type])

    def register_locations(self, observed: DataFrame,
                           identifier_type: str) -> None:
        """Register the locations seen on these lines and record their codes."""
        rules = {r.rule_id: r for r in self.ctx.resolution_rules}
        rule = {"PHOENIX_LOCATION_NUMBER": rules["PHOENIX_LOCATION_NUMBER"]
                }[identifier_type]
        self._register_namespaced("stock_location", observed, rule,
                                  "location_identifier_type",
                                  LOCATION_CODE_COLUMNS[identifier_type])

    def _register_namespaced(self, entity_type: str, observed: DataFrame,
                             rule: ResolutionRule, type_col: str,
                             code_col: str) -> None:
        self.build_observed_reference(entity_type, observed, rule)
        d = REFERENCE_DEFS[entity_type]
        reference = REFERENCE_TABLES[entity_type]
        ref = (self.spark.table(self.cfg.resolve_table(reference))
               .where(F.col("is_current")
                      & (F.col(type_col) == rule.identifier_type)))
        self.record_evidence(entity_type, rule, ref.select(
            F.col(d.ref_id_col).alias("entity_ref_id"),
            F.col(d.version_id_col).alias("reference_version_id"),
            F.lit(reference).alias("source_table"),
            "source_file_version_id",
            F.lit(None).cast("bigint").alias("source_row_number"),
            F.col(code_col).alias("source_identifier_value")))

    def record_article_codes(self, lines: DataFrame) -> tuple[int, list[str]]:
        """Record article codes against the product their line's PIP matched."""
        rules = {r.rule_id: r for r in self.ctx.resolution_rules}
        rule = rules["SAME_LINE_PIP"]
        seen = (lines
                .where(F.col("article_code").isNotNull()
                       & F.col("product_ref_id").isNotNull())
                .groupBy("article_code")
                .agg(F.array_sort(F.collect_set("product_ref_id")).alias("_refs"),
                     F.max("source_file_version_id")
                     .alias("source_file_version_id")))
        held = (self.spark.table(self._ensure(EVIDENCE_TABLE))
                .where((F.col("entity_type") == "product")
                       & (F.col("source_identifier_type") == ARTICLE_CODE_TYPE)
                       & (F.col("source_table") == ARTICLE_CODE_SOURCE))
                .select(F.col("source_identifier_value").alias("article_code"),
                        F.col("entity_ref_id").alias("_held_ref"),
                        F.col("is_active").alias("_held_active")))
        codes = seen.join(held, "article_code", "left")
        one_product = F.size("_refs") == 1
        new_code = F.col("_held_ref").isNull()
        agrees = F.col("_held_active") & (F.col("_held_ref") == F.col("_refs")[0])
        disagrees = F.col("_held_active") & ~agrees

        def evidence(df: DataFrame, ref: Column) -> DataFrame:
            return df.select(
                ref.alias("entity_ref_id"),
                F.lit(None).cast("string").alias("reference_version_id"),
                F.lit(ARTICLE_CODE_SOURCE).alias("source_table"),
                "source_file_version_id",
                F.lit(None).cast("bigint").alias("source_row_number"),
                F.col("article_code").alias("source_identifier_value"))

        # NULL-safe: _held_active is NULL for a code never seen before
        good = codes.where(one_product & (new_code | F.coalesce(agrees, F.lit(False))))
        clash = codes.where((~one_product & (new_code | F.coalesce(
                                 F.col("_held_active"), F.lit(False))))
                            | F.coalesce(one_product & disagrees, F.lit(False)))
        recorded = good.count()
        if recorded:
            self.record_evidence("product", rule,
                                 evidence(good, F.col("_refs")[0]))
        unmatched = sorted(r[0] for r in clash.select("article_code").collect())
        if unmatched:
            self.record_evidence(
                "product", rule,
                evidence(clash, F.coalesce(F.col("_held_ref"), F.col("_refs")[0])),
                active=False)
        return recorded, unmatched
