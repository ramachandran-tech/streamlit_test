"""Row rules for the sales feeds, in the platform's dq vocabulary."""
from __future__ import annotations

from typing import Callable, Mapping

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F

# column holding the ids of the FAIL rules a line breaks (empty = clean)
REJECT_CODES = "_reject_codes"


def tag_rejects(df: DataFrame,
                rules: Mapping[str, Callable[[], Column]]) -> DataFrame:
    """Add the ids of the FAIL rules each row breaks."""
    codes = F.array_compact(F.array(*[
        F.when(rule(), F.lit(rule_id)) for rule_id, rule in rules.items()]))
    return df.withColumn(REJECT_CODES, codes)


def accepted(tagged: DataFrame) -> DataFrame:
    return tagged.where(F.size(REJECT_CODES) == 0).drop(REJECT_CODES)


def rejected(tagged: DataFrame) -> DataFrame:
    return tagged.where(F.size(REJECT_CODES) > 0)


def flag(df: DataFrame, rules: Mapping[str, Column]) -> DataFrame:
    """Add WARN rules on top of whatever dq the keys step already set."""
    no_codes = F.array().cast("array<string>")
    for rule_id, condition in rules.items():
        hit = F.coalesce(condition, F.lit(False))
        df = (df
              .withColumn("dq_error_codes", F.when(hit, F.array_union(
                  F.coalesce(F.col("dq_error_codes"), no_codes),
                  F.array(F.lit(rule_id)))).otherwise(F.col("dq_error_codes")))
              .withColumn("dq_status", F.when(hit, F.lit("WARNING"))
                          .otherwise(F.col("dq_status"))))
    return df
