"""SCD2 engine for masters and conformed references."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Sequence

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from ..common.hashing import align_to_spec, create_table_if_absent
from ..config.models import PlatformConfig, TableSpec


@dataclass(frozen=True)
class Scd2Def:
    entity: str  # product | account | stock_location | supplier
    version_id_col: str  # PK column name
    ref_id_col: str  # durable id column name
    business_key_cols: Sequence[str]
    attribute_cols: Sequence[str]  # tracked for change detection
    business_key_out: str | None = None  # optional <x>_business_key column
    latest_cols: Sequence[str] = ()  # updated in place; not in change detection


def durable_ref_id(entity: str, bk_concat) -> F.Column:
    return F.sha2(F.concat_ws("|", F.lit(entity), bk_concat), 256)


def _refresh_latest(spark: SparkSession, physical: str, d: Scd2Def,
                    unchanged: DataFrame) -> None:
    """Update latest-value columns of unchanged open versions in place."""
    same = " AND ".join(f"`{c}` <=> `_cur_{c}`" for c in d.latest_cols)
    stale = (unchanged.where(~F.expr(same))
             .select(F.col("_cur_version").alias("_scd2_version"),
                     *d.latest_cols))
    if stale.limit(1).count() == 0:
        return
    stale.createOrReplaceTempView("_scd2_latest")
    sets = ", ".join(f"t.`{c}` = s.`{c}`" for c in d.latest_cols)
    spark.sql(f"""
        MERGE INTO {physical} t USING _scd2_latest s
        ON t.`{d.version_id_col}` = s._scd2_version
        WHEN MATCHED THEN UPDATE SET {sets}, t.processed_at = current_timestamp()""")


def apply_scd2(spark: SparkSession, cfg: PlatformConfig, spec: TableSpec,
               d: Scd2Def, incoming: DataFrame) -> int:
    """Merge one snapshot of members into the SCD2 table."""
    physical = create_table_if_absent(spark, cfg, spec)

    bk_concat = F.concat_ws("|", *[F.col(c).cast("string")
                                   for c in d.business_key_cols])
    hash_diff = F.sha2(F.concat_ws("|", *[
        F.coalesce(F.col(c).cast("string"), F.lit("\u0000"))
        for c in d.attribute_cols]), 256)

    inc = (incoming
           .withColumn("_bk", bk_concat)
           .withColumn(d.ref_id_col, durable_ref_id(d.entity, F.col("_bk")))
           .withColumn("hash_diff", hash_diff)
           .dropDuplicates(["_bk"]))
    if d.business_key_out:
        inc = inc.withColumn(d.business_key_out, F.col("_bk"))

    current = (spark.table(physical).where(F.col("is_current"))
               .select(F.col(d.ref_id_col).alias("_cur_ref"),
                       F.col(d.version_id_col).alias("_cur_version"),
                       F.col("hash_diff").alias("_cur_hash"),
                       *[F.col(c).alias(f"_cur_{c}") for c in d.latest_cols]))

    joined = inc.join(current, inc[d.ref_id_col] == current["_cur_ref"], "left")
    changed = joined.where(F.col("_cur_ref").isNotNull()
                           & (F.col("hash_diff") != F.col("_cur_hash")))
    brand_new = joined.where(F.col("_cur_ref").isNull())
    if d.latest_cols:
        _refresh_latest(spark, physical, d, joined.where(
            F.col("_cur_ref").isNotNull()
            & (F.col("hash_diff") == F.col("_cur_hash"))))

    now = F.current_timestamp()
    backdate = F.to_timestamp(F.lit(cfg.backdate_first_version_ts))

    def _version(df: DataFrame, eff_from) -> DataFrame:
        out = (df.withColumn("effective_from_ts", eff_from)
                 .withColumn("effective_to_ts", F.lit(None).cast("timestamp"))
                 .withColumn("recorded_at_ts", now)
                 .withColumn("is_current", F.lit(True))
                 .withColumn("processed_at", now)
                 .withColumn(d.version_id_col, F.sha2(F.concat_ws(
                     "|", F.col("_bk"),
                     F.date_format("effective_from_ts",
                                   "yyyy-MM-dd'T'HH:mm:ss")), 256)))
        return align_to_spec(out, spec)

    new_versions = _version(brand_new, backdate).unionByName(
        _version(changed, now))
    n = new_versions.count()
    if n == 0:
        return 0

    # One MERGE closes the superseded versions and inserts the new ones
    closes = changed.select(F.col("_cur_version").alias("_close_version")) \
        .distinct()
    staged = (new_versions.withColumn("_close_version", F.lit(None).cast("string"))
              .unionByName(closes, allowMissingColumns=True))
    staged.createOrReplaceTempView("_scd2_stage")
    cols = ", ".join(f"`{c}`" for c in spec.column_names)
    vals = ", ".join(f"s.`{c}`" for c in spec.column_names)
    spark.sql(f"""
        MERGE INTO {physical} t USING _scd2_stage s
        ON t.`{d.version_id_col}` = s._close_version
        WHEN MATCHED THEN UPDATE SET
            t.effective_to_ts = current_timestamp(), t.is_current = false
        WHEN NOT MATCHED AND s._close_version IS NULL THEN
            INSERT ({cols}) VALUES ({vals})""")
    return n
