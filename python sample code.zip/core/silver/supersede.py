"""Which delivery keeps a scope when two of them cover it."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Hashable, Iterable, Mapping


@dataclass(frozen=True, order=True)
class FileRank:
    """How a delivery ranks against another one claiming the same scope."""

    priority: int
    received_ts: datetime
    version_id: str


def claim_scopes(incoming: FileRank, scopes: Iterable[Hashable],
                 holders: Mapping[Hashable, Iterable[FileRank]]
                 ) -> tuple[list, list]:
    """Split the incoming file's ``scopes`` into (won, lost)."""
    won: list = []
    lost: list = []
    for scope in sorted(set(scopes)):
        rivals = [h for h in holders.get(scope, ())
                  if h.version_id != incoming.version_id]
        (won if all(incoming > r for r in rivals) else lost).append(scope)
    return won, lost


def date_span(first: date, last: date) -> list[date]:
    """Every date from ``first`` to ``last``, both included."""
    if last < first:
        raise ValueError(f"date span ends ({last}) before it starts ({first})")
    return [first + timedelta(days=n) for n in range((last - first).days + 1)]
