"""Weekly report: bronze JSON payload -> measure rows + period totals."""
from __future__ import annotations

from typing import Mapping

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql import types as T

from ..config.models import PlatformConfig, SourceSpec
from .cleaning import canonical_code, clean_date, clean_numeric


def _metric_type_expr(header_suffix: F.Column,
                      metric_map: Mapping[str, str]) -> F.Column:
    expr = F.lit(None).cast("string")
    for suffix, code in metric_map.items():
        expr = F.when(F.trim(header_suffix) == suffix, F.lit(code)).otherwise(expr)
    return expr


def explode_weekly(bronze_df: DataFrame, source: SourceSpec,
                   cfg: PlatformConfig) -> tuple[DataFrame, DataFrame]:
    """Return (measure_rows, total_rows) from bronze weekly rows."""
    p = source.parse
    week_re = p["week_header_pattern"]
    total_re = p["total_header_pattern"]
    metric_map: Mapping[str, str] = p["metric_header_map"]

    payload = F.from_json(F.col("weekly_measure_columns_raw"),
                          T.MapType(T.StringType(), T.StringType()))
    exploded = (bronze_df
                .withColumn("_m", payload)
                .select("*", F.explode("_m").alias("_header", "_value"))
                .drop("_m"))

    common = (exploded
              .withColumn("report_period_start_date",
                          clean_date(F.col("period_start_date_raw"), cfg))
              .withColumn("report_period_end_date",
                          clean_date(F.col("period_end_date_raw"), cfg))
              .withColumn("product_code", F.nullif(F.trim("product_code_raw"), F.lit("")))
              .withColumn("product_name", F.nullif(F.trim("product_name_raw"), F.lit("")))
              .withColumn("pip_code", F.nullif(F.trim("pip_code_raw"), F.lit("")))
              .withColumn("pip_code_canonical", canonical_code(F.col("pip_code_raw")))
              .withColumn("location_code", F.nullif(F.trim("location_code_raw"), F.lit("")))
              .withColumn("supplier_code", F.nullif(F.trim("supplier_code_raw"), F.lit("")))
              .withColumn("metric_value", clean_numeric(F.col("_value"), "decimal(18,3)"))
              .withColumn("source_metric_header", F.col("_header")))

    is_week = F.col("_header").rlike(week_re)
    is_total = F.col("_header").rlike(total_re)

    weeks = (common.where(is_week)
             .withColumn("target_week_number",
                         F.regexp_extract("_header", week_re, 1).cast("int"))
             .withColumn("_wk_year",
                         F.regexp_extract("_header", week_re, 2).cast("int"))
             .withColumn("_wk_day",
                         F.regexp_extract("_header", week_re, 3).cast("int"))
             .withColumn("_wk_month",
                         F.regexp_extract("_header", week_re, 4).cast("int"))
             .withColumn("target_week_start_date",
                         F.make_date("_wk_year", "_wk_month", "_wk_day"))
             .withColumn("metric_type", _metric_type_expr(
                 F.regexp_extract("_header", week_re, 5), metric_map))
             .where(F.col("metric_type").isNotNull()))

    totals = (common.where(is_total & ~is_week)
              .withColumn("metric_type", _metric_type_expr(
                  F.regexp_extract("_header", total_re, 1), metric_map))
              .where(F.col("metric_type").isNotNull()))
    return weeks, totals


def reconcile_weeks_vs_totals(measures: DataFrame, totals: DataFrame) -> DataFrame:
    """Per product/location/supplier/metric: SUM(week values) vs reported total."""
    grain = ["report_period_end_date", "product_code", "location_code",
             "supplier_code", "metric_type"]
    summed = (measures.groupBy(*grain)
              .agg(F.sum("metric_value").alias("sum_week_value")))
    reported = totals.select(*grain,
                             F.col("metric_value").alias("reported_total"))
    return (summed.join(reported, grain, "full_outer")
            .withColumn("difference",
                        F.coalesce(F.col("sum_week_value"), F.lit(0))
                        - F.coalesce(F.col("reported_total"), F.lit(0))))
