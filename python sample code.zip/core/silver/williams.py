"""Williams sales: one feed, two file layouts, one table."""
from __future__ import annotations

from typing import Callable, Mapping, Sequence

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F

from ..config.models import PlatformConfig, SourceSpec, TableSpec
from . import cleaning, row_rules
from .cleaning import ISO_DATE                     # noqa: F401  (kept importable here)
from .row_rules import REJECT_CODES, accepted, rejected   # noqa: F401

# Built lazily: a Column can only be created once a Spark session exists.
FAIL_RULES: Mapping[str, Callable[[], Column]] = {
    "DQ_WILLIAMS_INVOICE_DATE_INVALID": lambda: F.col("invoice_date").isNull(),
    "DQ_WILLIAMS_SALES_QTY_INVALID": lambda: F.col("sales_qty").isNull(),
    "DQ_WILLIAMS_NO_PRODUCT_IDENTIFIER": lambda: (
        F.col("material_code").isNull() & F.col("material_description").isNull()),
}

NEGATIVE_QTY = "DQ_WILLIAMS_NEGATIVE_QTY"  # usually a return - kept
UNLISTED_CLASS = "DQ_WILLIAMS_CUSTOMER_CLASS_UNLISTED"


def invoice_date(source: SourceSpec, cfg: PlatformConfig) -> Column:
    """invoice_date_raw parsed with the date format of the row's own layout."""
    return cleaning.layout_date(F.col("invoice_date_raw"), source, cfg)


def clean(bronze: DataFrame, spec: TableSpec, source: SourceSpec,
          cfg: PlatformConfig) -> DataFrame:
    """Bronze rows -> typed silver columns (keys and audit columns come later)."""
    return cleaning.map_clean_columns(
        bronze, spec, cfg, overrides={"invoice_date": invoice_date(source, cfg)})


def tag_rejects(df: DataFrame) -> DataFrame:
    """Add the ids of the FAIL rules each row breaks (empty array = clean)."""
    return row_rules.tag_rejects(df, FAIL_RULES)


def flag_warnings(df: DataFrame,
                  accepted_classes: Sequence[str] = ()) -> DataFrame:
    """Add the WARN rules on top of whatever dq the keys step already set."""
    rules = {NEGATIVE_QTY: F.col("sales_qty") < 0}
    if accepted_classes:
        rules[UNLISTED_CLASS] = (F.col("customer_class").isNotNull()
                                 & ~F.col("customer_class").isin(*accepted_classes))
    return row_rules.flag(df, rules)


def product_match_keys(df: DataFrame) -> DataFrame:
    """The two values a Williams line is matched to a product on."""
    return (df
            .withColumn("_material_code_key",
                        cleaning.canonical_code(F.col("material_code")))
            .withColumn("_material_name_key",
                        cleaning.normalised_name(F.col("material_description"))))
