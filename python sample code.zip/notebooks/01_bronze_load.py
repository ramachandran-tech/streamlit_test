# Databricks notebook source
# MAGIC %md
# MAGIC # 01 - Bronze load
# MAGIC Land each source file into its raw Delta table, as delivered.
# MAGIC
# MAGIC Parameters: `run_id`, `run_mode`, `entities`, `config_root`.

# COMMAND ----------

# MAGIC %pip install pyyaml==6.0.2 openpyxl==3.1.5 --quiet

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

import fnmatch
import os
import sys
import uuid

# make the repo importable when run from a workspace folder
_here = os.getcwd()
_root = os.path.dirname(_here) if os.path.basename(_here) == "notebooks" else _here
if _root not in sys.path:
    sys.path.insert(0, _root)

from core.bronze.loader import BronzeLoader
from core.common.audit import OpsStore
from core.common.hashing import ensure_schemas
from core.config.loader import ConfigContext
from core.config.models import LoadMode

# COMMAND ----------

# date-parser policy the cleaning rules need (best-effort)
try:
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")  # noqa: F821
except Exception as _cfg_err:
    print(f"[setup] timeParserPolicy not settable on this compute: {_cfg_err}")

# COMMAND ----------

dbutils.widgets.text("run_id", "", "Run id ({{job.run_id}} in jobs)")  # noqa: F821
dbutils.widgets.dropdown("run_mode", "incremental",  # noqa: F821
                         ["incremental", "historical"], "Load mode")
dbutils.widgets.text("entities", "all", "Entities (all or CSV)")  # noqa: F821
dbutils.widgets.text("config_root", "", "Config root (blank = <repo>/conf)")  # noqa: F821
dbutils.widgets.dropdown("seed_sample_data", "no", ["no", "yes"],  # noqa: F821
                         "Copy bundled sample workbooks into landing_root")

run_id = dbutils.widgets.get("run_id") or f"manual-{uuid.uuid4()}"  # noqa: F821
run_mode = LoadMode(dbutils.widgets.get("run_mode"))  # noqa: F821
entities_arg = dbutils.widgets.get("entities")  # noqa: F821
entities = None if entities_arg.strip().lower() in ("", "all") \
    else [e.strip() for e in entities_arg.split(",")]
config_root = dbutils.widgets.get("config_root") or os.path.join(_root, "conf")  # noqa: F821

ctx = ConfigContext.from_yaml(config_root)
print(f"run_id={run_id} mode={run_mode.value} entities={entities or 'all'} "
      f"env={ctx.platform.environment}")

# COMMAND ----------

# optionally copy the sample workbooks into an empty landing root
seed = dbutils.widgets.get("seed_sample_data").strip().lower() == "yes"  # noqa: F821
sample_root = os.path.join(_root, "sample_data")
landing = ctx.platform.landing_root
try:
    existing = dbutils.fs.ls(landing)  # noqa: F821
except Exception:
    existing = []
if seed and not existing and os.path.isdir(sample_root):
    seeded = 0
    for entity_dir in os.listdir(sample_root):
        src = os.path.join(sample_root, entity_dir)
        for fname in os.listdir(src):
            owner = next((s for s in ctx.sources()
                          if fnmatch.fnmatchcase(fname, s.file_glob)), None)
            if owner is None:
                continue
            dbutils.fs.cp(f"file:{os.path.join(src, fname)}",  # noqa: F821
                          f"{owner.landing_path(ctx.platform)}/{fname}")
            seeded += 1
    print(f"Seeded {seeded} sample workbook(s) into {landing} "
          f"(layout={ctx.platform.landing_layout})")

# COMMAND ----------

ensure_schemas(spark, ctx.platform)  # noqa: F821
ops = OpsStore(spark, ctx.platform, run_id,  # noqa: F821
               config_fingerprint=ctx.config_fingerprint)
ops.ensure_tables()

BronzeLoader(spark, ctx, ops).run(entities, run_mode)  # noqa: F821
print("Bronze load complete")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Schema drift for this run
# MAGIC Header findings for this run.

# COMMAND ----------

drift = (spark.table(ctx.platform.resolve_table("ops.schema_drift_audit"))  # noqa: F821
         .where(f"run_id = '{run_id}'"))
if drift.count():
    display(drift.select("entity", "severity", "event_type", "target_column",  # noqa: F821
                         "source_header", "matched_via", "match_confidence",
                         "column_qualifier", "detail")
                 .orderBy("severity", "entity"))
else:
    print("No schema drift in this run")
