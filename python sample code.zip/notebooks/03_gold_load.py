# Databricks notebook source
# MAGIC %md
# MAGIC # 03 - Gold load
# MAGIC Publish the dimensions and build the facts and views.
# MAGIC
# MAGIC Parameters: `run_id`, `run_mode`, `entities`, `config_root`.

# COMMAND ----------

# MAGIC %pip install pyyaml==6.0.2 --quiet

# COMMAND ----------

dbutils.library.restartPython()  # noqa: F821

# COMMAND ----------

import os
import sys
import uuid

# make the repo importable when run from a workspace folder
_here = os.getcwd()
_root = os.path.dirname(_here) if os.path.basename(_here) == "notebooks" else _here
if _root not in sys.path:
    sys.path.insert(0, _root)

from core.gold.loader import GoldLoader
from core.common.audit import OpsStore
from core.common.hashing import ensure_schemas
from core.config.loader import ConfigContext
from core.config.models import LoadMode

# COMMAND ----------

# date-parser policy the cleaning rules need (best-effort)
try:
    spark.conf.set("spark.sql.legacy.timeParserPolicy", "LEGACY")  # noqa: F821
except Exception as _cfg_err:
    print(f"[setup] timeParserPolicy not settable on this compute: {_cfg_err}")

# COMMAND ----------

dbutils.widgets.text("run_id", "", "Run id ({{job.run_id}} in jobs)")  # noqa: F821
dbutils.widgets.dropdown("run_mode", "incremental",  # noqa: F821
                         ["incremental", "historical"], "Load mode")
dbutils.widgets.text("entities", "all", "Entities (all or CSV)")  # noqa: F821
dbutils.widgets.text("config_root", "", "Config root (blank = <repo>/conf)")  # noqa: F821

run_id = dbutils.widgets.get("run_id") or f"manual-{uuid.uuid4()}"  # noqa: F821
run_mode = LoadMode(dbutils.widgets.get("run_mode"))  # noqa: F821
entities_arg = dbutils.widgets.get("entities")  # noqa: F821
entities = None if entities_arg.strip().lower() in ("", "all") \
    else [e.strip() for e in entities_arg.split(",")]
config_root = dbutils.widgets.get("config_root") or os.path.join(_root, "conf")  # noqa: F821

ctx = ConfigContext.from_yaml(config_root)
print(f"run_id={run_id} mode={run_mode.value} entities={entities or 'all'} "
      f"env={ctx.platform.environment}")

# COMMAND ----------

ensure_schemas(spark, ctx.platform)  # noqa: F821
ops = OpsStore(spark, ctx.platform, run_id,  # noqa: F821
               config_fingerprint=ctx.config_fingerprint)
ops.ensure_tables()

GoldLoader(spark, ctx, ops).run(entities, run_mode)  # noqa: F821
print("Gold load complete")
