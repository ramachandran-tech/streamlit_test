#!/usr/bin/env python3
"""One-time bootstrap: catalogue workbook -> conf/tables/<layer>/*.yaml."""
from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Any

import yaml
from openpyxl import load_workbook

AUDIT_ROLES = {"Audit / lineage / SCD control", "Data quality control"}

# Assumed workbook column layout (0-based), by the columns this reads
_EMPTY = ("", "—", "-", "None", "none")


def _clean(cell: Any) -> str:
    """Trimmed cell text, or '' for blanks and the workbook's dash placeholders."""
    text = str(cell if cell is not None else "").strip()
    return "" if text in _EMPTY else text


def _key_flags(key_role: str) -> dict[str, Any]:
    kr = (key_role or "").strip()
    out: dict[str, Any] = {}
    if kr in ("", "—", "-"):
        return out
    low = kr.lower()
    if low.startswith("pk"):
        out["pk"] = True
    if "bk component" in low or "bk input" in low:
        out["bk"] = True
        if "null-safe" in low:
            out["null_safe"] = True
    if low.startswith("fk") or "fk ->" in low:
        m = re.search(r"FK\s*->\s*([A-Za-z0-9_.]+)", kr)
        if m:
            out["fk"] = m.group(1)
    if "durable entity id" in low:
        out["durable_ref"] = True
    if "supersede scope key" in low:
        out["supersede_scope"] = True
    out["key_role"] = kr
    return out


def _column_spec(sheet: str, r: list[Any]) -> dict[str, Any]:
    col, dtype, nullable = str(r[2]), str(r[4]), str(r[5])
    spec: dict[str, Any] = {"name": col, "type": dtype, "nullable": nullable == "Yes"}
    spec.update(_key_flags(str(r[6] or "")))
    role = _clean(r[7])
    if role in AUDIT_ROLES:
        spec["column_class"] = "audit"
    if role:
        spec["column_role"] = role
    src_table, src_col = _clean(r[9]), _clean(r[10])
    if src_table:
        spec["source_table"] = src_table
    if src_col:
        spec["source_column"] = src_col
    if sheet == "Bronze" and src_col:
        spec["source_header"] = src_col
    transform = _clean(r[8])
    if transform:
        spec["transform"] = transform
    return spec


def generate(xlsx: Path, out_dir: Path) -> None:
    wb = load_workbook(xlsx, read_only=True)
    for sheet in ("Bronze", "Silver", "Gold"):
        ws = wb[sheet]
        tables: dict[str, list[dict[str, Any]]] = {}
        for row in ws.iter_rows(values_only=True):
            r = (list(row) + [None] * 15)[:15]
            if r[0] not in ("Bronze", "Silver", "Gold") or not r[1] or not r[2]:
                continue
            tables.setdefault(str(r[1]), []).append(_column_spec(sheet, r))
        layer_dir = out_dir / sheet.lower()
        layer_dir.mkdir(parents=True, exist_ok=True)
        for name, columns in tables.items():
            fname = name.split(".", 1)[1] if "." in name else name
            header = (f"# {name} - one table per file (config is the source of "
                      f"truth).\n# design baseline: V16 (bootstrapped from "
                      f"{xlsx.name}).\n")
            body = yaml.safe_dump({name: {"columns": columns}}, sort_keys=False,
                                  width=110, allow_unicode=True)
            (layer_dir / f"{fname}.yaml").write_text(header + body, encoding="utf-8")
        print(f"{layer_dir}: {len(tables)} tables, "
              f"{sum(len(c) for c in tables.values())} columns")


if __name__ == "__main__":
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
        "Vendor_Data_Ingestion_3_Layer_Key_Mapping_V16.xlsx")
    dst = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("conf/tables")
    generate(src, dst)
