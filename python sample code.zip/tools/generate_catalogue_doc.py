#!/usr/bin/env python3
"""Generate the client-facing column catalogue from the YAML."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

import yaml
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[1]

# (yaml key, column header) in emit order - the reverse of what the bootstrap read
COLUMNS: list[tuple[str, str]] = [
    ("_table", "Table"),
    ("name", "Column"),
    ("type", "Type"),
    ("nullable", "Nullable"),
    ("key_role", "Key Role"),
    ("column_role", "Column Role"),
    ("source_table", "Source Table"),
    ("source_column", "Source Column"),
    ("source_header", "Source Header"),
    ("bk_order", "BK Order"),
    ("transform", "Transform"),
]
_HEAD_FILL = PatternFill("solid", fgColor="1F3864")
_HEAD_FONT = Font(color="FFFFFF", bold=True)


def _load_layer(tables_dir: Path, layer: str) -> dict[str, list[dict[str, Any]]]:
    """logical table name -> its column dicts, read from conf/tables/<layer>/."""
    out: dict[str, list[dict[str, Any]]] = {}
    layer_dir = tables_dir / layer
    for path in sorted(layer_dir.glob("*.yaml")):
        doc = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        for name, tspec in doc.items():
            out[name] = tspec.get("columns", [])
    return out


def _cell(col_key: str, column: dict[str, Any], table: str) -> Any:
    if col_key == "_table":
        return table
    val = column.get(col_key)
    if col_key == "nullable":
        return "Yes" if val else "No"
    return "" if val is None else val


def _write_sheet(ws, tables: dict[str, list[dict[str, Any]]]) -> None:
    ws.append([h for _, h in COLUMNS])
    for c in range(1, len(COLUMNS) + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill, cell.font = _HEAD_FILL, _HEAD_FONT
    ws.freeze_panes = "A2"
    for table, columns in tables.items():
        for column in columns:
            ws.append([_cell(k, column, table) for k, _ in COLUMNS])
    for i, (_, h) in enumerate(COLUMNS, start=1):
        width = max(len(h), *(len(str(ws.cell(row=r, column=i).value or ""))
                              for r in range(2, ws.max_row + 1)), 8)
        ws.column_dimensions[get_column_letter(i)].width = min(width + 2, 60)
        if h in ("Transform", "Source Table", "Source Column"):
            for r in range(2, ws.max_row + 1):
                ws.cell(row=r, column=i).alignment = Alignment(wrap_text=True,
                                                               vertical="top")


def generate(tables_dir: Path, out_path: Path) -> None:
    wb = Workbook()
    wb.remove(wb.active)
    total = 0
    for layer in ("bronze", "silver", "gold"):
        tables = _load_layer(tables_dir, layer)
        ws = wb.create_sheet(layer.capitalize())
        _write_sheet(ws, tables)
        n = sum(len(c) for c in tables.values())
        total += n
        print(f"{layer}: {len(tables)} tables, {n} columns")
    out_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out_path)
    print(f"\nwrote {out_path} ({total} columns across 3 layers)")


if __name__ == "__main__":
    src = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "conf" / "tables"
    dst = Path(sys.argv[2]) if len(sys.argv) > 2 else \
        ROOT / "build" / "Vendor_Data_Catalogue.xlsx"
    generate(src, dst)
