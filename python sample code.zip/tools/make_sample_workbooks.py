#!/usr/bin/env python3
"""Build the sample .xlsx feeds from their .csv seeds."""
from __future__ import annotations

import csv
import re
import sys
from pathlib import Path

import yaml
from openpyxl import Workbook
from openpyxl.utils import get_column_letter

ROOT = Path(__file__).resolve().parents[1]

# sheet name per landing folder; anything else uses the platform default tab
SHEET_BY_FOLDER = {"weekly_report": "Weekly Report",
                   "phoenix_sales": "SalesByChannel_Bayer"}
DEFAULT_SHEET = "Data"

# tabs written ahead of the data tab, as the vendor's workbook has them.
TABS_BEFORE = {
    "phoenix_sales": [("SalesByChannel", [
        ["Date", "ArtCode", "Pipcode", "ProductDesc", "EAN", "LocNo", "LocName",
         "CustomerChannel", "CuNo", "CuName", "CuPCode", "SalesQty",
         "SalesValue"],
        ["13/07/2026", "PX-7001", "7654321", "Other Maker Syrup", "", "101",
         "Phoenix Leeds", "Independent", "C-5001", "Moor Pharmacy", "LS6 2AB",
         "40", "120.00"],
        ["14/07/2026", "PX-7002", "7654322", "Other Maker Gel", "", "102",
         "Phoenix York", "Hospital", "C-5002", "St Mary Hospital", "YO1 7HH",
         "25", "80.00"],
    ])],
}

# folders whose header is split over two rows, with the group label merged
TWO_ROW_HEADER = {"weekly_report"}


def _weekly_patterns() -> list[tuple[str, int]]:
    """(regex, group holding the metric suffix) from the weekly feed's config."""
    doc = yaml.safe_load((ROOT / "conf" / "sources.yaml").read_text(encoding="utf-8"))
    parse = doc["sources"]["weekly_report"]["parse"]
    return [(parse["week_header_pattern"], 5), (parse["total_header_pattern"], 1)]


def _split_header(header: str, patterns: list[tuple[str, int]]) -> tuple[str, str]:
    """"Wk 29/2026 (13/7) Last Year" -> ("Wk 29/2026 (13/7)", "Last Year")."""
    for pattern, group in patterns:
        m = re.match(pattern, header)
        if m:
            return header[:m.start(group)].strip(), m.group(group)
    return header, ""  # a fixed column: label only, row 1


def _write_single_header(ws, rows: list[list[str]]) -> None:
    for row in rows:
        ws.append(row)


def _write_two_row_header(ws, rows: list[list[str]],
                          patterns: list[tuple[str, int]]) -> None:
    headers = rows[0]
    groups = [_split_header(h, patterns) for h in headers]
    ws.append([g or None for g, _ in groups])
    ws.append([m or None for _, m in groups])
    for row in rows[1:]:
        ws.append(row)

    # merge each run of repeated group labels, as a vendor's export would
    start = 0
    for i in range(1, len(groups) + 1):
        same = i < len(groups) and groups[i][0] == groups[start][0] \
            and groups[i][1]  # only metric columns group
        if not same:
            if i - start > 1:
                ws.merge_cells(start_row=1, start_column=start + 1,
                               end_row=1, end_column=i)
            start = i


def convert(csv_path: Path, patterns: list[tuple[str, int]]) -> Path:
    with csv_path.open(newline="", encoding="utf-8-sig") as fh:
        rows = [r for r in csv.reader(fh) if any(c.strip() for c in r)]
    if not rows:
        raise ValueError(f"{csv_path} has no rows")

    folder = csv_path.parent.name
    wb = Workbook()
    wb.remove(wb.active)
    for title, tab_rows in TABS_BEFORE.get(folder, ()):
        _write_single_header(wb.create_sheet(title), tab_rows)
    ws = wb.create_sheet(SHEET_BY_FOLDER.get(folder, DEFAULT_SHEET))
    if folder in TWO_ROW_HEADER:
        _write_two_row_header(ws, rows, patterns)
    else:
        _write_single_header(ws, rows)
    for c in range(1, len(rows[0]) + 1):
        ws.column_dimensions[get_column_letter(c)].width = 22

    out = csv_path.with_suffix(".xlsx")
    wb.save(out)
    return out


# -- Complex-layout sample builders ------------------------------------------
_BANNER = ("The information and calculation results in this sheet were produced "
           "by RELEX solutions.")
_PERIOD_START = "06-Jul-26"
_PERIOD_END = "12-Jul-26"

# stock, in the RELEX on-file column order (r4 name, or r3 where r4 is blank)
_STOCK_R3 = {0: "PIP code", 1: "Location info", 3: "Product info",
             6: "Stocks and orders", 18: "Block and comments",
             20: "Product info", 26: "Review  days and order cycle",
             33: "AAH product owner"}
_STOCK_R4 = [
    None, "Location name", "Location code", "Product code", "Product name",
    "Pack size", "Average daily forecast (next 30 days)",
    "Next 14 Days Effective Forecast", "End balance", "Forecasted supply (days)",
    "End balance value", "Open purchase orders quantity",
    "Forecasted supply (days) with open orders", "Today's order Proposal",
    "Forecasted supply (days) with open orders and proposal",
    "Order proposal (value)", "Projected OOS next 7 days",
    "Projected lost sales next 7 days", "Product-location Block Start Date",
    "Product comments", "Purchase price", "Storage type", "Prom period",
    "Min. delivery", "Supplier code", "Supplier name", "[SL] Order (Mon)",
    "[SL] Order (Tue)", "[SL] Order (Wed)", "[SL] Order (Thu)",
    "[SL] Order (Fri)", "[SL] Lead time", "[SL] Order cycle", None]
_STOCK_ROWS = [
    ["123-4567", "Leeds", "LOC01", "APC001", "Paracetamol 500mg Tabs", "100",
     "12.5", "175", "480", "38.4", "£2,184.00", "200", "54.4", "0", "54.4",
     "£0.00", "0", "£0.00", "", "", "£4.55", "AMB", "", "10", "SUP01",
     "PharmaSupplies Ltd", "Y", "N", "Y", "N", "Y", "3", "7", "Owner A"],
    ["234-5678", "Leeds", "LOC01", "APC002", "Ibuprofen 200mg Tabs", "84",
     "8.2", "115", "60", "7.3", "£237.00", "150", "25.6", "50", "31.7",
     "£197.50", "1", "£32.30", "", "", "£3.95", "AMB", "", "10", "SUP01",
     "PharmaSupplies Ltd", "Y", "N", "Y", "N", "Y", "3", "7", "Owner A"],
    ["345-6789", "Manchester", "LOC02", "APC003", "Amoxicillin 250mg Caps", "21",
     "5.1", "71", "300", "58.8", "£2,340.00", "0", "58.8", "0", "58.8",
     "£0.00", "0", "£0.00", "", "", "£7.80", "COLD", "", "5", "SUP02",
     "MedSource plc", "N", "Y", "N", "Y", "N", "5", "7", "Owner B"],
    ["456-7890", "Manchester", "LOC02", "APC004", "Cetirizine 10mg Tabs", "30",
     "3.4", "48", "25", "7.4", "£81.25", "100", "36.8", "40", "48.5",
     "£130.00", "1", "£11.05", "", "", "£3.25", "AMB", "", "5", "SUP02",
     "MedSource plc", "N", "Y", "N", "Y", "N", "5", "7", "Owner B"],
]


def build_stock_relex(out: Path) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = DEFAULT_SHEET
    width = len(_STOCK_R4)
    ws.append([_BANNER])
    ws.append(["Period start date", _PERIOD_START, "Period end date", _PERIOD_END])
    ws.append([_STOCK_R3.get(i) for i in range(width)])  # r3 classification
    ws.append(list(_STOCK_R4))  # r4 column names
    ws.append(["#"] * 6 + [None] * (width - 6))  # r5 aggregate (skipped)
    for row in _STOCK_ROWS:
        ws.append(row)
    for c in range(1, width + 1):
        ws.column_dimensions[get_column_letter(c)].width = 20
    wb.save(out)
    return out


# weekly: 5 fixed dims, then a Total block and 3 week blocks (3 metrics each)
_WK_DIMS = ["Product code", "Product name", "PIP code", "Location code",
            "Supplier code"]
_WK_METRIC4 = ["Last Year", "AAH Sales Forecast", "AAH Purchase Order Forecast"]
_WK_METRIC5 = ["Sales quantity", None, None]
_WK_WEEKS = ["Wk 29/2026 (13/7)", "Wk 30/2026 (20/7)", "Wk 31/2026 (27/7)"]
# (dims, [[Total ly,asf,apo], [wk1...], [wk2...], [wk3...]]).
_WK_PRODUCTS = [
    (["APC001", "Paracetamol 500mg Tabs", "123-4567", "LOC01", "SUP01"],
     [[300, 330, 315], [100, 110, 105], [100, 110, 105], [100, 110, 105]]),
    (["APC002", "Ibuprofen 200mg Tabs", "234-5678", "LOC01", "SUP01"],
     [[240, 270, 255], [80, 90, 85], [80, 90, 85], [80, 90, 85]]),
    (["APC003", "Amoxicillin 250mg Caps", "345-6789", "LOC02", "SUP02"],
     [[150, 180, 165], [50, 60, 55], [50, 60, 55], [50, 60, 55]]),
    (["APC004", "Cetirizine 10mg Tabs", "", "LOC02", "SUP02"],
     [[90, 125, 105], [30, 40, 35], [30, 40, 35], [30, 40, 35]]),
]


def build_weekly_bayer(out: Path) -> Path:
    wb = Workbook()
    ws = wb.active
    ws.title = SHEET_BY_FOLDER.get("weekly_report", DEFAULT_SHEET)
    n_fixed = len(_WK_DIMS)
    n_blocks = 1 + len(_WK_WEEKS)  # Total + week blocks
    width = n_fixed + 3 * n_blocks
    ws.append([_BANNER])
    ws.append(["Period start date", _PERIOD_START, "Period end date", _PERIOD_END])
    r3 = [None] * width
    r3[0] = "Total"  # group label at col 0, as exported
    for bi, label in enumerate(_WK_WEEKS):
        r3[n_fixed + 3 * (bi + 1)] = label
    ws.append(r3)
    ws.append(list(_WK_DIMS) + _WK_METRIC4 * n_blocks)  # r4 metric name
    ws.append([None] * n_fixed + _WK_METRIC5 * n_blocks)  # r5 metric qualifier
    for dims, blocks in _WK_PRODUCTS:
        row = list(dims)
        for triple in blocks:
            row += [str(v) for v in triple]
        ws.append(row)
    for c in range(1, width + 1):
        ws.column_dimensions[get_column_letter(c)].width = 20
    wb.save(out)
    return out


# folders built by a dedicated complex-layout builder, not the CSV renderer
_COMPLEX_BUILDERS = {
    "stock": ("stock_2026-07-12.xlsx", build_stock_relex),
    "weekly_report": ("weekly_report_2026-07-12.xlsx", build_weekly_bayer),
}


def main(targets: list[str]) -> None:
    dirs = [Path(t).resolve() for t in targets] or [
        ROOT / "sample_data", ROOT / "tests" / "fixtures" / "drift"]
    patterns = _weekly_patterns()
    total = 0
    for d in dirs:
        for csv_path in sorted(d.rglob("*.csv")):
            if csv_path.parent.name in _COMPLEX_BUILDERS:
                continue  # handled by a complex builder
            out = convert(csv_path, patterns)
            print(f"{csv_path.relative_to(ROOT)} -> {out.name} "
                  f"[{out.stat().st_size:,} bytes]")
            total += 1
    # the two complex feeds, when sample_data is in scope
    for d in dirs:
        for folder, (fname, builder) in _COMPLEX_BUILDERS.items():
            target = d / folder
            if target.is_dir():
                out = builder(target / fname)
                print(f"{out.relative_to(ROOT)}  [{out.stat().st_size:,} bytes] "
                      f"(complex builder)")
                total += 1
    print(f"\n{total} workbook(s) written")


if __name__ == "__main__":
    main(sys.argv[1:])
