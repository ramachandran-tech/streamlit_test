#!/usr/bin/env python3
"""Validate the YAML config; exit non-zero on any failure."""
from __future__ import annotations

import re
import sys
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from core.config.loader import ConfigContext           # noqa: E402
from core.config.models import SourceSpec, TableSpec   # noqa: E402

# layout ids end up in SQL and in every bronze row's schema_version
_LAYOUT_ID = re.compile(r"[A-Z][A-Z0-9_]*")

_KNOWN_TYPES = ("string", "int", "integer", "bigint", "long", "smallint",
                "tinyint", "double", "float", "boolean", "date", "timestamp",
                "decimal", "array", "map", "struct", "binary")


def _type_ok(t: str) -> bool:
    t = (t or "").strip().lower()
    # a bare type, or a parameterised one: decimal(18,3), array<string>
    return any(t == base or t.startswith(base + "(") or t.startswith(base + "<")
               for base in _KNOWN_TYPES)


class Validator:
    def __init__(self, conf_dir: Path) -> None:
        self.ctx = ConfigContext.from_yaml(conf_dir)
        self.errors: list[str] = []
        self._table_names = {
            t.logical_name for layer in ("bronze", "silver", "gold")
            for t in self.ctx.tables_in_layer(layer)}

    def err(self, msg: str) -> None:
        self.errors.append(msg)

    # -- table / column shape ------------------------------------------------
    def check_tables(self) -> None:
        for layer in ("bronze", "silver", "gold"):
            for spec in self.ctx.tables_in_layer(layer):
                self._check_columns(spec)
                self._check_pk(layer, spec)
                self._check_fks(spec)
                self._check_key_recipe(spec)

    def _check_columns(self, spec: TableSpec) -> None:
        seen: set[str] = set()
        for c in spec.columns:
            where = f"{spec.logical_name}.{c.name or '<unnamed>'}"
            if not c.name:
                self.err(f"{spec.logical_name}: a column has no name")
            if not _type_ok(c.type):
                self.err(f"{where}: unparseable type {c.type!r}")
            if not isinstance(c.nullable, bool):
                self.err(f"{where}: nullable is not a bool")
            if c.name in seen:
                self.err(f"{spec.logical_name}: duplicate column '{c.name}'")
            seen.add(c.name)

    def _check_pk(self, layer: str, spec: TableSpec) -> None:
        pks = [c.name for c in spec.columns if c.pk]
        if layer == "bronze":
            if pks:
                self.err(f"{spec.logical_name}: bronze table must have no PK "
                         f"(keyed by file version), found {pks}")
            if not any(c.supersede_scope for c in spec.columns):
                self.err(f"{spec.logical_name}: bronze table has no "
                         f"supersede-scope column")
        elif len(pks) != 1:
            self.err(f"{spec.logical_name}: expected exactly one PK, found {pks}")

    def _check_fks(self, spec: TableSpec) -> None:
        for c in spec.columns:
            if not c.fk or "." not in c.fk:
                continue  # single-token fk = polymorphic marker
            parts = c.fk.split(".")
            table, col = ".".join(parts[:2]), parts[2] if len(parts) > 2 else None
            if table not in self._table_names:
                self.err(f"{spec.logical_name}.{c.name}: FK -> {c.fk} "
                         f"(no such table {table})")
            elif col and col not in self.ctx.table(table).column_names:
                self.err(f"{spec.logical_name}.{c.name}: FK -> {c.fk} "
                         f"(table {table} has no column {col})")

    def _check_key_recipe(self, spec: TableSpec) -> None:
        recipe = spec.key_recipe
        if recipe is None:
            return
        if not recipe.name:
            self.err(f"{spec.logical_name}: key_recipe needs a name")
        if not recipe.columns and not spec.bk_columns:
            self.err(f"{spec.logical_name}: key_recipe {recipe.name} names no "
                     f"columns, so it is the business key - but the table "
                     f"has no bk columns")
        for col in recipe.columns:
            if col not in spec.column_names:
                self.err(f"{spec.logical_name}: key_recipe column '{col}' is "
                         f"not a column of the table")
            elif spec.column(col).nullable:
                self.err(f"{spec.logical_name}: key_recipe column '{col}' must "
                         f"be NOT NULL - a NULL part would let keys collide")

    def _check_layouts(self, s: SourceSpec,
                       bronze: Optional[TableSpec]) -> None:
        if not s.layouts:
            return
        standard = [lay.layout_id for lay in s.layouts.values() if lay.standard]
        if len(standard) != 1:
            self.err(f"{s.entity}: exactly one layout must be 'standard: true', "
                     f"found {standard or 'none'}")
        elif s.schema_version != standard[0]:
            self.err(f"{s.entity}: schema_version '{s.schema_version}' should "
                     f"be the standard layout '{standard[0]}'")
        if len(s.scope_columns) != 1:
            self.err(f"{s.entity}: a multi-layout feed needs exactly one "
                     f"silver.scope column (the unit a better-ranked file "
                     f"replaces), found {s.scope_columns}")
        real = set(bronze.column_names) if bronze is not None else set()
        for lay in s.layouts.values():
            where = f"{s.entity}.layouts.{lay.layout_id}"
            if not _LAYOUT_ID.fullmatch(lay.layout_id):
                self.err(f"{where}: layout ids are UPPER_SNAKE_CASE")
            if lay.priority < 1:
                self.err(f"{where}: priority must be 1 or more")
            if lay.standard and lay.header_map:
                self.err(f"{where}: the standard layout reads its headers from "
                         f"the bronze spec's source_header - drop its header_map")
            if not lay.standard and not lay.header_map:
                self.err(f"{where}: a non-standard layout needs a header_map")
            mapped = set(lay.column_map.values())
            for header, target in lay.column_map.items():
                if bronze is not None and target not in real:
                    self.err(f"{where}: {header!r} -> {target} is not a bronze "
                             f"column of {s.bronze_table}")
            for header in lay.optional_headers:
                if header not in lay.column_map:
                    self.err(f"{where}: optional header {header!r} is not one "
                             f"of this layout's headers")
            for header in lay.parked_headers:
                if header in lay.column_map:
                    self.err(f"{where}: header {header!r} is both mapped and "
                             f"parked - pick one")
            for target in lay.aliases:
                if target not in mapped:
                    self.err(f"{where}: alias for {target}, which this layout "
                             f"does not map")

    # -- feeds ---------------------------------------------------------------
    def check_sources(self) -> None:
        for s in self.ctx.sources():
            for role, logical in (("bronze_table", s.bronze_table),
                                  ("silver_table", s.silver_table)):
                if logical not in self._table_names:
                    self.err(f"{s.entity}: {role} '{logical}' is not a table spec")
            bronze = self.ctx.table(s.bronze_table) \
                if s.bronze_table in self._table_names else None
            self._check_layouts(s, bronze)
            if bronze is not None:
                key = ("fixed_column_map"
                       if "weekly" in str(s.parser) else "column_map")
                real = set(bronze.column_names)
                for header, target in (s.parse.get(key) or {}).items():
                    if target not in real:
                        # the deliberate EAN gap is an override, still flagged
                        self.err(f"{s.entity}: column_map {header!r} -> {target} "
                                 f"is not a bronze column of {s.bronze_table}")
            if s.silver_table in self._table_names:
                sil = self.ctx.table(s.silver_table)
                for col in s.scope_columns:
                    if col not in sil.column_names:
                        self.err(f"{s.entity}: scope column '{col}' not on "
                                 f"{s.silver_table}")
                nullsafe_bk = {c.name for c in sil.bk_columns if c.null_safe}
                for col in s.silver.get("dq_sentinel_columns", []) or []:
                    if col not in nullsafe_bk:
                        self.err(f"{s.entity}: dq_sentinel column '{col}' is not "
                                 f"a null-safe BK column of {s.silver_table}")

    # -- resolution rules referenced in code ---------------------------------
    def check_resolution_rules(self) -> None:
        in_config = {r.rule_id for r in self.ctx.resolution_rules}
        referenced: set[str] = set()
        for path in (ROOT / "core" / "silver").glob("*.py"):
            referenced |= set(re.findall(r'rules\["([A-Z_]+)"\]',
                                         path.read_text(encoding="utf-8")))
        for rule_id in sorted(referenced - in_config):
            self.err(f"resolution rule '{rule_id}' is used in code but not in "
                     f"sources.yaml resolution config")

    # -- run -----------------------------------------------------------------
    def run(self) -> int:
        self.check_tables()
        self.check_sources()
        self.check_resolution_rules()
        if self.errors:
            print(f"CONFIG INVALID - {len(self.errors)} problem(s):")
            for e in self.errors:
                print(f"  - {e}")
            return 1
        n = len(self._table_names)
        print(f"CONFIG OK - {n} tables, {len(list(self.ctx.sources()))} feeds, "
              f"{len(self.ctx.resolution_rules)} resolution rules validated.")
        return 0


def main(argv: list[str]) -> int:
    conf_dir = Path(argv[1]) if len(argv) > 1 else ROOT / "conf"
    return Validator(conf_dir).run()


if __name__ == "__main__":
    raise SystemExit(main(sys.argv))
