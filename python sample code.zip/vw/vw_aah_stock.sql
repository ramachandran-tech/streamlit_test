-- =====================================================================================================
-- gold.vw_aah_stock - order and delivery days per product and location from the AAH stock file.
-- View requirement 4, "AAH stock view" (docs/view_requirements2.jpeg). First cut: the requirement is
-- still waiting for further details from Maxi, so the assumptions below need confirming.
--
-- Rows      : the rows of gold.vw_aah_stock_details (one per product, location and supplier in a stock
--             file, per stock date), showing only the requested columns plus period_end_date. Without the
--             stock date, every stock file would repeat the same product and location rows.
-- order_day : the stock file has one Y/N column per weekday, [SL] Order (Mon) to [SL] Order (Fri). The
--             requirement asks for the days marked Yes in one column, so order_day lists them Monday first,
--             comma separated ("Monday, Wednesday, Friday"). NULL when no day is marked.
-- delivery_ : the requirement says "Delivery Day (= Delivery Day + SL Lead time)"; read as order day plus
-- day         [SL] Lead time. Each order day is moved on by the lead time and named, in the same order as
--             order_day, so the n-th delivery day belongs to the n-th order day ("Tuesday, Thursday,
--             Saturday" for the example above with a lead time of 1). NULL when the lead time is missing.
-- Assumed   : (1) the lead time is in calendar days, so Friday plus 1 is Saturday - if it is working days,
-- (Maxi)        Friday plus 1 should be Monday; (2) the lead time is a whole number of days (it is in
--               every file so far); (3) one row per stock date is wanted, rather than only the latest
--               stock date; (4) a product has one supplier per location - if it can have more, the rows
--               of each supplier look alike here and supplier_name should be added.
-- Phoenix   : not here - AAH stock only, as requirement 4 says; Phoenix sends no stock file (see
--             gold.vw_aah_stock_details).
-- Names     : physical names for the dev config in conf/platform.yaml, built as
--             <catalog>.<schema>.<layer prefix><table>. For another environment, change
--             efdataonelh_dev.default and the prefixes to match its platform.yaml.
-- Order     : reads gold.vw_aah_stock_details - create that view first.
-- =====================================================================================================

CREATE OR REPLACE VIEW efdataonelh_dev.default.gold_vw_aah_stock (
    period_end_date     COMMENT 'Stock date: Period end date of the stock file',
    bayer_product_name  COMMENT 'Product Name from the Wholesale Product Master. NULL when the row matched no master product',
    bayer_sku           COMMENT 'SKU from the Wholesale Product Master. NULL when the row matched no master product',
    pip_code            COMMENT 'PIP Code from the Wholesale Product Master. NULL when the row matched no master product',
    location_name       COMMENT 'Location name from the stock file',
    order_day           COMMENT 'Weekdays marked Y in [SL] Order (Mon) to [SL] Order (Fri), Monday first, comma separated. NULL when none is marked',
    delivery_day        COMMENT 'Each order day plus [SL] Lead time (calendar days), in the same order as order_day. NULL when the lead time is missing')
COMMENT 'Order days and delivery days (order day plus lead time) per product, location and stock date from the AAH Bayer Stock File. View requirement 4, first cut pending details from Maxi.'
AS
WITH stock AS (
    SELECT
        period_end_date,
        bayer_product_name,
        bayer_sku,
        pip_code,
        location_name,
        sl_order_mon,
        sl_order_tue,
        sl_order_wed,
        sl_order_thu,
        sl_order_fri,
        CAST(sl_lead_time AS INT) AS lead_time_days,
        DATE'2024-01-01' AS a_monday
    FROM efdataonelh_dev.default.gold_vw_aah_stock_details
)
SELECT
    period_end_date,
    bayer_product_name,
    bayer_sku,
    pip_code,
    location_name,
    NULLIF(concat_ws(', ',
        IF(sl_order_mon, 'Monday',    NULL),
        IF(sl_order_tue, 'Tuesday',   NULL),
        IF(sl_order_wed, 'Wednesday', NULL),
        IF(sl_order_thu, 'Thursday',  NULL),
        IF(sl_order_fri, 'Friday',    NULL)), '') AS order_day,
    -- Weekday arithmetic on a real date: 1 January 2024 was a Monday, so adding the order day
    -- (0 = Monday) and the lead time lands on the delivery weekday, past Sunday too, and a missing
    -- lead time gives NULL. Not an array lookup: in Spark 3.5 with ANSI mode, element_at given a NULL
    -- index computed from a column returns the last element instead of NULL.
    NULLIF(concat_ws(', ',
        IF(sl_order_mon, date_format(date_add(a_monday, 0 + lead_time_days), 'EEEE'), NULL),
        IF(sl_order_tue, date_format(date_add(a_monday, 1 + lead_time_days), 'EEEE'), NULL),
        IF(sl_order_wed, date_format(date_add(a_monday, 2 + lead_time_days), 'EEEE'), NULL),
        IF(sl_order_thu, date_format(date_add(a_monday, 3 + lead_time_days), 'EEEE'), NULL),
        IF(sl_order_fri, date_format(date_add(a_monday, 4 + lead_time_days), 'EEEE'), NULL)), '') AS delivery_day
FROM stock;

-- Latest stock date only:
-- SELECT * FROM efdataonelh_dev.default.gold_vw_aah_stock
-- WHERE period_end_date = (SELECT max(period_end_date) FROM efdataonelh_dev.default.gold_vw_aah_stock);
