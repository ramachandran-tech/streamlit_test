-- =====================================================================================================
-- gold.vw_aah_stock_details - every column of the AAH "Bayer Stock File", described with the product
-- master's PIP code, SKU and product name. View requirement 3, "AAH stock view with details"
-- (docs/view_requirements1.jpeg and 2).
--
-- Rows      : one per product, location and supplier in a stock file, for every stock date (the file's
--             Period end date), as published in gold.fact_stock_availability_snapshot. A stock file
--             re-sent for the same date replaces that date, so each date shows the latest file only.
-- Columns   : the file's columns in the file's order. Gold publishes the stock measures; the ordering
--             details, names and comments (location and supplier name, pack size, block start date,
--             comments, prom period, min. delivery, the [SL] order days, lead time and order cycle) are
--             kept in Silver only (open decision OD-11), so the view reads those from the row's Silver
--             record, which has the same key.
-- Product   : pip_code, bayer_sku and bayer_product_name come from the Wholesale Product Master
--             (gold.dim_product). Silver matched each row on its PIP code (rule PIP_EXACT), falling back
--             to the product code as the AAH product code. The view follows the fact's product_key, so a
--             row shows the master version valid on its stock date. A row that matched no master product
--             shows NULL in these three columns.
-- Left out  : the file's own PIP code and Product name, which the master values replace (requirement).
-- Phoenix   : not here - the requirement is the AAH Bayer Stock File, and Phoenix sends no stock file.
--             Since the V21 revision of 20 October the shared location list also holds the Phoenix
--             depots; this view takes the location from the stock row itself, so they never appear.
-- Names     : physical names for the dev config in conf/platform.yaml, built as
--             <catalog>.<schema>.<layer prefix><table>. For another environment, change
--             efdataonelh_dev.default and the prefixes to match its platform.yaml.
-- Order     : gold.vw_aah_stock reads this view, so create this one first.
-- =====================================================================================================

CREATE OR REPLACE VIEW efdataonelh_dev.default.gold_vw_aah_stock_details (
    period_start_date                                   COMMENT 'Period start date (row 2 of the stock file)',
    period_end_date                                     COMMENT 'Period end date (row 2 of the stock file): the stock date',
    pip_code                                            COMMENT 'PIP Code from the Wholesale Product Master. NULL when the row matched no master product',
    bayer_sku                                           COMMENT 'SKU from the Wholesale Product Master. NULL when the row matched no master product',
    bayer_product_name                                  COMMENT 'Product Name from the Wholesale Product Master. NULL when the row matched no master product',
    location_name                                       COMMENT 'Location name',
    location_code                                       COMMENT 'Location code',
    product_code                                        COMMENT 'Product code (the AAH product code)',
    pack_size                                           COMMENT 'Pack size',
    average_daily_forecast_next_30_days                 COMMENT 'Average daily forecast (next 30 days)',
    next_14_days_effective_forecast                     COMMENT 'Next 14 Days Effective Forecast',
    end_balance_qty                                     COMMENT 'End balance',
    forecasted_supply_days                              COMMENT 'Forecasted supply (days)',
    end_balance_value                                   COMMENT 'End balance value',
    open_purchase_orders_qty                            COMMENT 'Open purchase orders quantity',
    forecasted_supply_days_with_open_orders             COMMENT 'Forecasted supply (days) with open orders',
    todays_order_proposal_qty                           COMMENT 'Today\'s order Proposal',
    forecasted_supply_days_with_orders_and_proposals    COMMENT 'Forecasted supply (days) with open orders and proposal',
    order_proposal_value                                COMMENT 'Order proposal (value)',
    projected_oos_next_7_days                           COMMENT 'Projected OOS next 7 days',
    projected_lost_sales_next_7_days                    COMMENT 'Projected lost sales next 7 days',
    product_location_block_start_date                   COMMENT 'Product-location Block Start Date',
    product_comments                                    COMMENT 'Product comments',
    purchase_price                                      COMMENT 'Purchase price',
    storage_type                                        COMMENT 'Storage type',
    promo_period                                        COMMENT 'Prom period',
    min_delivery                                        COMMENT 'Min. delivery',
    supplier_code                                       COMMENT 'Supplier code',
    supplier_name                                       COMMENT 'Supplier name',
    sl_order_mon                                        COMMENT '[SL] Order (Mon): true when the file says Y',
    sl_order_tue                                        COMMENT '[SL] Order (Tue): true when the file says Y',
    sl_order_wed                                        COMMENT '[SL] Order (Wed): true when the file says Y',
    sl_order_thu                                        COMMENT '[SL] Order (Thu): true when the file says Y',
    sl_order_fri                                        COMMENT '[SL] Order (Fri): true when the file says Y',
    sl_lead_time                                        COMMENT '[SL] Lead time, in days',
    sl_order_cycle                                      COMMENT '[SL] Order cycle',
    aah_product_owner                                   COMMENT 'AAH product owner',
    dq_status                                           COMMENT 'PASS, or WARNING when a data quality rule flagged the row (the rule ids are on its Silver row)',
    source_file_name                                    COMMENT 'Stock file the row was delivered in',
    source_fact_key                                     COMMENT 'Key of the row in gold.fact_stock_availability_snapshot (stock_snapshot_key)')
COMMENT 'Every column of the AAH Bayer Stock File per product, location, supplier and stock date, with the PIP code, SKU and product name from the Wholesale Product Master. View requirement 3.'
AS
SELECT
    f.period_start_date                                 AS period_start_date,
    f.period_end_date                                   AS period_end_date,
    p.pip_code                                          AS pip_code,
    p.sku                                               AS bayer_sku,
    p.product_name                                      AS bayer_product_name,
    s.location_name                                     AS location_name,
    f.location_code                                     AS location_code,
    f.product_code                                      AS product_code,
    s.pack_size                                         AS pack_size,
    f.average_daily_forecast_next_30_days               AS average_daily_forecast_next_30_days,
    f.next_14_days_effective_forecast                   AS next_14_days_effective_forecast,
    f.end_balance_qty                                   AS end_balance_qty,
    f.forecasted_supply_days                            AS forecasted_supply_days,
    f.end_balance_value                                 AS end_balance_value,
    f.open_purchase_orders_qty                          AS open_purchase_orders_qty,
    s.forecasted_supply_days_with_open_orders           AS forecasted_supply_days_with_open_orders,
    f.todays_order_proposal_qty                         AS todays_order_proposal_qty,
    s.forecasted_supply_days_with_orders_and_proposals  AS forecasted_supply_days_with_orders_and_proposals,
    f.order_proposal_value                              AS order_proposal_value,
    f.projected_oos_next_7_days                         AS projected_oos_next_7_days,
    f.projected_lost_sales_next_7_days                  AS projected_lost_sales_next_7_days,
    s.product_location_block_start_date                 AS product_location_block_start_date,
    s.product_comments                                  AS product_comments,
    f.purchase_price                                    AS purchase_price,
    f.storage_type                                      AS storage_type,
    s.promo_period                                      AS promo_period,
    s.min_delivery                                      AS min_delivery,
    f.supplier_code                                     AS supplier_code,
    s.supplier_name                                     AS supplier_name,
    s.sl_order_mon                                      AS sl_order_mon,
    s.sl_order_tue                                      AS sl_order_tue,
    s.sl_order_wed                                      AS sl_order_wed,
    s.sl_order_thu                                      AS sl_order_thu,
    s.sl_order_fri                                      AS sl_order_fri,
    s.sl_lead_time                                      AS sl_lead_time,
    s.sl_order_cycle                                    AS sl_order_cycle,
    f.aah_product_owner                                 AS aah_product_owner,
    s.dq_status                                         AS dq_status,
    f.source_file_name                                  AS source_file_name,
    f.stock_snapshot_key                                AS source_fact_key
FROM efdataonelh_dev.default.gold_fact_stock_availability_snapshot AS f
LEFT JOIN efdataonelh_dev.default.silver_stock_availability AS s
       ON s.stock_availability_id = f.stock_snapshot_key
LEFT JOIN efdataonelh_dev.default.gold_dim_product AS p
       ON p.product_key = f.product_key;

-- Check after creating (one row per fact row, and how many matched no master product):
-- SELECT period_end_date, count(*) AS rows, count_if(pip_code IS NULL) AS rows_without_master_product
-- FROM efdataonelh_dev.default.gold_vw_aah_stock_details
-- GROUP BY period_end_date
-- ORDER BY period_end_date;
