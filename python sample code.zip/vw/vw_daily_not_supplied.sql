-- =====================================================================================================
-- gold.vw_daily_not_supplied - order lines a wholesaler could not supply, with the reason, described
-- with the product master's PIP code, SKU and product name. View requirement 5, "Daily not supplied"
-- (docs/view_requirements2.jpeg). First cut: the requirement is still waiting for further details from
-- Maxi, so this follows the rules given for the sales details view (requirement 1) until then.
--
-- Rows      : one per not-supplied line published in gold.fact_daily_sales_not_supplied (the AAH Bayer
--             Daily Not Supplied file). AAH is the only wholesaler that sends not-supplied lines:
--             Williams sends sales only, and the Phoenix feed added in the V21 revision of 20 October is
--             its sales file's SalesByChannel_Bayer tab, which has no not-supplied lines either. The requirement
--             asks for the wholesaler name all the same, so wholesaler_name is here, and another
--             wholesaler's not-supplied lines would be a further UNION ALL branch.
-- Columns   : the customer columns keep the names they had before gold.vw_sales_details took the
--             business's mapping sheet (customer_code there is account_number, print_branch is
--             depot_print_branch, and so on). The sheet was given for the sales details view only;
--             rename here too if the business wants the two views to line up.
-- Product   : pip_code, bayer_sku and bayer_product_name come from the Wholesale Product Master
--             (gold.dim_product). Silver matched each line on its PIP code (rule PIP_EXACT, with the AAH
--             product code as a fallback); the view shows the master version valid on the line's date,
--             and NULL in these three columns when the line matched no master product.
-- Customer  : as delivered on the line, from its Silver row (the fact keeps keys and measures only).
-- Left out  : the file's own PIP code and product description, which the master values replace, and
--             Invoice Number. This first cut left it out because requirement 1 hides it on AAH sales
--             lines; the sales details view has since kept it in the view for reports to hide, so add it
--             here the same way if Maxi wants it. Both are to confirm with Maxi.
-- Names     : physical names for the dev config in conf/platform.yaml, built as
--             <catalog>.<schema>.<layer prefix><table>. For another environment, change
--             efdataonelh_dev.default and the prefixes to match its platform.yaml.
-- =====================================================================================================

CREATE OR REPLACE VIEW efdataonelh_dev.default.gold_vw_daily_not_supplied (
    wholesaler_name         COMMENT 'Wholesaler that reported the line: AAH (Williams and Phoenix send no not-supplied lines)',
    not_supplied_date       COMMENT 'AAH: Date',
    pip_code                COMMENT 'PIP Code from the Wholesale Product Master. NULL when the line matched no master product',
    bayer_sku               COMMENT 'SKU from the Wholesale Product Master. NULL when the line matched no master product',
    bayer_product_name      COMMENT 'Product Name from the Wholesale Product Master. NULL when the line matched no master product',
    volume                  COMMENT 'Units ordered but not supplied. AAH: Volume',
    omit_marker_id          COMMENT 'Reason code. AAH: Omit Marker ID',
    omit_marker_description COMMENT 'Reason. AAH: Omit Marker Description',
    customer_code           COMMENT 'AAH: Account Number',
    customer_name           COMMENT 'AAH: Account Name',
    customer_type           COMMENT 'AAH: Customer Type',
    customer_channel        COMMENT 'AAH: Customer Channel',
    address_line_1          COMMENT 'AAH: Address Line 1',
    address_line_2          COMMENT 'AAH: Address Line 2',
    address_line_3          COMMENT 'AAH: Address Line 3',
    address_line_4          COMMENT 'AAH: Address Line 4',
    post_code               COMMENT 'AAH: Post Code',
    print_branch            COMMENT 'AAH: Print Branch',
    account_branch          COMMENT 'AAH: Account Branch',
    aah_product_code        COMMENT 'AAH: AAH Product Code',
    ean_code                COMMENT 'AAH: EAN Code',
    pack_size               COMMENT 'AAH: Pack Size',
    dq_status               COMMENT 'PASS, or WARNING when a data quality rule flagged the line (the rule ids are on its Silver row)',
    source_file_name        COMMENT 'File the line was delivered in',
    source_fact_key         COMMENT 'Key of the line in gold.fact_daily_sales_not_supplied (daily_sales_not_supplied_key)')
COMMENT 'Order lines that could not be supplied, with the reason and the PIP code, SKU and product name from the Wholesale Product Master. View requirement 5, first cut pending details from Maxi.'
AS
-- AAH: Bayer Daily Not Supplied
SELECT
    'AAH'                               AS wholesaler_name,
    f.business_date                     AS not_supplied_date,
    p.pip_code                          AS pip_code,
    p.sku                               AS bayer_sku,
    p.product_name                      AS bayer_product_name,
    f.volume                            AS volume,
    f.omit_marker_id                    AS omit_marker_id,
    f.omit_marker_description           AS omit_marker_description,
    f.account_number                    AS customer_code,
    s.account_name                      AS customer_name,
    s.customer_type                     AS customer_type,
    s.customer_channel                  AS customer_channel,
    s.address_line_1                    AS address_line_1,
    s.address_line_2                    AS address_line_2,
    s.address_line_3                    AS address_line_3,
    s.address_line_4                    AS address_line_4,
    s.post_code                         AS post_code,
    f.print_branch                      AS print_branch,
    f.account_branch                    AS account_branch,
    f.aah_product_code                  AS aah_product_code,
    f.ean_code                          AS ean_code,
    s.pack_size                         AS pack_size,
    f.dq_status                         AS dq_status,
    f.source_file_name                  AS source_file_name,
    f.daily_sales_not_supplied_key      AS source_fact_key
FROM efdataonelh_dev.default.gold_fact_daily_sales_not_supplied AS f
LEFT JOIN efdataonelh_dev.default.silver_daily_sales_not_supplied AS s
       ON s.daily_sales_not_supplied_id = f.daily_sales_not_supplied_key
LEFT JOIN efdataonelh_dev.default.gold_dim_product AS p
       ON p.product_key = f.product_key;

-- Not supplied per day and reason:
-- SELECT not_supplied_date, omit_marker_description, count(*) AS lines, sum(volume) AS volume
-- FROM efdataonelh_dev.default.gold_vw_daily_not_supplied
-- GROUP BY 1, 2
-- ORDER BY 1, 2;
