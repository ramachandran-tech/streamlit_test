-- =====================================================================================================
-- gold.vw_sales_aggregated - daily sales volume per wholesaler and product, without customer details,
-- with each wholesaler's market share. View requirement 2, "aggregated sales view without customer
-- details" (docs/view_requirements1.jpeg).
--
-- Rows      : one per wholesaler, sale date and master product, summed over every customer of
--             gold.vw_sales_details, so the same sources: AAH Bayer Daily Sales, both Williams files and
--             the Phoenix SalesByChannel_Bayer tab (from the Phoenix release; its feed returns no rows until it
--             is switched on). Lines that matched no master product are summed into one row per
--             wholesaler and day, with NULL product columns, so they still count in the totals.
-- Product   : pip_code, bayer_sku and bayer_product_name from the Wholesale Product Master, exactly as in
--             gold.vw_sales_details.
-- Market    : market_share is the share of the calendar month's total volume, across all wholesalers and
-- share       products, that the row's volume makes up. Shares add up: summed over one wholesaler's rows
--             in a month they give that wholesaler's market share for the month ("each wholesaler vs total
--             sales for the month"), and the wholesalers of one month always add up to 1 (to rounding).
--             The share is calculated per row rather than repeated for the whole month so that a report
--             can sum it by wholesaler, month or product without overstating it. Do not add it up across
--             different months.
--             Volume is net of returns. A month is only comparable across wholesalers once every
--             wholesaler has delivered it; until then the wholesalers that have delivered get too large a
--             share. That includes Phoenix: once its feed goes live, the AAH and Williams shares of every
--             month Phoenix delivers go down, as they should - tell the report owners before go-live.
--             Phoenix "Date" is taken as the invoice date until OD-16 confirms it; if it turns out to be
--             the dispatch or order date, its lines sit in a slightly different month near month ends.
-- Left out  : customer details, per the requirement. Further calculations are still to come (Maxi).
-- Names     : physical names for the dev config in conf/platform.yaml, built as
--             <catalog>.<schema>.<layer prefix><table>. For another environment, change
--             efdataonelh_dev.default and the prefixes to match its platform.yaml.
-- Order     : reads gold.vw_sales_details - create that view first.
-- =====================================================================================================

CREATE OR REPLACE VIEW efdataonelh_dev.default.gold_vw_sales_aggregated (
    wholesaler_name     COMMENT 'Wholesaler that reported the sales: AAH, Williams or Phoenix',
    sale_date           COMMENT 'Sale date. AAH: Date. Williams: invoice date (history build-up: Despatch Date). Phoenix: Date',
    pip_code            COMMENT 'PIP Code from the Wholesale Product Master. NULL for sales that matched no master product',
    bayer_sku           COMMENT 'SKU from the Wholesale Product Master. NULL for sales that matched no master product',
    bayer_product_name  COMMENT 'Product Name from the Wholesale Product Master. NULL for sales that matched no master product',
    volume              COMMENT 'Units the wholesaler sold of the product on the day, all customers together, net of returns',
    market_share        COMMENT 'Share of the total volume of all wholesalers in the same calendar month that this row makes up. Summed over one wholesaler and one month it is the market share of that wholesaler for the month; all wholesalers of a month add up to 1. Do not add it up across months.')
COMMENT 'Daily sales volume per wholesaler and master product, without customer details, with market share against the monthly total of all wholesalers. View requirement 2.'
AS
WITH daily AS (
    SELECT
        wholesaler_name,
        date AS sale_date,
        pip_code,
        bayer_sku,
        bayer_product_name,
        SUM(volume) AS volume
    FROM efdataonelh_dev.default.gold_vw_sales_details
    GROUP BY wholesaler_name, date, pip_code, bayer_sku, bayer_product_name
)
SELECT
    wholesaler_name,
    sale_date,
    pip_code,
    bayer_sku,
    bayer_product_name,
    volume,
    CAST(volume / NULLIF(SUM(volume) OVER (PARTITION BY trunc(sale_date, 'MM')), 0)
         AS DECIMAL(38, 6)) AS market_share
FROM daily;

-- Market share per wholesaler and month, the way a report would show it:
-- SELECT trunc(sale_date, 'MM') AS sale_month, wholesaler_name,
--        sum(volume) AS volume, sum(market_share) AS market_share
-- FROM efdataonelh_dev.default.gold_vw_sales_aggregated
-- GROUP BY 1, 2
-- ORDER BY 1, 2;
