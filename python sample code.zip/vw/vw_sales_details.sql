-- =====================================================================================================
-- gold.vw_sales_details - every wholesaler's sales lines, described with the product master's PIP code,
-- SKU and product name. View requirement 1, "Sales details" (docs/view_requirements1.jpeg), with the
-- column names and the mapping across wholesalers from the business's mapping sheet
-- (docs/view_column_mapping.png).
--
-- Rows      : one per sales line published in Gold.
--               AAH       gold.fact_daily_sales     Bayer Daily Sales
--               Williams  gold.fact_williams_sales  the weekly file and the sales history build-up: one
--                                                   feed in two layouts, landed in one table. Where both
--                                                   cover an invoice date, Silver keeps only the weekly
--                                                   file's lines, so a date is never counted twice.
--               Phoenix   gold.fact_phoenix_sales   sales history build-up 2 and later Phoenix files, tab
--                                                   SalesByChannel_Bayer only (the feed reads no other tab). A
--                                                   newer file replaces every date from its first to its
--                                                   last, so a date is never counted twice either.
-- Columns   : every column on the sheet's "column name in view" list, in its order, each name written
--             the platform's way (lower case, underscores): "Depot (Print Branch)" is depot_print_branch,
--             "Ean Code" is ean_code. Every column's comment starts with the sheet's own name, which a
--             report can use as its label. wholesaler_name is not on the sheet; requirement 1 asks for
--             it and requirement 2 calls it "Wholesaler name".
-- Mapping   : each wholesaler column goes where the sheet puts it, so a Williams Customer Code is an
--             account_number, Customer City is address_line_4, Customer Class is customer_channel and
--             Material Code is aah_product_code; a Phoenix LocName is depot_print_branch, CuNo is
--             account_number, CuPCode is post_code and ArtCode is aah_product_code. A view column a
--             wholesaler has nothing for is NULL on its lines. The sheet lists the Williams weekly file
--             only; the history build-up arrives under the same names (Silver renames WMS Code, Account
--             Name, Address6, WMS Class, Sales (Units) and Despatch Date; Material Code has the same name
--             in both), and its Delivery Address, which the weekly file does not have, goes in
--             address_line_1 - the pairing silver.account_reference uses. The Phoenix location number
--             (LocNo) is not on the sheet, so it is not here; the line's depot name is.
-- Product   : pip_code, bayer_sku and bayer_product_name always come from the Wholesale Product Master
--             (gold.dim_product), never from the wholesaler's file; they take the place of the sheet's
--             PIP Code and Product Description, as requirement 1 asks.
-- Join      : requirement 1 says "join on pip code for AAH and Phoenix data" and "join on William
--             Product Name for Williams data". That join is made once, in Silver, when each line is
--             matched to the product master, and the Gold fact keeps the result as product_key; this
--             view follows product_key to gold.dim_product. So the requirement's join is not written
--             out below - it is already in the key - and product_matched_on shows, line by line, what
--             the line was matched on:
--               'PIP code'               AAH and Phoenix: the line's PIP code (7 digits, dashes and
--                                        spaces ignored) is the master product's PIP code
--               'Williams product name'  Williams: the line's material description is the master's
--                                        Williams Product Name, ignoring case and spacing only
--               'AAH product code'       AAH, fallback: the line has no PIP code the master knows, but
--                                        its AAH product code is a master product's
--               'Phoenix article code'   Phoenix, fallback: the line has no usable PIP code, but its
--                                        article code was seen on other lines with a PIP code that
--                                        matched (rule SAME_LINE_PIP) - so it still comes from a PIP
--               NULL                     the line matched no master product: it keeps its volume and
--                                        shows NULL product columns
--             The two fallbacks only ever add products to lines the requirement's join would leave
--             without one; they never change a line that has a matching PIP or name. Filter on
--             product_matched_on IN ('PIP code', 'Williams product name') for the requirement's join
--             exactly. The Williams material code rule, still pending on OD-06, would add
--             'Williams material code' ahead of the name once activated - that departs from the
--             requirement, so agree it with the business first.
--             A line shows the master version that was valid on its sale date. For today's master
--             values on every line, look the product up by product_business_key with is_current = true.
--             The AAH and Phoenix customer and depot text (and the AAH pack size) come from the line's
--             Silver row: their facts keep the line's keys, codes and measures, not its text.
-- Reports   : requirement 1 asks for some columns not to be shown. Those that are on the sheet are in
--             the view, so the data stays available, and the report hides them:
--               invoice_number    hide it (AAH is the only wholesaler that sends one)
--               aah_product_code  hide it on Williams lines (wholesaler_name = 'Williams'), where it
--                                 holds the Williams Material Code
--             The rest are not on the sheet and not in the view: Sales Value (AAH, Phoenix) and the
--             Williams Country Code. Requirement 1 hides nothing else for Phoenix, so its article code
--             shows in aah_product_code.
-- Go-live   : the Phoenix feed is deployed switched off (active: false in conf/sources.yaml) until its
--             file name, date format and folder are confirmed (OD-10, OD-16). Until then its branch
--             returns no rows, and the view is exactly AAH and Williams.
-- Not yet   : the AAH history build-up has no feed in the platform. If it has the Daily Sales layout, it
--             can be delivered through the daily_sales feed (named to match that feed's file_glob) and
--             lands in gold.fact_daily_sales, with no change here.
-- Names     : physical names for the dev config in conf/platform.yaml, built as
--             <catalog>.<schema>.<layer prefix><table>. For another environment, change
--             efdataonelh_dev.default and the prefixes to match its platform.yaml.
-- Order     : gold.vw_sales_aggregated reads this view, so create this one first. The Phoenix tables
--             are created by the pipeline's first run after the Phoenix release, feed live or not.
-- To confirm: with the business, that the Williams history build-up's Delivery Address belongs in
--             address_line_1 (the sheet is silent on it); with Phoenix, that LocName names the depot that
--             served the customer (OD-18) and that Date is the invoice date (OD-16).
-- =====================================================================================================

CREATE OR REPLACE VIEW efdataonelh_dev.default.gold_vw_sales_details (
    wholesaler_name         COMMENT 'Wholesaler name: the wholesaler that reported the sale, AAH, Williams or Phoenix',
    date                    COMMENT 'Date. AAH: Date. Williams: Invoice Date (history build-up: Despatch Date). Phoenix: Date',
    depot_print_branch      COMMENT 'Depot (Print Branch). AAH: Print Branch. Phoenix: LocName. NULL for Williams',
    depot_account_branch    COMMENT 'Depot (Account Branch). AAH: Account Branch. NULL for Williams and Phoenix',
    account_number          COMMENT 'Account Number. AAH: Account Number. Williams: Customer Code (history build-up: WMS Code). Phoenix: CuNo',
    account_name            COMMENT 'Account Name. AAH: Account Name. Williams: Customer Name (history build-up: Account Name). Phoenix: CuName',
    address_line_1          COMMENT 'Address Line 1. AAH: Address Line 1. Williams history build-up: Delivery Address. NULL for the Williams weekly file and Phoenix',
    address_line_2          COMMENT 'Address Line 2. AAH: Address Line 2. NULL for Williams and Phoenix',
    address_line_3          COMMENT 'Address Line 3. AAH: Address Line 3. NULL for Williams and Phoenix',
    address_line_4          COMMENT 'Address Line 4. AAH: Address Line 4. Williams weekly file: Customer City. NULL for the Williams history build-up and Phoenix',
    post_code               COMMENT 'Post Code. AAH: Post Code. Williams: Sales Order Delivery Post Code (history build-up: Address6). Phoenix: CuPCode, in standard UK format',
    customer_type           COMMENT 'Customer Type. AAH: Customer Type. NULL for Williams and Phoenix',
    customer_channel        COMMENT 'Customer Channel. AAH: Customer Channel. Williams: Customer Class (history build-up: WMS Class). Phoenix: CustomerChannel. Each as the wholesaler sends it (one list across wholesalers is OD-20)',
    aah_product_code        COMMENT 'AAH Product Code. AAH: AAH Product Code. Williams: Material Code, which requirement 1 does not show: hide it in reports on Williams lines. Phoenix: ArtCode',
    pip_code                COMMENT 'PIP Code from the Wholesale Product Master, not from the wholesaler file. NULL when the line matched no master product',
    bayer_sku               COMMENT 'Bayer SKU: SKU from the Wholesale Product Master. NULL when the line matched no master product',
    bayer_product_name      COMMENT 'Bayer Product Name: Product Name from the Wholesale Product Master, in place of the Product Description in the wholesaler file. NULL when the line matched no master product',
    ean_code                COMMENT 'Ean Code. AAH: EAN Code. Phoenix: EAN. NULL for Williams',
    pack_size               COMMENT 'Pack Size. AAH: Pack Size. NULL for Williams and Phoenix',
    invoice_number          COMMENT 'Invoice Number. AAH: Invoice Number. NULL for Williams and Phoenix. Requirement 1 does not show it: hide it in reports',
    volume                  COMMENT 'Volume: units sold, negative for a return. AAH: Volume. Williams: Sales QTY (history build-up: Sales (Units)). Phoenix: SalesQty',
    product_matched_on      COMMENT 'What the line was matched to the product master on: PIP code (AAH, Phoenix) or Williams product name (Williams), as requirement 1 asks; AAH product code or Phoenix article code when the line has no usable PIP code; NULL when it matched no master product',
    dq_status               COMMENT 'PASS, or WARNING when a data quality rule flagged the line (the rule ids are on its Silver row)',
    source_file_name        COMMENT 'File the line was delivered in',
    source_fact_key         COMMENT 'Key of the line in its Gold fact: daily_sales_key (AAH), williams_sales_key (Williams) or phoenix_sales_key (Phoenix)')
COMMENT 'Sales lines from every wholesaler (AAH, Williams, Phoenix), with every column of the business mapping sheet under its name, and the PIP code, SKU and product name from the Wholesale Product Master. View requirement 1.'
AS
-- AAH: Bayer Daily Sales
SELECT
    'AAH'                               AS wholesaler_name,
    f.business_date                     AS date,
    f.print_branch                      AS depot_print_branch,
    f.account_branch                    AS depot_account_branch,
    f.account_number                    AS account_number,
    s.account_name                      AS account_name,
    s.address_line_1                    AS address_line_1,
    s.address_line_2                    AS address_line_2,
    s.address_line_3                    AS address_line_3,
    s.address_line_4                    AS address_line_4,
    s.post_code                         AS post_code,
    s.customer_type                     AS customer_type,
    s.customer_channel                  AS customer_channel,
    f.aah_product_code                  AS aah_product_code,
    p.pip_code                          AS pip_code,
    p.sku                               AS bayer_sku,
    p.product_name                      AS bayer_product_name,
    f.ean_code                          AS ean_code,
    s.pack_size                         AS pack_size,
    f.invoice_number                    AS invoice_number,
    f.volume                            AS volume,
    CASE WHEN f.product_ref_id IS NULL THEN NULL
         WHEN f.pip_code = p.product_business_key THEN 'PIP code'
         ELSE 'AAH product code' END    AS product_matched_on,
    f.dq_status                         AS dq_status,
    f.source_file_name                  AS source_file_name,
    f.daily_sales_key                   AS source_fact_key
FROM efdataonelh_dev.default.gold_fact_daily_sales AS f
LEFT JOIN efdataonelh_dev.default.silver_daily_sales AS s
       ON s.daily_sales_id = f.daily_sales_key
LEFT JOIN efdataonelh_dev.default.gold_dim_product AS p
       ON p.product_key = f.product_key

UNION ALL

-- Williams: weekly file and history build-up, both already under the weekly file's column names
SELECT
    'Williams'                          AS wholesaler_name,
    f.invoice_date                      AS date,
    CAST(NULL AS STRING)                AS depot_print_branch,
    CAST(NULL AS STRING)                AS depot_account_branch,
    f.customer_code                     AS account_number,
    f.customer_name                     AS account_name,
    f.delivery_address                  AS address_line_1,
    CAST(NULL AS STRING)                AS address_line_2,
    CAST(NULL AS STRING)                AS address_line_3,
    f.customer_city                     AS address_line_4,
    f.sales_order_delivery_post_code    AS post_code,
    CAST(NULL AS STRING)                AS customer_type,
    f.customer_class                    AS customer_channel,
    f.material_code                     AS aah_product_code,
    p.pip_code                          AS pip_code,
    p.sku                               AS bayer_sku,
    p.product_name                      AS bayer_product_name,
    CAST(NULL AS STRING)                AS ean_code,
    CAST(NULL AS STRING)                AS pack_size,
    CAST(NULL AS STRING)                AS invoice_number,
    f.sales_qty                         AS volume,
    CASE WHEN f.product_ref_id IS NULL THEN NULL
         WHEN upper(regexp_replace(trim(f.material_description), '\\s+', ' '))
            = upper(regexp_replace(trim(p.williams_product_name), '\\s+', ' '))
         THEN 'Williams product name'
         ELSE 'Williams material code' END
                                        AS product_matched_on,
    f.dq_status                         AS dq_status,
    f.source_file_name                  AS source_file_name,
    f.williams_sales_key                AS source_fact_key
FROM efdataonelh_dev.default.gold_fact_williams_sales AS f
LEFT JOIN efdataonelh_dev.default.gold_dim_product AS p
       ON p.product_key = f.product_key

UNION ALL

-- Phoenix: tab SalesByChannel_Bayer; Sales Value is not on the sheet, so it is not shown
SELECT
    'Phoenix'                           AS wholesaler_name,
    f.business_date                     AS date,
    s.location_name                     AS depot_print_branch,
    CAST(NULL AS STRING)                AS depot_account_branch,
    f.customer_number                   AS account_number,
    s.customer_name                     AS account_name,
    CAST(NULL AS STRING)                AS address_line_1,
    CAST(NULL AS STRING)                AS address_line_2,
    CAST(NULL AS STRING)                AS address_line_3,
    CAST(NULL AS STRING)                AS address_line_4,
    s.customer_post_code                AS post_code,
    CAST(NULL AS STRING)                AS customer_type,
    s.customer_channel                  AS customer_channel,
    f.article_code                      AS aah_product_code,
    p.pip_code                          AS pip_code,
    p.sku                               AS bayer_sku,
    p.product_name                      AS bayer_product_name,
    f.ean_code                          AS ean_code,
    CAST(NULL AS STRING)                AS pack_size,
    CAST(NULL AS STRING)                AS invoice_number,
    f.sales_qty                         AS volume,
    CASE WHEN f.product_ref_id IS NULL THEN NULL
         WHEN f.pip_code = p.product_business_key THEN 'PIP code'
         ELSE 'Phoenix article code' END
                                        AS product_matched_on,
    f.dq_status                         AS dq_status,
    f.source_file_name                  AS source_file_name,
    f.phoenix_sales_key                 AS source_fact_key
FROM efdataonelh_dev.default.gold_fact_phoenix_sales AS f
LEFT JOIN efdataonelh_dev.default.silver_phoenix_sales AS s
       ON s.phoenix_sales_id = f.phoenix_sales_key
LEFT JOIN efdataonelh_dev.default.gold_dim_product AS p
       ON p.product_key = f.product_key;

-- How each wholesaler's lines were matched to the product master (requirement 1's join):
-- SELECT wholesaler_name, product_matched_on, count(*) AS lines, sum(volume) AS volume
-- FROM efdataonelh_dev.default.gold_vw_sales_details
-- GROUP BY wholesaler_name, product_matched_on
-- ORDER BY wholesaler_name, product_matched_on;

-- Check after creating (each wholesaler's line count and volume equal its fact's):
-- SELECT wholesaler_name, count(*) AS lines, sum(volume) AS volume,
--        count_if(pip_code IS NULL) AS lines_without_master_product
-- FROM efdataonelh_dev.default.gold_vw_sales_details
-- GROUP BY wholesaler_name;
-- SELECT count(*), sum(volume)    FROM efdataonelh_dev.default.gold_fact_daily_sales;
-- SELECT count(*), sum(sales_qty) FROM efdataonelh_dev.default.gold_fact_williams_sales;
-- SELECT count(*), sum(sales_qty) FROM efdataonelh_dev.default.gold_fact_phoenix_sales;
